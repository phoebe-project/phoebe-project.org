#ifndef PHOEBE_GUI_BASE_H
	#define PHOEBE_GUI_BASE_H 1

int phoebe_gui_init ();
int phoebe_gui_quit ();

#endif

#include <gtk/gtk.h>
