#include "phoebe_types.h"

int compute_passband_intensity (double *intensity, PHOEBE_hist *SED, PHOEBE_hist *PTF);
