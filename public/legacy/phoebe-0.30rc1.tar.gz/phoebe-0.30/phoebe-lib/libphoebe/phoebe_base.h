#ifndef PHOEBE_BASE_H
	#define PHOEBE_BASE_H 1

int    phoebe_init      ();
int    phoebe_configure ();
int    phoebe_quit      ();

#endif
