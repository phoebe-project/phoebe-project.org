#ifndef PHOEBE_SCRIPTER_CONFIGURATION
	#define PHOEBE_SCRIPTER_CONFIGURATION 1

int scripter_create_config_file ();

#endif
