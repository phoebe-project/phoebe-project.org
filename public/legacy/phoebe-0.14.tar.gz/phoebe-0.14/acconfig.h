/* Define if you have Linux gcc compiler. */
#define f2cFortran 1
