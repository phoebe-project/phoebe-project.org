#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <errno.h>

#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_gui.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_callbacks.h"
#include "phoebe_gui_support.h"

void phoebe_init ()
	{
	GtkWidget *warning_window;

	GtkWidget *readout_widget;

	char working_string[255];
	char *working_str = working_string;

	char keyword_string[255];
	char *keyword_str = keyword_string;

	FILE *config_file;

	sprintf (PHOEBE_VERSION_NUMBER, "0.14 (testing release)");
	sprintf (PHOEBE_VERSION_DATE,   "January 13, 2003");

	LC_ZOOM_FACTOR = 0.0;
	LC_X_OFFSET    = 0.0;
	LC_Y_OFFSET    = 0.0;

	RV_ZOOM_FACTOR = 0.0;
	RV_X_OFFSET    = 0.0;
	RV_Y_OFFSET    = 0.0;
	
	PHOEBE_lc_data = NULL;
	PHOEBE_rv_data = NULL;

	/* Create the main PHOEBE window and show it; we must not wait, because any */
	/* warning windows created later would be covered and the user might not    */
	/* see them.                                                                */
  PHOEBE = create_PHOEBE ();
  gtk_widget_show (PHOEBE);

	/* Assign a .phoebe configuration path to the PHOEBE_CONFIG variable:       */
	if (getenv ("HOME") == NULL)
		{
		warning_window = create_notice_window (
			"Environment entry not found",
			"Environment entry $HOME missing",
			"PHOEBE cannot find the environment entry HOME. Please set it to your",
			"home directory (e.g. set HOME=/home/your_name) and restart PHOEBE.",
			gtk_main_quit);
		}

	sprintf (USER_HOME_DIR, "%s", getenv ("HOME"));
	sprintf (PHOEBE_HOME_DIR, "%s/.phoebe", USER_HOME_DIR);
	sprintf (PHOEBE_CONFIG, "%s/phoebe.config", PHOEBE_HOME_DIR);

	if (file_exists (PHOEBE_CONFIG))
		{
		config_file = fopen (PHOEBE_CONFIG, "r");
		while (!feof (config_file))
			{
			fscanf (config_file, "%s", keyword_str);

			if (strcmp (keyword_str, "PHOEBE_BASE_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_BASE_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_SOURCE_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_SOURCE_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_SHARE_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_SHARE_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_TEMP_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_TEMP_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_DATA_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_DATA_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_LC_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_LC_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_DC_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_DC_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_PLOTTING_PACKAGE") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_PLOTTING_PACKAGE, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_PLOTTING_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_PLOTTING_DIR, "%s", working_str);
				}
			if (strcmp (keyword_str, "PHOEBE_LD_SWITCH") == 0)
				fscanf (config_file, "%d", &PHOEBE_LD_SWITCH);
			if (strcmp (keyword_str, "PHOEBE_LD_DIR") == 0)
				{
				fscanf (config_file, "%s", working_str);
				sprintf (PHOEBE_LD_DIR, "%s", working_str);
				}
			}
		fclose (config_file);
		}

	if (!file_exists (PHOEBE_CONFIG)) /* Config file is missing */
		{
		warning_window = create_warning_window (
			"PHOEBE Configuration File Missing",
			"Welcome to PHOEBE!",
			"Since there is no configuration file, I guess this is the first time you started PHOEBE.",
			"I am about to create a hidden PHOEBE configuration directory in your home directory. Is that OK?",
			on_warning_no_configuration_ok_button_clicked,
			gtk_main_quit);
		gtk_object_set_data (GTK_OBJECT (PHOEBE), "warning_window", warning_window);

		sprintf (PHOEBE_BASE_DIR, "/usr/local/lib/phoebe");
		sprintf (PHOEBE_SOURCE_DIR, "/usr/local/lib/phoebe/src");
		sprintf (PHOEBE_SHARE_DIR, "/usr/local/share/phoebe");
		sprintf (PHOEBE_TEMP_DIR, "/tmp");
		sprintf (PHOEBE_DATA_DIR, "%s/data", PHOEBE_BASE_DIR);
		sprintf (PHOEBE_LC_DIR, "/usr/local/bin");
		sprintf (PHOEBE_DC_DIR, "/usr/local/bin");
		sprintf (PHOEBE_PLOTTING_PACKAGE, "sm");
		sprintf (PHOEBE_PLOTTING_DIR, "/usr/local/bin");
		         PHOEBE_LD_SWITCH = 0;
		}

	/* We now set the pixmaps directories. These directories contain all PHOEBE */
	/* related pixmaps and they should be initialized through a config file. If */
	/* that file is missing, we try to set the pixmaps directories relatively.  */

	if (file_exists (PHOEBE_CONFIG))
		{
		/* Pixmaps (empty LC/RV/Chi2 plots, logos, ...):                            */
		sprintf (working_str, "%s/pixmaps", PHOEBE_SHARE_DIR);
	  add_pixmap_directory (working_str);

		/* Button Icons:                                                            */
		sprintf (working_str, "%s/icons", PHOEBE_BASE_DIR);
	  add_pixmap_directory (working_str);

		/* Temporary directory:                                                     */
		sprintf (working_str, "%s/", PHOEBE_TEMP_DIR);
		add_pixmap_directory (working_str);
		}
	else
		{
		/* Pixmaps (empty LC/RV/Chi2 plots, logos, ...):                            */
	  add_pixmap_directory ("../share/pixmaps/");

		/* Button Icons:                                                            */
	  add_pixmap_directory ("../icons/");

		/* Temporary directory:                                                     */
		add_pixmap_directory ("/tmp/");
		}

	/* Now that pixmaps directories are set, let's put the pixmaps that reside  */
	/* in ../icons/ directory manually to avoid problems when PHOEBE is started */
	/* for the first time:                                                      */
	readout_widget = lookup_widget (PHOEBE, "under_construction_pixmap");
	readout_widget = create_pixmap (PHOEBE, "under_construction.xpm");
  gtk_widget_ref (readout_widget);
  gtk_object_set_data_full (GTK_OBJECT (PHOEBE), "under_construction_pixmap", readout_widget, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (readout_widget);
  gtk_table_attach (GTK_TABLE (lookup_widget (PHOEBE, "orbit_table")), readout_widget, 1, 5, 17, 22, (GtkAttachOptions) (GTK_FILL), (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);

	if (file_exists (PHOEBE_CONFIG)) chdir (PHOEBE_DATA_DIR);
  PHOEBE_open_keyword_file     = create_PHOEBE_open_keyword_file ();
  PHOEBE_save_keyword_file     = create_PHOEBE_save_keyword_file ();
	PHOEBE_plot_to_file_selector = create_PHOEBE_plot_to_file_selector ();

	if (file_exists (PHOEBE_CONFIG)) chdir (PHOEBE_BASE_DIR);
  PHOEBE_open_data_file        = create_PHOEBE_open_data_file ();

  PHOEBE_calculate_grid        = create_PHOEBE_calculate_grid ();
	PHOEBE_calculate_grid_edit_parameters
	                             = create_PHOEBE_calculate_grid_edit_parameters ();

  PHOEBE_calculate_phsv        = create_PHOEBE_calculate_phsv ();
  PHOEBE_calculate_pcsv        = create_PHOEBE_calculate_pcsv ();

  PHOEBE_plot_lc               = create_PHOEBE_plot_lc ();
  PHOEBE_plot_rv               = create_PHOEBE_plot_rv ();
	PHOEBE_plot_to_file          = create_PHOEBE_plot_to_file ();
	PHOEBE_ld_interpolation      = create_PHOEBE_ld_interpolation ();
	PHOEBE_dc                    = create_PHOEBE_dc ();
	PHOEBE_dc_correlation_matrix = create_PHOEBE_dc_correlation_matrix ();
	PHOEBE_fitting_quickbar      = create_PHOEBE_fitting_quickbar ();

	PHOEBE_assign_data_file      = create_PHOEBE_assign_data_file ();
	PHOEBE_filter_menu           = create_PHOEBE_filter_menu ();
	PHOEBE_assign_el3            = create_PHOEBE_assign_el3 ();
	PHOEBE_assign_rv_data_file   = create_PHOEBE_assign_rv_data_file ();
	PHOEBE_assign_lc_luminosity  = create_PHOEBE_assign_lc_luminosity ();
	PHOEBE_assign_rv_luminosity  = create_PHOEBE_assign_rv_luminosity ();
	PHOEBE_assign_ld_monochromatic_lc
                               = create_PHOEBE_assign_ld_monochromatic_lc ();
	PHOEBE_assign_ld_monochromatic_rv
                               = create_PHOEBE_assign_ld_monochromatic_rv ();
	PHOEBE_assign_primary_spots  = create_PHOEBE_assign_primary_spots ();
	PHOEBE_assign_secondary_spots
	                             = create_PHOEBE_assign_secondary_spots ();
	PHOEBE_assign_weighting      = create_PHOEBE_assign_weighting ();
	PHOEBE_scripter              = create_PHOEBE_scripter ();

	/* GLADE has problems defining clist justifications, so we do it manually:  */
	set_clist_justifications ();

	if (file_exists (PHOEBE_CONFIG)) chdir (PHOEBE_BASE_DIR);
  PHOEBE_configuration        = create_PHOEBE_configuration ();
  PHOEBE_configuration_browse = create_PHOEBE_configuration_browse ();

	/* If LD interpolation switch is set on, set the interpolation button sen-  */
	/* sitive:                                                                  */
	readout_widget = lookup_widget (PHOEBE, "ld_vanhamme_interpolation");
	if (PHOEBE_LD_SWITCH == 0) gtk_widget_set_sensitive (readout_widget, FALSE);
	if (PHOEBE_LD_SWITCH == 1) gtk_widget_set_sensitive (readout_widget, TRUE);

	/* Create About window and change the version label to contain information  */
	/* given in PHOEBE_VERSION_NUMBER and PHOEBE_VERSION_DATE:                  */
	PHOEBE_about = create_PHOEBE_about ();
	readout_widget = lookup_widget (PHOEBE_about, "about_version_label");
	sprintf (working_str, "Version %s       %s", PHOEBE_VERSION_NUMBER, PHOEBE_VERSION_DATE);
	gtk_label_set_text (GTK_LABEL (readout_widget), working_str);

	print_to_status_bar ("PHOEBE Started...");
	}

int file_exists (char *file_name)
	{
	int return_value = 1;
	/* This function checks whether a file exists; if it does, it returns 1; if */
	/* not, it returns 0. Thus we use it like this:                             */
  /*                                                                          */
	/*   if (file_exists ("some_file"))  or  if (! file_exists ("some_file"))   */
  /*                                                                          */
	FILE *test_file = fopen (file_name, "r+");
	
	if (test_file != NULL) fclose (test_file);
		else return_value = 0;

	return return_value;
	}

void strip_string_tail (char *in)
	{
	in[strlen(in)-1] = '\0';
	return;
	}

void print_to_status_bar (char *text)
	{
	GtkWidget *status_bar = lookup_widget (PHOEBE, "status_bar");

	char outtext_string[255];
	char *outtext_str = outtext_string;

	sprintf (outtext_str, " %s", text);
	gtk_statusbar_push (GTK_STATUSBAR (status_bar), 1, outtext_str);
	}

GtkWidget *create_warning_window (char *title, char *main_label, char *description1, char *description2, GtkSignalFunc ok_function, GtkSignalFunc cancel_function)
	{
  GtkWidget *warning_window;
  GtkWidget *warning_window_vbox;
  GtkWidget *warning_window_frame;
  GtkWidget *warning_window_table;
  GtkWidget *warning_window_main_label;
  GtkWidget *warning_window_description_line_1;
  GtkWidget *warning_window_separator;
  GtkWidget *warning_window_description_line_2;
  GtkWidget *warning_window_button_box;
  GtkWidget *warning_window_ok_button;
  GtkWidget *warning_window_cancel_button;

  warning_window = gtk_window_new (GTK_WINDOW_DIALOG);
  gtk_object_set_data (GTK_OBJECT (warning_window), "warning_window", warning_window);
  gtk_window_set_title (GTK_WINDOW (warning_window), title);
  gtk_window_set_position (GTK_WINDOW (warning_window), GTK_WIN_POS_CENTER);

  warning_window_vbox = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (warning_window_vbox);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_vbox", warning_window_vbox, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_vbox);
  gtk_container_add (GTK_CONTAINER (warning_window), warning_window_vbox);

  warning_window_frame = gtk_frame_new (NULL);
  gtk_widget_ref (warning_window_frame);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_frame", warning_window_frame, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_frame);
  gtk_box_pack_start (GTK_BOX (warning_window_vbox), warning_window_frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_frame), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (warning_window_frame), GTK_SHADOW_IN);

  warning_window_table = gtk_table_new (4, 3, TRUE);
  gtk_widget_ref (warning_window_table);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_table", warning_window_table, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_table);
  gtk_container_add (GTK_CONTAINER (warning_window_frame), warning_window_table);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_table), 5);

  warning_window_main_label = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_main_label), main_label);
  gtk_widget_ref (warning_window_main_label);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_main_label", warning_window_main_label, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_main_label);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_main_label, 0, 3, 0, 1, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_main_label), 0.0, 0.5);

  warning_window_description_line_1 = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_description_line_1), description1);
  gtk_widget_ref (warning_window_description_line_1);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_description_line_1", warning_window_description_line_1, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_description_line_1);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_description_line_1, 0, 3, 2, 3, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_description_line_1), 0.0, 0.5);
  gtk_misc_set_padding (GTK_MISC (warning_window_description_line_1), 10, 0);

  warning_window_separator = gtk_hseparator_new ();
  gtk_widget_ref (warning_window_separator);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_separator", warning_window_separator, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_separator);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_separator, 0, 3, 1, 2, (GtkAttachOptions) (GTK_FILL), (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);

  warning_window_description_line_2 = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_description_line_2), description2);
  gtk_widget_ref (warning_window_description_line_2);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_description_line_2", warning_window_description_line_2, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_description_line_2);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_description_line_2, 0, 3, 3, 4, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_description_line_2), 0.0, 0.5);

  warning_window_button_box = gtk_hbox_new (TRUE, 5);
  gtk_widget_ref (warning_window_button_box);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_button_box", warning_window_button_box, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_button_box);
  gtk_box_pack_start (GTK_BOX (warning_window_vbox), warning_window_button_box, FALSE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_button_box), 5);

  warning_window_ok_button = gtk_button_new_with_label ("OK");
  gtk_widget_ref (warning_window_ok_button);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_ok_button", warning_window_ok_button, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_ok_button);
  gtk_box_pack_start (GTK_BOX (warning_window_button_box), warning_window_ok_button, FALSE, TRUE, 0);
  gtk_signal_connect_object (GTK_OBJECT (warning_window_ok_button), "clicked", GTK_SIGNAL_FUNC (ok_function), GTK_OBJECT (warning_window));

  warning_window_cancel_button = gtk_button_new_with_label ("Cancel");
  gtk_widget_ref (warning_window_cancel_button);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_cancel_button", warning_window_cancel_button, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_cancel_button);
  gtk_box_pack_start (GTK_BOX (warning_window_button_box), warning_window_cancel_button, FALSE, TRUE, 0);
  gtk_signal_connect_object (GTK_OBJECT (warning_window_cancel_button), "clicked", GTK_SIGNAL_FUNC (cancel_function), GTK_OBJECT (warning_window));

	gtk_object_set_data (GTK_OBJECT (PHOEBE), "warning_window", warning_window);
	gtk_widget_show (warning_window);

	return warning_window;
	}

GtkWidget *create_notice_window (char *title, char *main_label, char *description1, char *description2, GtkSignalFunc ok_function)
	{
  GtkWidget *warning_window;
  GtkWidget *warning_window_vbox;
  GtkWidget *warning_window_frame;
  GtkWidget *warning_window_table;
  GtkWidget *warning_window_main_label;
  GtkWidget *warning_window_description_line_1;
  GtkWidget *warning_window_separator;
  GtkWidget *warning_window_description_line_2;
  GtkWidget *warning_window_ok_button;

  warning_window = gtk_window_new (GTK_WINDOW_DIALOG);
  gtk_object_set_data (GTK_OBJECT (warning_window), "warning_window", warning_window);
  gtk_window_set_title (GTK_WINDOW (warning_window), title);
  gtk_window_set_position (GTK_WINDOW (warning_window), GTK_WIN_POS_CENTER);

  warning_window_vbox = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (warning_window_vbox);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_vbox", warning_window_vbox, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_vbox);
  gtk_container_add (GTK_CONTAINER (warning_window), warning_window_vbox);

  warning_window_frame = gtk_frame_new (NULL);
  gtk_widget_ref (warning_window_frame);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_frame", warning_window_frame, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_frame);
  gtk_box_pack_start (GTK_BOX (warning_window_vbox), warning_window_frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_frame), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (warning_window_frame), GTK_SHADOW_IN);

  warning_window_table = gtk_table_new (4, 3, TRUE);
  gtk_widget_ref (warning_window_table);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_table", warning_window_table, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_table);
  gtk_container_add (GTK_CONTAINER (warning_window_frame), warning_window_table);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_table), 5);

  warning_window_main_label = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_main_label), main_label);
  gtk_widget_ref (warning_window_main_label);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_main_label", warning_window_main_label, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_main_label);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_main_label, 0, 3, 0, 1, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_main_label), 0.0, 0.5);

  warning_window_description_line_1 = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_description_line_1), description1);
  gtk_widget_ref (warning_window_description_line_1);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_description_line_1", warning_window_description_line_1, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_description_line_1);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_description_line_1, 0, 3, 2, 3, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_description_line_1), 0.0, 0.5);
  gtk_misc_set_padding (GTK_MISC (warning_window_description_line_1), 10, 0);

  warning_window_separator = gtk_hseparator_new ();
  gtk_widget_ref (warning_window_separator);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_separator", warning_window_separator, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_separator);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_separator, 0, 3, 1, 2, (GtkAttachOptions) (GTK_FILL), (GtkAttachOptions) (GTK_EXPAND | GTK_FILL), 0, 0);

  warning_window_description_line_2 = gtk_label_new ("");
  gtk_label_parse_uline (GTK_LABEL (warning_window_description_line_2), description2);
  gtk_widget_ref (warning_window_description_line_2);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_description_line_2", warning_window_description_line_2, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_description_line_2);
  gtk_table_attach (GTK_TABLE (warning_window_table), warning_window_description_line_2, 0, 3, 3, 4, (GtkAttachOptions) (GTK_EXPAND), (GtkAttachOptions) (0), 0, 0);
  gtk_misc_set_alignment (GTK_MISC (warning_window_description_line_2), 0.0, 0.5);

  warning_window_ok_button = gtk_button_new_with_label ("OK");
  gtk_widget_ref (warning_window_ok_button);
  gtk_object_set_data_full (GTK_OBJECT (warning_window), "warning_window_ok_button", warning_window_ok_button, (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (warning_window_ok_button);
  gtk_box_pack_start (GTK_BOX (warning_window_vbox), warning_window_ok_button, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_ok_button), 5);
  gtk_signal_connect_object (GTK_OBJECT (warning_window_ok_button), "clicked", GTK_SIGNAL_FUNC (ok_function), GTK_OBJECT (warning_window));

	gtk_object_set_data (GTK_OBJECT (PHOEBE), "warning_window", warning_window);
	gtk_widget_show (warning_window);

	return warning_window;
	}

void set_clist_justifications ()
	{
	/* GLADE has problems defining the column justification for CList widgets,  */
	/* so we have to do it here manually:                                       */
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), 1, GTK_JUSTIFY_LEFT);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), 3, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), 1, GTK_JUSTIFY_LEFT);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), 3, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list")), 3, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list")), 4, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_chi2_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_chi2_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_chi2_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_chi2_info_list")), 3, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), 2, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), 2, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), 1, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), 3, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), 4, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), 3, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), 4, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_weighting_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_weighting_info_list")), 1, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_scripter, "scripter_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_scripter, "scripter_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE_scripter, "scripter_info_list")), 2, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_primary_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_primary_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_primary_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_primary_info_list")), 3, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_primary_info_list")), 4, GTK_JUSTIFY_CENTER);

	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_secondary_info_list")), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_secondary_info_list")), 1, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_secondary_info_list")), 2, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_secondary_info_list")), 3, GTK_JUSTIFY_CENTER);
	gtk_clist_set_column_justification (GTK_CLIST (lookup_widget (PHOEBE, "spots_secondary_info_list")), 4, GTK_JUSTIFY_CENTER);

	return;
	}

void add_empty_record_to_all_lc_dependent_info_lists ()
	{
	add_empty_record_to_lc_info_list ();
	add_empty_record_to_luminosities_lc_info_list ();
	add_empty_record_to_luminosities_el3_info_list ();
	add_empty_record_to_ld_monochromatic_lc_info_list ();
	add_empty_record_to_luminosities_weighting_info_list ();
	}

void add_empty_record_to_all_rv_dependent_info_lists ()
	{
	add_empty_record_to_rv_info_list ();
	add_empty_record_to_luminosities_rv_info_list ();
	add_empty_record_to_ld_monochromatic_rv_info_list ();
	}

void add_empty_record_to_lc_info_list ()
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "data_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rows_already_present = GTK_CLIST (lc_list)->rows;
	int i;

	char entry_string[4][255];
	char *entry[4] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3]};

	/* If lc_no is greater than 0, Edit button should be available: */
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "data_lc_edit_data_entry_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "data_lc_edit_data_entry_button"), FALSE);

	if (lc_no < rows_already_present)
		{
		for (i = rows_already_present; i > lc_no; i--)
			gtk_clist_remove (GTK_CLIST (lc_list), i-1);
		}

	if (lc_no > rows_already_present)
		for (i = rows_already_present; i < lc_no; i++)
			{
			sprintf (entry[0], "%d.", i+1);
			sprintf (entry[1], "Undefined");
			sprintf (entry[2], "0.00000");
			sprintf (entry[3], "Undefined");

			sprintf (PHOEBE_lc_data[i].column1,  "Phase");
			sprintf (PHOEBE_lc_data[i].column2,  "Magnitude");
			sprintf (PHOEBE_lc_data[i].column3,  "Weight (int)");
			sprintf (PHOEBE_lc_data[i].filename, "Undefined");
			sprintf (PHOEBE_lc_data[i].sigma,    "0.00000");
			sprintf (PHOEBE_lc_data[i].filter,   "Undefined");

			gtk_clist_append (GTK_CLIST (lc_list), entry);
			}
	}

void add_empty_record_to_rv_info_list (GtkEditable *editable, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "data_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	int rows_already_present = GTK_CLIST (rv_list)->rows;
	int i;

	char entry_string[4][255];
	char *entry[4] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3]};

	/* If rv_no is greater than 0, Edit button should be available: */
	if (rv_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "data_rv_edit_data_entry_button"), TRUE);
	if (rv_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "data_rv_edit_data_entry_button"), FALSE);

	if (rv_no < rows_already_present)
		{
		for (i = rows_already_present; i > rv_no; i--)
			gtk_clist_remove (GTK_CLIST (rv_list), i-1);
		}

	if (rv_no > rows_already_present)
		for (i = rows_already_present; i < rv_no; i++)
			{
			sprintf (entry[0], "%d.", i+1);
			sprintf (entry[1], "Undefined");
			sprintf (entry[2], "0.00000");
			sprintf (entry[3], "Undefined");

			sprintf (PHOEBE_rv_data[i].column1,  "Phase");
			sprintf (PHOEBE_rv_data[i].column2,  "RV in km/s");
			sprintf (PHOEBE_rv_data[i].column3,  "Weight (int)");
			sprintf (PHOEBE_rv_data[i].filename, "Undefined");
			sprintf (PHOEBE_rv_data[i].sigma,    "0.00000");
			sprintf (PHOEBE_rv_data[i].filter,   "Undefined");

			gtk_clist_append (GTK_CLIST (rv_list), entry);
			}
	}

void add_empty_record_to_luminosities_lc_info_list ()
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rows_already_present = GTK_CLIST (lc_list)->rows;

	char entry_string[3][20];
	char *entry[3] = {entry_string[0], entry_string[1], entry_string[2]};

	int i;

	/* If lc_no is greater than 0, Edit button should be available: */
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_lc_edit_entry_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_lc_edit_entry_button"), FALSE);

	if (lc_no < rows_already_present)
		{
		for (i = rows_already_present; i > lc_no; i--)
			gtk_clist_remove (GTK_CLIST (lc_list), i-1);
		}

	if (lc_no > rows_already_present)
		for (i = rows_already_present; i < lc_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_lc_data[i].filter);
			sprintf (entry[1], "10.00000");
			sprintf (entry[2], "10.00000");

			gtk_clist_append (GTK_CLIST (lc_list), entry);
			}
	}

void add_empty_record_to_luminosities_rv_info_list ()
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "luminosities_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	int rows_already_present = GTK_CLIST (rv_list)->rows;

	char entry_string[3][20];
	char *entry[3] = {entry_string[0], entry_string[1], entry_string[2]};

	int i;

	/* If rv_no is greater than 0, Edit button should be available: */
	if (rv_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_rv_edit_entry_button"), TRUE);
	if (rv_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_rv_edit_entry_button"), FALSE);

	if (rv_no < rows_already_present)
		{
		for (i = rows_already_present; i > rv_no; i--)
			gtk_clist_remove (GTK_CLIST (rv_list), i-1);
		}

	if (rv_no > rows_already_present)
		for (i = rows_already_present; i < rv_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_rv_data[i].filter);
			sprintf (entry[1], "10.00000");
			sprintf (entry[2], "10.00000");

			gtk_clist_append (GTK_CLIST (rv_list), entry);
			}
	}

void add_empty_record_to_luminosities_el3_info_list ()
	{
	GtkWidget *el3_list = lookup_widget (PHOEBE, "luminosities_el3_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rows_already_present = GTK_CLIST (el3_list)->rows;

	char entry_string[2][20];
	char *entry[2] = {entry_string[0], entry_string[1]};

	int i;

	/* If lc_no is greater than 0, Edit button should be available: */
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_el3_edit_entry_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_el3_edit_entry_button"), FALSE);

	if (lc_no < rows_already_present)
		{
		for (i = rows_already_present; i > lc_no; i--)
			gtk_clist_remove (GTK_CLIST (el3_list), i-1);
		}

	if (lc_no > rows_already_present)
		for (i = rows_already_present; i < lc_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_lc_data[i].filter);
			sprintf (entry[1], "0.00000");

			gtk_clist_append (GTK_CLIST (el3_list), entry);
			}
	}

void add_empty_record_to_ld_monochromatic_lc_info_list ()
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rows_already_present = GTK_CLIST (ld_list)->rows;

	char entry_string[5][20];
	char *entry[5] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4]};

	int i;

	/* If lc_no is greater than 0, Edit button should be available: */
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_monochromatic_lc_edit_entry_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_monochromatic_lc_edit_entry_button"), FALSE);

	if (lc_no < rows_already_present)
		{
		for (i = rows_already_present; i > lc_no; i--)
			gtk_clist_remove (GTK_CLIST (ld_list), i-1);
		}

	if (lc_no > rows_already_present)
		for (i = rows_already_present; i < lc_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_lc_data[i].filter);
			sprintf (entry[1], "1.00000");
			sprintf (entry[2], "1.00000");
			sprintf (entry[3], "1.00000");
			sprintf (entry[4], "1.00000");

			gtk_clist_append (GTK_CLIST (ld_list), entry);
			}
	}

void add_empty_record_to_ld_monochromatic_rv_info_list ()
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	int rows_already_present = GTK_CLIST (ld_list)->rows;

	char entry_string[5][20];
	char *entry[5] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4]};

	int i;

	/* If rv_no is greater than 0, Edit button should be available: */
	if (rv_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_monochromatic_rv_edit_entry_button"), TRUE);
	if (rv_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_monochromatic_rv_edit_entry_button"), FALSE);

	if (rv_no < rows_already_present)
		{
		for (i = rows_already_present; i > rv_no; i--)
			gtk_clist_remove (GTK_CLIST (ld_list), i-1);
		}

	if (rv_no > rows_already_present)
		for (i = rows_already_present; i < rv_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_rv_data[i].filter);
			sprintf (entry[1], "1.00000");
			sprintf (entry[2], "1.00000");
			sprintf (entry[3], "1.00000");
			sprintf (entry[4], "1.00000");

			gtk_clist_append (GTK_CLIST (ld_list), entry);
			}
	}

void add_empty_record_to_luminosities_weighting_info_list ()
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "luminosities_weighting_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rows_already_present = GTK_CLIST (w_list)->rows;

	char entry_string[2][20];
	char *entry[2] = {entry_string[0], entry_string[1]};

	int i;

	/* If lc_no is greater than 0, Edit button should be available: */
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_weighting_edit_entry_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "luminosities_weighting_edit_entry_button"), FALSE);

	if (lc_no < rows_already_present)
		{
		for (i = rows_already_present; i > lc_no; i--)
			gtk_clist_remove (GTK_CLIST (w_list), i-1);
		}

	if (lc_no > rows_already_present)
		for (i = rows_already_present; i < lc_no; i++)
			{
			sprintf (entry[0], "%s", PHOEBE_lc_data[i].filter);
			sprintf (entry[1], "No Level-Dependent Weighting");

			gtk_clist_append (GTK_CLIST (w_list), entry);
			}
	}

void add_empty_record_to_spots_primary_info_list ()
	{
	GtkWidget *sp_list = lookup_widget (PHOEBE, "spots_primary_info_list");
	int sp_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "spots_sprim_value")));
	int rows_already_present = GTK_CLIST (sp_list)->rows;
	int i;

	char entry_string[5][255];
	char *entry[5] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4]};

	/* If sp_no is greater than 0, Edit button should be available: */
	if (sp_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "spots_edit_primary_button"), TRUE);
	if (sp_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "spots_edit_primary_button"), FALSE);

	if (sp_no < rows_already_present)
		{
		for (i = rows_already_present; i > sp_no; i--)
			gtk_clist_remove (GTK_CLIST (sp_list), i-1);
		}

	if (sp_no > rows_already_present)
		for (i = rows_already_present; i < sp_no; i++)
			{
			sprintf (entry[0], "%d.", i+1);
			sprintf (entry[1], "0.00000");
			sprintf (entry[2], "0.00000");
			sprintf (entry[3], "0.00000");
			sprintf (entry[4], "1.00000");

			gtk_clist_append (GTK_CLIST (sp_list), entry);
			}
	}

void add_empty_record_to_spots_secondary_info_list ()
	{
	GtkWidget *sp_list = lookup_widget (PHOEBE, "spots_secondary_info_list");
	int sp_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "spots_ssec_value")));
	int rows_already_present = GTK_CLIST (sp_list)->rows;
	int i;

	char entry_string[5][255];
	char *entry[5] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4]};

	/* If sp_no is greater than 0, Edit button should be available: */
	if (sp_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "spots_edit_secondary_button"), TRUE);
	if (sp_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "spots_edit_secondary_button"), FALSE);

	if (sp_no < rows_already_present)
		{
		for (i = rows_already_present; i > sp_no; i--)
			gtk_clist_remove (GTK_CLIST (sp_list), i-1);
		}

	if (sp_no > rows_already_present)
		for (i = rows_already_present; i < sp_no; i++)
			{
			sprintf (entry[0], "%d.", i+1);
			sprintf (entry[1], "0.00000");
			sprintf (entry[2], "0.00000");
			sprintf (entry[3], "0.00000");
			sprintf (entry[4], "0.00000");

			gtk_clist_append (GTK_CLIST (sp_list), entry);
			}
	}

void add_filters_to_available_filter_lists ()
	{
	/* This function is used to set all filter lists with one call from call-   */
	/* backs routines. This way, when adding available filter lists, we must    */
	/* change only this routine, everything else remains intact.                */

	add_filters_to_lc_plot_filter_list ();
	add_filters_to_rv_plot_filter_list ();
	add_filters_to_chi2_filter_list ();
	add_filters_to_ld_filter_list ();
	}

void add_filters_to_lc_plot_filter_list ()
	{
	/* This function fills the LC plotting combo box with filters that have     */
	/* been selected in a PHOEBE CList. */

	GtkWidget *filter_box = lookup_widget (PHOEBE_plot_lc, "plot_lc_data_combo_box");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	GtkWidget *new_item;
	int i;
	int modified = 0;

	if (lc_no == 0) return;

  gtk_list_clear_items (GTK_LIST (GTK_COMBO (filter_box)->list), 0, -1);

	for (i = 0; i < lc_no; i++)
		{
		if (strcmp (PHOEBE_lc_data[i].filter, "Undefined") != 0)
			{
			modified = 1;
			new_item = gtk_list_item_new_with_label (PHOEBE_lc_data[i].filter);
			gtk_widget_show (new_item);
			gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
			}
		}

	/* We don't want to have an empty combo box, so if there are no filters de- */
	/* fined, let's have a "None Specified" entry.                              */
	if (modified == 0)
		{
		new_item = gtk_list_item_new_with_label ("None Specified");
		gtk_widget_show (new_item);
		gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
		}

	return;
	}

void add_filters_to_rv_plot_filter_list ()
	{
	/* This function fills the RV plotting combo box with filters that have     */
	/* been selected in a PHOEBE CList. */

	GtkWidget *filter_box = lookup_widget (PHOEBE_plot_rv, "plot_rv_data_combo_box");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	GtkWidget *new_item;
	int i;
	int modified = 0;

	if (rv_no == 0) return;

  gtk_list_clear_items (GTK_LIST (GTK_COMBO (filter_box)->list), 0, -1);

	for (i = 0; i < rv_no; i++)
		{
		if (strcmp (PHOEBE_rv_data[i].filter, "Undefined") != 0)
			{
			modified = 1;
			new_item = gtk_list_item_new_with_label (PHOEBE_rv_data[i].filter);
			gtk_widget_show (new_item);
			gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
			}
		}

	/* We don't want to have an empty combo box, so if there are no filters de- */
	/* fined, let's have a "None Specified" entry.                              */
	if (modified == 0)
		{
		new_item = gtk_list_item_new_with_label ("None Specified");
		gtk_widget_show (new_item);
		gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
		}

	return;
	}

void add_filters_to_chi2_filter_list ()
	{
	GtkWidget *filter_box = lookup_widget (PHOEBE, "fitting_chi2_filter");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	GtkWidget *new_item;
	int i;
	int modified = 0;

	if (lc_no == 0) return;

  gtk_list_clear_items (GTK_LIST (GTK_COMBO (filter_box)->list), 0, -1);

	for (i = 0; i < lc_no; i++)
		{
		if (strcmp (PHOEBE_lc_data[i].filter, "Undefined") != 0)
			{
			modified = 1;
			new_item = gtk_list_item_new_with_label (PHOEBE_lc_data[i].filter);
			gtk_widget_show (new_item);
			gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
			}
		}

	/* We don't want to have an empty combo box, so if there are no filters de- */
	/* fined, let's have an undefined entry. */
	if (modified == 0)
		{
		new_item = gtk_list_item_new_with_label ("Filter: None Specified");
		gtk_widget_show (new_item);
		gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
		}

	return;
	}

void add_filters_to_ld_filter_list ()
	{
	/* This function adds filter names that have been assigned at PHOEBE's LC   */
	/* CList widget and puts them to ld_interpolation combo box.                */

	GtkWidget *filter_box = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_filter_box");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	GtkWidget *new_item;
	int i;

  gtk_list_clear_items (GTK_LIST (GTK_COMBO (filter_box)->list), 0, -1);

	/* We always want to have "bolometric" entry in the box:                    */
	new_item = gtk_list_item_new_with_label ("Bolometric");
	gtk_widget_show (new_item);
	gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);

	for (i = 0; i < lc_no; i++)
		{
		if (strcmp (PHOEBE_lc_data[i].filter, "Undefined") != 0)
			{
			new_item = gtk_list_item_new_with_label (PHOEBE_lc_data[i].filter);
			gtk_widget_show (new_item);
			gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
			}
		}
	for (i = 0; i < rv_no; i++)
		{
		if (strcmp (PHOEBE_rv_data[i].filter, "Undefined") != 0)
			{
			new_item = gtk_list_item_new_with_label (PHOEBE_rv_data[i].filter);
			gtk_widget_show (new_item);
			gtk_container_add (GTK_CONTAINER (GTK_COMBO (filter_box)->list), new_item);
			}
		}

	return;
	}
