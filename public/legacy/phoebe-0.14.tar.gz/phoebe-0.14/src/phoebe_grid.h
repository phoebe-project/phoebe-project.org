#ifndef PHOEBE_GRID_H
#define PHOEBE_GRID_H 1

char *calculate_estimated_synthetic_grid_file_size (int params_no, int nodes_no, int vertexes_no, int filters_no, char **size_str);

#endif
