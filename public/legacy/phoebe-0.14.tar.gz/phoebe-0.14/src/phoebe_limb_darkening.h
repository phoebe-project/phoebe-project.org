#include "phoebe_global.h"

PHOEBE_data read_in_ld_coeficients (char *input_filter, int T, double lg, double M, int ld_law);
PHOEBE_data interpolate_from_ld_tables (char *input_filter, int T, double lg, double M, int ld_law);
