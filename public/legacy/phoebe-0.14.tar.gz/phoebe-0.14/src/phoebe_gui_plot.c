#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "phoebe_allocations.h"
#include "phoebe_binning.h"
#include "phoebe_chi2.h"
#include "phoebe_error_handling.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_callbacks.h"
#include "phoebe_gui_support.h"
#include "phoebe_gui_plot.h"
#include "phoebe_plot.h"
#include "phoebe_transformations.h"

void plot_lc_plot (PHOEBE_plot_device device, char *filename)
	{
	int i;

	new_PHOEBE_data synthetic_data;
	new_PHOEBE_data experimental_data;

	PHOEBE_main_parameters   main      = read_in_main_parameters ();
	PHOEBE_switches          switches  = read_in_switches ();
	PHOEBE_limb_darkening    ld        = read_in_ld_coefficients ();
	PHOEBE_spots             spots     = read_in_spots ();
	PHOEBE_curve_parameters  curve     = read_in_curve_parameters ();

	PHOEBE_wl_dependent_parameters mono;
	PHOEBE_calculated_parameters params;

	GtkWidget *readout_widget;
	GtkWidget *warning_window;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	int VERTEXES;

	int chosen_filter;

	int INDEP;     /* This switch determines the independent variable:          */
                 /*   INDEP = 1 .. heliocentric julian date                   */
                 /*   INDEP = 2 .. phase                                      */

	int DEP;       /* This switch determines the dependent variable:            */
                 /*   DEP = 3 .. normalized primary star flux                 */
                 /*   DEP = 4 .. normalized secondary star flux               */
                 /*   DEP = 5 .. normalized total flux (from both stars)      */
                 /*   DEP = 6 .. FACTORed total flux (from both stars)        */
                 /*   DEP = 8 .. MZEROed total magnitude (from both stars)    */
                 /*   DEP = 9 .. light curve residuals                        */

	int BOX;       /* This switch determines how does SuperMongo limit plots:   */
                 /*   BOX = 0 .. draw ticked axes (x and y)                   */
                 /*   BOX = 1 .. draw ticked box                              */

	int GRID;      /* This switch determines what kind of gridding is used:     */
                 /*   GRID = 0 .. no gridding                                 */
                 /*   GRID = 1 .. coarse grid                                 */
                 /*   GRID = 2 .. fine grid                                   */

	int DATA;      /* This switch determines whether the user wants to plot ex- */
	               /* perimental data:                                          */
                 /*   DATA = 0 .. do not plot experimental data               */
                 /*   DATA = 1 .. plot experimental data                      */

	int MODEL;     /* This switch determines whether the user wants to plot     */
	               /* synthetic data:                                           */
                 /*   MODEL = 0 .. do not plot synthetic data                 */
                 /*   MODEL = 1 .. plot synthetic data                        */

	int ALIASING;  /* This switch determines if the phases are to be aliased to */
                 /* a wider/narrower range or not.                            */
								 /*   ALIASING = 0 .. don't use aliasing, always [-0.5, 0.5]  */
                 /*   ALIASING = 1 .. use aliasing to [PHSTRT, PHSTOP].       */

	int RESIDUALS; /* This switch determines whether the plot should contain    */
                 /* overlapped synthetic and experimental data or should it   */
								 /* calculate residuals and plot them against INDEP:          */
								 /*   RESIDUALS = 0 .. don't calculate/plot residuals         */
								 /*   RESIDUALS = 1 .. calculate/plot residuals               */

	int REDDENING; /* This switch determines if the reddening/extinction effect */
                 /* should be compensated for input magnitudes:               */
								 /*   REDDENING = 0 .. don't remove reddening from input data */
								 /*   REDDENING = 1 .. remove reddening from input data       */

	double SEED, STDDEV;

	double chi2 = 0.0;

	/* We want to plot LCs, so we set MPAGE to 1: */
	switches.MPAGE = 1;

	/* The filter name combo box contains either the name of the chosen filter  */
	/* or the "None Specified" entry. If the filter name is defined, we have to */
	/* initialize the wavelength-dependent parameters based on that filter for  */
	/* synthetic LC generation. If not, we assume the default values.           */
	i = 0;
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_data_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "None Specified") == 0) chosen_filter = -1;
	else
		{
		while (strcmp (readout_str, PHOEBE_lc_data[i].filter) != 0) i++;
		chosen_filter = i;
		}

	/* If the filter is not specified (chosen_filter == -1), we read in the de- */
	/* faults, else we read in filter-dependent parameters:                     */
	if (chosen_filter == -1)
		{
		mono.WLA   = 500.0;
		mono.HLA   = 10.0;
		mono.CLA   = 10.0;
		mono.X1A   = 0.5;
		mono.X2A   = 0.5;
		mono.Y1A   = 0.5;
		mono.Y2A   = 0.5;
		mono.EL3   = 0.0;
		mono.OPSF  = 0.0;
		mono.SIGMA = 0.0;
		}
	else mono = read_in_wl_dependent_parameters (readout_str);

	/* Read out the phase settings from LC Plot Window: */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_vertexes_value");
	VERTEXES = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phstrt_value");
	curve.PHSTRT = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phend_value");
	curve.PHSTOP = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	curve.PHIN = (curve.PHSTOP - curve.PHSTRT) / (VERTEXES - 1);
	curve.HJDST = main.HJD0 + main.PERIOD * curve.PHSTRT;
	curve.HJDSP = main.HJD0 + main.PERIOD * curve.PHSTOP;
	curve.HJDIN = main.PERIOD * curve.PHIN;

	/* Since there is no typedef'd support for synthetic noise (yet), we have   */
	/* to read in the values manually:                                          */
	readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_value");
		STDDEV = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
		readout_widget = lookup_widget (PHOEBE, "luminosities_seed_value");
		SEED = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
		}
	else
		{
		STDDEV = 0.0;
		SEED = 100000002.0;
		}

	/* What variable user chooses to be independent (time or phase): */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_independent_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Time") == 0)  { INDEP = 1; switches.JDPHS = 1; }
	if (strcmp (readout_str, "Phase") == 0) { INDEP = 2; switches.JDPHS = 2; }

	/* What variable user chooses to be dependent (flux or magnitude): */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_dependent_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Primary Star Flux") == 0)    DEP = 3;
	if (strcmp (readout_str, "Secondary Star Flux") == 0)  DEP = 4;
	if (strcmp (readout_str, "Total Flux") == 0)           DEP = 5;
	if (strcmp (readout_str, "Normalized Flux") == 0)      DEP = 6;
	if (strcmp (readout_str, "Magnitude") == 0)            DEP = 8;

	/* Do we want to have a gridded plot? If so, set GRID to 1 or 2:            */
	GRID = 0;
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_fine_gridlines");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) GRID = 2;
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_coarse_gridlines");
	if ( (GTK_TOGGLE_BUTTON (readout_widget)->active) && GRID != 2) GRID = 1;

	/* What kind of plot border would we like? Boxed or axes?                   */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_draw_box");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) BOX = 0;
	else BOX = 1;

	/* Do we want to plot experimental data?                                    */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_experimental_data");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) DATA = 1;
	else DATA = 0;

	/* Is the data switch turned on, but we have no input files?                */
	if ( (chosen_filter == -1) && (DATA == 1) )
		{
		warning_window = create_notice_window ("PHOEBE Notice", "Experimental data plot failure", "You should supply experimental data to PHOEBE in the", "main window's Data tab. Until then experimental data cannot be plotted.", gtk_widget_destroy);
		DATA = 0;
		}

	/* Do we want data aliasing:                                                */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_aliasing_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) ALIASING = 1;
	else ALIASING = 0;

	/* Do we want to plot residuals:                                            */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_residuals_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) RESIDUALS = 1;
	else RESIDUALS = 0;

	/* Do we want to remove reddening:                                          */
	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_reddening_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) REDDENING = 1;
	else REDDENING = 0;

	/* We don't want experimental data to be plotted against individual fluxes: */
	if ( (DEP == 3) || (DEP == 4) ) DATA = 0;

	/* Do we want to plot synthetic data?                                       */
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_synthetic_lightcurve");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) MODEL = 1;
	else MODEL = 0;

	if (MODEL == 1)
		{
		/* Now we have prepared everything and it is time to write the LCI file:  */
		create_lci_input_file ("phoebe_lc", main, switches, ld, spots, curve, mono, SEED, STDDEV);

		/* Let's call WD98's lc program on the created input file:                */
		i = scan_temporary_directory_for_lci_file_index ("phoebe_lc");
		sprintf (working_str, "%s/lc < %s/phoebe_lc_%03d.lci > %s/phoebe_lc_%03d.lco", PHOEBE_LC_DIR, PHOEBE_TEMP_DIR, i, PHOEBE_TEMP_DIR, i);
		system (working_str);

		/* Assign a filename to the current LCO process and read in the calcula-  */
		/* ted synthetic data and binary parameters:                              */
		i = scan_temporary_directory_for_lci_file_index ("phoebe_lc");
		sprintf (working_str, "%s/phoebe_lc_%03d.lco", PHOEBE_TEMP_DIR, i);
		if (DEP == 8)
			{
			read_in_synthetic_lc_data (working_str, &synthetic_data, &params, INDEP, 5);
			transform_flux_to_magnitude (&synthetic_data, main.MNORM);
			}
		else
			read_in_synthetic_lc_data (working_str, &synthetic_data, &params, INDEP, DEP);

		/* Write out the calculated parameters (radii, surface, ...) to the plot- */
		/* ting window:                                                           */
		plot_update_info (1, params);
		}

	if (DATA == 1)
		{
		/* If we want to plot experimental data, we will first read in the values */
		/* from a file according to indep and dep switches:                       */
		read_in_experimental_lc_data (chosen_filter, &experimental_data, INDEP, DEP);

		/* Remove the reddening if the user wishes:                               */
		if (REDDENING == 1) remove_reddening_from_data (&experimental_data, mono.WLA, switches.REDDENING_R, switches.REDDENING_E);

		/* If an error occured, ptsno value is 0. In that case we don't want any  */
		/* experimental data present in our work, otherwise we expect segfault.   */
		if (experimental_data.ptsno == 0)
			{
			free (experimental_data.indep);
			free (experimental_data.dep);
			free (experimental_data.weight);
			DATA = 0;
			}

		/* Write out the number of points to plotting status window: */
		readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_chi2_ptsno_value");
		sprintf (working_str, "%d", experimental_data.ptsno);
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);
		}

	/* If we plot both experimental and synthetic data, we can calculate chi2;  */
	/* if we plot residuals, we must prepare them here:                         */
	if ( (DATA == 1) && (MODEL == 1) )
		{
		chi2 = calculate_chi2 (synthetic_data, experimental_data, 1.0, 1);
		sprintf (working_str, "%lf", chi2);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_chi2_weighted_sigma_value");
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);

		chi2 = calculate_chi2 (synthetic_data, experimental_data, 1.0, 0);
		sprintf (working_str, "%lf", chi2);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_chi2_unweighted_sigma_value");
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);

		/* Now for the residuals; after this function, synthetic_data will hold   */
		/* only zeroes (for reference) and experimental_data will hold residuals: */
		if (RESIDUALS == 1)
			calculate_residuals (&synthetic_data, &experimental_data);
		}

	/* Finally, we must call aliasing function in the end, so that chi2 calcu-  */
	/* lation is performed only on non-aliased points:                          */
	if (DATA == 1)
		{
		/* If the phase range of the plot is narrower than [-0.5,0.5], we must    */
		/* crop the experimental data output. If the range is wider, we must ali- */
		/* as some points to the outside regions:                                 */
		if ( (ALIASING == 1) && (switches.JDPHS == 2 /* Phases */) )
			alias_phase_to_interval (&experimental_data, curve.PHSTRT, curve.PHSTOP);
		}

	/* Create a plot: */
	create_lc_plot_using_sm (device, filename, synthetic_data, experimental_data, INDEP, DEP, GRID, BOX, LC_X_OFFSET, LC_Y_OFFSET, LC_ZOOM_FACTOR, MODEL, DATA);

	/* Put a plot to the screen if device is x11: */
	if (device == x11)
		{
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_image_frame");
		sprintf (working_str, "phoebe_lc_%03d.xpm", scan_temporary_directory_for_lci_file_index ("phoebe_lc"));
		draw_image_to_screen (readout_widget, working_str);
		}

	/* Free all memory that we don't need anymore, but only the ones that were  */
	/* phoebe_malloc()ed:                                                       */
	if (MODEL == 1)
		{
		free (synthetic_data.indep);
		free (synthetic_data.dep);
		free (synthetic_data.weight);
		}
	if (DATA == 1)
		{
		free (experimental_data.indep);
		free (experimental_data.dep);
		free (experimental_data.weight);
		}
	}

void plot_rv_plot (PHOEBE_plot_device device, char *filename)
	{
	int i;

	new_PHOEBE_data synthetic_rv1_data;
	new_PHOEBE_data synthetic_rv2_data;
	new_PHOEBE_data experimental_rv1_data;
	new_PHOEBE_data experimental_rv2_data;

	/* This variable holds both RVs if DEP reflects it, otherwise NULL:         */
	new_PHOEBE_data joint_synthetic_data;
	new_PHOEBE_data joint_experimental_data;

	PHOEBE_main_parameters  main     = read_in_main_parameters ();
	PHOEBE_switches         switches = read_in_switches ();
	PHOEBE_limb_darkening   ld       = read_in_ld_coefficients ();
	PHOEBE_spots            spots    = read_in_spots ();
	PHOEBE_curve_parameters curve    = read_in_curve_parameters ();

	PHOEBE_wl_dependent_parameters mono;
	PHOEBE_calculated_parameters params;

	GtkWidget *readout_widget;
	GtkWidget *warning_window;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	int VERTEXES;

	int chosen_filter;

	int INDEP;     /* This switch determines the independent variable:          */
                 /*   INDEP = 1 .. heliocentric julian date                   */
                 /*   INDEP = 2 .. phase                                      */

	int DEP;       /* This switch determines the dependent variable:            */
                 /*   DEP = 3 .. normalized primary RV curve                  */
                 /*   DEP = 4 .. normalized secondary RV curve                */
                 /*   DEP = 5 .. primary star eclipse proximity corrections   */
                 /*   DEP = 6 .. secondary star eclipse proximity corrections */
                 /*   DEP = 7 .. primary RV curve in km/s                     */
                 /*   DEP = 8 .. secondary RV curve in km/s                   */
                 /*   DEP = 9 .. both RV curves in km/s                       */

	int BOX;       /* This switch determines how does SuperMongo limit plots:   */
                 /*   BOX = 0 .. draw ticked axes (x and y)                   */
                 /*   BOX = 1 .. draw ticked box                              */

	int GRID;      /* This switch determines what kind of gridding is used:     */
                 /*   GRID = 0 .. no gridding                                 */
                 /*   GRID = 1 .. coarse grid                                 */
                 /*   GRID = 2 .. fine grid                                   */

	int DATA;      /* This switch determines whether the user wants to plot ex- */
	               /* perimental data:                                          */
                 /*   DATA = 0 .. do not plot experimental data               */
                 /*   DATA = 1 .. plot experimental data                      */

	int MODEL;     /* This switch determines whether the user wants to plot     */
	               /* synthetic data:                                           */
                 /*   MODEL = 0 .. do not plot synthetic data                 */
                 /*   MODEL = 1 .. plot synthetic data                        */

	int ALIASING;  /* This switch determines if the phases are to be aliased to */
                 /* a wider/narrower range or not.                            */
								 /*   ALIASING = 0 .. don't use aliasing, always [-0.5, 0.5]  */
                 /*   ALIASING = 1 .. use aliasing to [PHSTRT, PHSTOP].       */

	double SEED, STDDEV;

	double chi2_rv1 = 0.0;
	double chi2_rv2 = 0.0;

	/* We want to plot RVs, so we set MPAGE to 2: */
	switches.MPAGE = 2;

	/* The filter name combo box contains either the name of the chosen filter  */
	/* or the "None Specified" entry. If the filter name is defined, we have to */
	/* initialize the wavelength-dependent parameters based on that filter for  */
	/* synthetic RV generation. If not, we assume the default values.           */
	i = 0;
	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_data_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "None Specified") == 0) chosen_filter = -1;
	else
		{
		while (strcmp (readout_str, PHOEBE_rv_data[i].filter) != 0) i++;
		chosen_filter = i;
		}

	/* If the filter is not specified (chosen_filter == -1), we read in the de- */
	/* faults, else we read in filter-dependent parameters:                     */
	if (chosen_filter == -1)
		{
		mono.WLA   = 500.0;
		mono.HLA   = 10.0;
		mono.CLA   = 10.0;
		mono.X1A   = 0.5;
		mono.X2A   = 0.5;
		mono.Y1A   = 0.5;
		mono.Y2A   = 0.5;
		mono.EL3   = 0.0;
		mono.OPSF  = 0.0;
		mono.SIGMA = 0.0;
		}
	else mono = read_in_wl_dependent_parameters (readout_str);

	/* Read out the phase settings from RV Plot Window:                         */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_vertexes_value");
	VERTEXES = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_phstrt_value");
	curve.PHSTRT = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_phend_value");
	curve.PHSTOP = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	curve.PHIN = (curve.PHSTOP - curve.PHSTRT) / (VERTEXES - 1);
	curve.HJDST = main.HJD0 + main.PERIOD * curve.PHSTRT;
	curve.HJDSP = main.HJD0 + main.PERIOD * curve.PHSTOP;
	curve.HJDIN = main.PERIOD * curve.PHIN;

	/* Since there is no typedef'd support for synthetic noise (yet), we have   */
	/* to read in the values manually:                                          */
	readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_value");
		STDDEV = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
		readout_widget = lookup_widget (PHOEBE, "luminosities_seed_value");
		SEED = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
		}
	else
		{
		STDDEV = 0.0;
		SEED = 100000002.0;
		}

	/* What variable the user chooses to be independent (time or phase): */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_independent_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Time") == 0)  { INDEP = 1; switches.JDPHS = 1; }
	if (strcmp (readout_str, "Phase") == 0) { INDEP = 2; switches.JDPHS = 2; }

	/* What variable user chooses to be dependent (flux or magnitude): */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_dependent_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Primary normalized RV") == 0)   DEP = 3;
	if (strcmp (readout_str, "Secondary normalized RV") == 0) DEP = 4;
	if (strcmp (readout_str, "Primary eclipse-proximity corrections") == 0) DEP = 5;
	if (strcmp (readout_str, "Secondary eclipse-proximity corrections") == 0) DEP = 6;
	if (strcmp (readout_str, "Primary RV in km/s") == 0)   DEP = 7;
	if (strcmp (readout_str, "Secondary RV in km/s") == 0)   DEP = 8;
	if (strcmp (readout_str, "Both RVs in km/s") == 0) DEP = 9;

	/* Do we want to have a gridded plot? If so, set GRID to 1 or 2:            */
	GRID = 0;
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_fine_gridlines");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) GRID = 2;
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_coarse_gridlines");
	if ( (GTK_TOGGLE_BUTTON (readout_widget)->active) && GRID != 2) GRID = 1;

	/* What kind of plot border would we like? Boxed or axes?                   */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_draw_box");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) BOX = 0;
	else BOX = 1;

	/* Do we want to plot experimental data?                                    */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_experimental_data");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) DATA = 1;
	else DATA = 0;

	/* Is the data switch turned on, but we have no input files?                */
	if ( (chosen_filter == -1) && (DATA == 1) )
		{
		warning_window = create_notice_window ("PHOEBE Notice", "Experimental data plot failure", "You should supply experimental data to PHOEBE in the", "main window's Data tab. Until then experimental data cannot be plotted.", gtk_widget_destroy);
		DATA = 0;
		}

	/* Do we want data aliasing:                                                */
	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_aliasing_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) ALIASING = 1;
	else ALIASING = 0;

	/* We don't want experimental data plotted with proximity corrections: */
	if ( (DEP == 5) || (DEP == 6) ) DATA = 0;

	/* Do we want to plot synthetic data?                                       */
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_synthetic_lightcurve");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) MODEL = 1;
	else MODEL = 0;

	if (MODEL == 1)
		{
		/* Now we have prepared everything and it is time to write the LCI file:  */
		create_lci_input_file ("phoebe_rv", main, switches, ld, spots, curve, mono, SEED, STDDEV);

		/* Let's call WD98's lc program on the created input file:                */
		i = scan_temporary_directory_for_lci_file_index ("phoebe_rv");
		sprintf (working_str, "%s/lc < %s/phoebe_rv_%03d.lci > %s/phoebe_rv_%03d.lco", PHOEBE_LC_DIR, PHOEBE_TEMP_DIR, i, PHOEBE_TEMP_DIR, i);
		system (working_str);

		/* Assign a filename to the current LCO process and read in the calcula-  */
		/* ted synthetic data and binary parameters:                              */
		i = scan_temporary_directory_for_lci_file_index ("phoebe_rv");
		sprintf (working_str, "%s/phoebe_rv_%03d.lco", PHOEBE_TEMP_DIR, i);
		if ( (DEP == 3) || (DEP == 5) || (DEP == 7) )
			read_in_synthetic_rv_data (working_str, &synthetic_rv1_data, &params, INDEP, DEP);
		if ( (DEP == 4) || (DEP == 6) || (DEP == 8) )
			read_in_synthetic_rv_data (working_str, &synthetic_rv2_data, &params, INDEP, DEP);
		if ( DEP == 9 )
			read_in_synthetic_rv_data (working_str, &joint_synthetic_data, &params, INDEP, DEP);

		/* Write out the calculated parameters (radii, surface, ...) to window:   */
		plot_update_info (2, params);
		}

	if (DATA == 1)
		{
		if ( ( DEP == 3 ) || ( DEP == 7 ) )
			{
			read_in_experimental_rv_data (chosen_filter, &experimental_rv1_data, INDEP, DEP, 1.0);

			/* If an error occured, ptsno value is 0. In that case we don't want    */
			/* any experimental data present in our work, otherwise we expect the   */
			/* program to segfault.                                                 */
			if (experimental_rv1_data.ptsno == 0)
				{
				free (experimental_rv1_data.indep);
				free (experimental_rv1_data.dep);
				free (experimental_rv1_data.weight);
				DATA = 0;
				}

			sprintf (working_str, "%d", experimental_rv1_data.ptsno);
			}

		if ( ( DEP == 4 ) || ( DEP == 8 ) )
			{
			read_in_experimental_rv_data (chosen_filter, &experimental_rv2_data, INDEP, DEP, 1.0);

			/* If an error occured, ptsno value is 0. In that case we don't want    */
			/* any experimental data present in our work, otherwise we expect the   */
			/* program to segfault.                                                 */
			if (experimental_rv2_data.ptsno == 0)
				{
				free (experimental_rv2_data.indep);
				free (experimental_rv2_data.dep);
				free (experimental_rv2_data.weight);
				DATA = 0;
				}

			sprintf (working_str, "%d", experimental_rv2_data.ptsno);
			}

		if ( DEP == 9 )
			{
			read_in_experimental_rv_data (0, &experimental_rv1_data, INDEP, DEP, 1.0);
			read_in_experimental_rv_data (1, &experimental_rv2_data, INDEP, DEP, 1.0);

			joint_experimental_data.ptsno = experimental_rv1_data.ptsno + experimental_rv2_data.ptsno;
			joint_experimental_data.indep = NULL; joint_experimental_data.dep = NULL; joint_experimental_data.weight = NULL;

			allocate_memory_for_data (&joint_experimental_data);
			
			for (i = 0; i < experimental_rv1_data.ptsno; i++)
				{
				joint_experimental_data.indep[i]  = experimental_rv1_data.indep[i];
				joint_experimental_data.dep[i]    = experimental_rv1_data.dep[i];
				joint_experimental_data.weight[i] = experimental_rv1_data.weight[i];
				}
			for (i = experimental_rv1_data.ptsno; i < experimental_rv1_data.ptsno + experimental_rv2_data.ptsno; i++)
				{
				joint_experimental_data.indep[i]  = experimental_rv2_data.indep[i-experimental_rv1_data.ptsno];
				joint_experimental_data.dep[i]    = experimental_rv2_data.dep[i-experimental_rv1_data.ptsno];
				joint_experimental_data.weight[i] = experimental_rv2_data.weight[i-experimental_rv1_data.ptsno];
				}
			sprintf (working_str, "%d", joint_experimental_data.ptsno);
			}

		readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_chi2_ptsno_value");
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);
		}

	/* If we plot both experimental and synthetic data, we can calculate chi2:  */
	if ( (DATA == 1) && (MODEL == 1) && (DEP != 5) && (DEP != 6 ) )
		{
		if ( DEP != 9 )
			{
			chi2_rv1 = chi2_rv2 = 0.0;
			if ( (DEP == 3) || (DEP == 7) )
				chi2_rv1 = calculate_chi2 (synthetic_rv1_data, experimental_rv1_data, 1.0, 1);
			if ( (DEP == 4) || (DEP == 8) )
				chi2_rv2 = calculate_chi2 (synthetic_rv2_data, experimental_rv2_data, 1.0, 1);
			sprintf (working_str, "%lf", chi2_rv1 + chi2_rv2);
			}
		if ( DEP == 9 )
			sprintf (working_str, "not implemented");

		readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_chi2_weighted_sigma_value");
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);

		if ( DEP != 9 )
			{
			chi2_rv1 = chi2_rv2 = 0.0;
			if ( (DEP == 3) || (DEP == 7) )
				chi2_rv1 = calculate_chi2 (synthetic_rv1_data, experimental_rv1_data, 1.0, 0);
			if ( (DEP == 4) || (DEP == 8) )
				chi2_rv2 = calculate_chi2 (synthetic_rv2_data, experimental_rv2_data, 1.0, 0);
			sprintf (working_str, "%lf", chi2_rv1 + chi2_rv2);
			}
		if ( DEP == 9 )
			sprintf (working_str, "not implemented");

		readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_chi2_unweighted_sigma_value");
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);
		}

	/* If the phase range of the plot is narrower than [-0.5,0.5], we must      */
	/* crop the experimental data output. If the range is wider, we must ali-   */
	/* as some points to the outside regions:                                   */
	if (DATA == 1)
		{
		if ( ( DEP == 3 ) || ( DEP == 7 ) )
			{
			if ( (ALIASING == 1) && (switches.JDPHS == 2 /* Phases */) )
				alias_phase_to_interval (&experimental_rv1_data, curve.PHSTRT, curve.PHSTOP);
			}
		if ( ( DEP == 4 ) || ( DEP == 8 ) )
			{
			if ( (ALIASING == 1) && (switches.JDPHS == 2 /* Phases */) )
				alias_phase_to_interval (&experimental_rv2_data, curve.PHSTRT, curve.PHSTOP);
			}
		if ( DEP == 9 )
			{
			if ( (ALIASING == 1) && (switches.JDPHS == 2) )
				{
				alias_phase_to_interval (&experimental_rv1_data, curve.PHSTRT, curve.PHSTOP);
				alias_phase_to_interval (&experimental_rv2_data, curve.PHSTRT, curve.PHSTOP);
				}
			}
		}

	/* Create a plot: */
	if ( ( DEP == 3 ) || ( DEP == 5 ) || ( DEP == 7 ) )
		create_rv_plot_using_sm (device, filename, synthetic_rv1_data, experimental_rv1_data, INDEP, DEP, GRID, BOX, RV_X_OFFSET, RV_Y_OFFSET, RV_ZOOM_FACTOR, MODEL, DATA);
	if ( ( DEP == 4 ) || ( DEP == 6 ) || ( DEP == 8 ) )
		create_rv_plot_using_sm (device, filename, synthetic_rv2_data, experimental_rv2_data, INDEP, DEP, GRID, BOX, RV_X_OFFSET, RV_Y_OFFSET, RV_ZOOM_FACTOR, MODEL, DATA);
	if ( DEP == 9 )
		create_rv_plot_using_sm (device, filename, joint_synthetic_data, joint_experimental_data, INDEP, DEP, GRID, BOX, RV_X_OFFSET, RV_Y_OFFSET, RV_ZOOM_FACTOR, MODEL, DATA);

	/* Put a plot to the screen, but only if device is x11: */
	if (device == x11)
		{
		readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_image_frame");
		sprintf (working_str, "phoebe_rv_%03d.xpm", scan_temporary_directory_for_lci_file_index ("phoebe_rv"));
		draw_image_to_screen (readout_widget, working_str);
		}

	/* Free all memory that we don't need anymore, but only the ones that were  */
	/* phoebe_malloc()ed:                                                       */
	if ( (DEP == 3) || (DEP == 5) || (DEP == 7) )
		{
		if ( MODEL == 1 )
			{
			free (synthetic_rv1_data.indep);
			free (synthetic_rv1_data.dep);
			free (synthetic_rv1_data.weight);
			}
		if ( DATA == 1 )
			{
			free (experimental_rv1_data.indep);
			free (experimental_rv1_data.dep);
			free (experimental_rv1_data.weight);
			}
		}
	if ( (DEP == 4) || (DEP == 6) || (DEP == 8) )
		{
		if ( MODEL == 1 )
			{
			free (synthetic_rv2_data.indep);
			free (synthetic_rv2_data.dep);
			free (synthetic_rv2_data.weight);
			if (DEP == 9)
				{
				free (joint_synthetic_data.indep);
				free (joint_synthetic_data.dep);
				free (joint_synthetic_data.weight);
				}
			}
		if ( DATA == 1 )
			{
			free (experimental_rv2_data.indep);
			free (experimental_rv2_data.dep);
			free (experimental_rv2_data.weight);
			if (DEP == 9)
				{
				free (joint_experimental_data.indep);
				free (joint_experimental_data.dep);
				free (joint_experimental_data.weight);
				}
			}
		}
	}

void plot_chi2_plot (PHOEBE_plot_device device, char *filename)
	{
	phoebe_warning ("This function is not yet implemented.");
	}

void plot_lc_zoom_in ()
	{
	GtkWidget *zoom_step = lookup_widget (PHOEBE_plot_lc, "plot_lc_zoom_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_ZOOM_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (zoom_step));
	sscanf (readout_str, "%d", &LC_ZOOM_INC);

	LC_ZOOM_FACTOR -= (double) LC_ZOOM_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_lc_zoom_out ()
	{
	GtkWidget *zoom_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_zoom_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_ZOOM_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (zoom_step));
	sscanf (readout_str, "%d", &LC_ZOOM_INC);

	LC_ZOOM_FACTOR += (double) LC_ZOOM_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_lc_shift_left ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_X_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &LC_X_INC);

	LC_X_OFFSET -= (double) LC_X_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_lc_shift_right ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_X_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &LC_X_INC);

	LC_X_OFFSET += (double) LC_X_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_lc_shift_up ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_Y_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &LC_Y_INC);

	LC_Y_OFFSET -= (double) LC_Y_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_lc_shift_down ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_lc), "plot_lc_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int LC_Y_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &LC_Y_INC);

	LC_Y_OFFSET += (double) LC_Y_INC / 100.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_update_info (int DESTINATION, PHOEBE_calculated_parameters params)
	{
	GtkWidget *readout_widget;
	
	char working_string[255];
	char *working_str = working_string;

	int i;
	
	const char *lc_keywords[] =
		{
		"plot_lc_info_mass_p_label",
		"plot_lc_info_mass_s_label",
		"plot_lc_info_radius_p_label",
		"plot_lc_info_radius_s_label",
		"plot_lc_info_mbol_p_label",
		"plot_lc_info_mbol_s_label",
		"plot_lc_info_logg_p_label",
		"plot_lc_info_logg_s_label",
		"plot_lc_info_psb_p_label",
		"plot_lc_info_psb_s_label",
		"plot_lc_info_surface_p_label",
		"plot_lc_info_surface_s_label",
		"plot_lc_info_rpole_p_label",
		"plot_lc_info_rpole_s_label",
		"plot_lc_info_rpoint_p_label",
		"plot_lc_info_rpoint_s_label",
		"plot_lc_info_rside_p_label",
		"plot_lc_info_rside_s_label",
		"plot_lc_info_rback_p_label",
		"plot_lc_info_rback_s_label"
		};

	const char *rv_keywords[] =
		{
		"plot_rv_info_mass_p_label",
		"plot_rv_info_mass_s_label",
		"plot_rv_info_radius_p_label",
		"plot_rv_info_radius_s_label",
		"plot_rv_info_mbol_p_label",
		"plot_rv_info_mbol_s_label",
		"plot_rv_info_logg_p_label",
		"plot_rv_info_logg_s_label",
		"plot_rv_info_psb_p_label",
		"plot_rv_info_psb_s_label",
		"plot_rv_info_surface_p_label",
		"plot_rv_info_surface_s_label",
		"plot_rv_info_rpole_p_label",
		"plot_rv_info_rpole_s_label",
		"plot_rv_info_rpoint_p_label",
		"plot_rv_info_rpoint_s_label",
		"plot_rv_info_rside_p_label",
		"plot_rv_info_rside_s_label",
		"plot_rv_info_rback_p_label",
		"plot_rv_info_rback_s_label"
		};

	double values[20] =
		{
		params.mass_p,
		params.mass_s,
		params.radius_p,
		params.radius_s,
		params.mbol_p,
		params.mbol_s,
		params.logg_p,
		params.logg_s,
		params.psb_p,
		params.psb_s,
		params.surface_p,
		params.surface_s,
		params.rpole_p,
		params.rpole_s,
		params.rpoint_p,
		params.rpoint_s,
		params.rside_p,
		params.rside_s,
		params.rback_p,
		params.rback_s
		};

	for (i = 0; i < 20; i++)
		{
		if (DESTINATION == 1)
			readout_widget = lookup_widget (PHOEBE_plot_lc, lc_keywords[i]);
		if (DESTINATION == 2)
			readout_widget = lookup_widget (PHOEBE_plot_rv, rv_keywords[i]);

		sprintf (working_str, "%.3lf", values[i]);
		gtk_label_set_text (GTK_LABEL (readout_widget), working_str);
		}
	}

void plot_rv_shift_up ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_Y_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &RV_Y_INC);

	RV_Y_OFFSET -= (double) RV_Y_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_rv_shift_down ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_Y_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &RV_Y_INC);

	RV_Y_OFFSET += (double) RV_Y_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_rv_shift_left ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_X_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &RV_X_INC);

	RV_X_OFFSET -= (double) RV_X_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_rv_shift_right ()
	{
	GtkWidget *offset_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_offset_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_X_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (offset_step));
	sscanf (readout_str, "%d", &RV_X_INC);

	RV_X_OFFSET += (double) RV_X_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}
	
void plot_rv_zoom_in ()
	{
	GtkWidget *zoom_step = lookup_widget (PHOEBE_plot_rv, "plot_rv_zoom_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_ZOOM_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (zoom_step));
	sscanf (readout_str, "%d", &RV_ZOOM_INC);

	RV_ZOOM_FACTOR -= (double) RV_ZOOM_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

void plot_rv_zoom_out ()
	{
	GtkWidget *zoom_step = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_zoom_step_entry");
	GtkWidget *dummy = gtk_button_new ();

	char *readout_str;

	int RV_ZOOM_INC;

	readout_str = gtk_entry_get_text (GTK_ENTRY (zoom_step));
	sscanf (readout_str, "%d", &RV_ZOOM_INC);

	RV_ZOOM_FACTOR += (double) RV_ZOOM_INC / 100.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (dummy), NULL);
	}

int draw_image_to_screen (GtkWidget *frame, char *image_name)
	{
	GtkWidget *new_image;

	gtk_widget_destroy (GTK_BIN (frame)->child);
	new_image = create_pixmap (frame, image_name);
	gtk_container_add (GTK_CONTAINER (frame), new_image);
	gtk_widget_show (new_image);
	}
