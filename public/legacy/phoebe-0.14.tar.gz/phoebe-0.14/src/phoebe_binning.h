#include <stdlib.h>
#include "phoebe_global.h"

void bin_data (new_PHOEBE_data *data, int bin_no);
