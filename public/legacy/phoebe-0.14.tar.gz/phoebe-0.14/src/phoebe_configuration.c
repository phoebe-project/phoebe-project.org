#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>

#include "phoebe_global.h"
#include "phoebe_gui_support.h"

void configuration_save_file (GtkWidget *widget, gpointer user_data)
	{
	GtkWidget *readout_widget;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	FILE *CONFIG_FILE;

	sprintf (working_str, "%s/phoebe.config", PHOEBE_HOME_DIR);
	CONFIG_FILE = fopen (working_str, "w");

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_base_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_BASE_DIR               %s\n", readout_str);
	sprintf (PHOEBE_BASE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_source_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_SOURCE_DIR             %s\n", readout_str);
	sprintf (PHOEBE_SOURCE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_share_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_SHARE_DIR              %s\n", readout_str);
	sprintf (PHOEBE_SHARE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_working_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_TEMP_DIR               %s\n", readout_str);
	sprintf (PHOEBE_TEMP_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_data_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_DATA_DIR               %s\n", readout_str);
	sprintf (PHOEBE_DATA_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_lc_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_LC_DIR                 %s\n", readout_str);
	sprintf (PHOEBE_LC_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_dc_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_DC_DIR                 %s\n", readout_str);
	sprintf (PHOEBE_DC_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_sm_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		fprintf (CONFIG_FILE, "PHOEBE_PLOTTING_PACKAGE       sm\n");
		sprintf (PHOEBE_PLOTTING_PACKAGE, "sm");
		}
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_gnuplot_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		fprintf (CONFIG_FILE, "PHOEBE_PLOTTING_PACKAGE       gnuplot\n");
		sprintf (PHOEBE_PLOTTING_PACKAGE, "gnuplot");
		}
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_pgplot_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		fprintf (CONFIG_FILE, "PHOEBE_PLOTTING_PACKAGE       pgplot\n");
		sprintf (PHOEBE_PLOTTING_PACKAGE, "pgplot");
		}

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_plotting_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_PLOTTING_DIR           %s\n", readout_str);
	sprintf (PHOEBE_PLOTTING_DIR, "%s", readout_str);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		{
		fprintf (CONFIG_FILE, "PHOEBE_LD_SWITCH              1\n");
		PHOEBE_LD_SWITCH = 1;
		}
	else
		{
		fprintf (CONFIG_FILE, "PHOEBE_LD_SWITCH              0\n");
		PHOEBE_LD_SWITCH = 0;
		}

	if (PHOEBE_LD_SWITCH == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_vanhamme_interpolation"), FALSE);
	if (PHOEBE_LD_SWITCH == 1) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_vanhamme_interpolation"), TRUE);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	fprintf (CONFIG_FILE, "PHOEBE_LD_DIR                 %s\n", readout_str);
	sprintf (PHOEBE_LD_DIR, "%s", readout_str);

	fclose (CONFIG_FILE);

	print_to_status_bar ("PHOEBE Configuration File Saved...");

	gtk_widget_hide (PHOEBE_configuration);
	}
