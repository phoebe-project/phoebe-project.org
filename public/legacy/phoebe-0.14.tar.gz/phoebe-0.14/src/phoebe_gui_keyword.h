#ifndef PHOEBE_GUI_KEYWORD_H
#define PHOEBE_GUI_KEYWORD_H 1

enum keyword_type {TYPE_INT, TYPE_DBL, TYPE_STR, TYPE_BOO, TYPE_LST};

void add_to_keyword_file   (const char *keyword, enum keyword_type type, GtkWidget *WIDGET, const char *widget_name, FILE *keyword_file);
void get_from_keyword_file (                     enum keyword_type type, GtkWidget *WIDGET, const char *widget_name, FILE *keyword_file);

void save_keyword_file ();
void open_keyword_file (const char *filename);

int check_directory_consistency (GtkWidget *filesel1, GtkWidget *filesel2);
void update_keyword_file_list ();

#endif
