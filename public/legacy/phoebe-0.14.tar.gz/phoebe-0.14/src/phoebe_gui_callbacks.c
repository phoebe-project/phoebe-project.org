#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <errno.h>
#include <gtk/gtk.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "phoebe_allocations.h"
#include "phoebe_chi2.h"
#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_grid.h"
#include "phoebe_gui.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_callbacks.h"
#include "phoebe_gui_fitting.h"
#include "phoebe_gui_keyword.h"
#include "phoebe_gui_ld.h"
#include "phoebe_gui_plot.h"
#include "phoebe_gui_support.h"
#include "phoebe_limb_darkening.h"
#include "phoebe_phsv_pcsv.h"
#include "phoebe_plot.h"
#include "phoebe_transformations.h"

void on_switches_toggled (GtkToggleButton *togglebutton, gpointer user_data)
	{
	/* This function takes care of shading, which represents availability of    */
	/* some specific widget; it is attached to a toggle-button change. If the   */
	/* toggle button is turned on, the widget will be available.                */

	if (GTK_TOGGLE_BUTTON (user_data)->active == TRUE)
		gtk_widget_set_sensitive (GTK_WIDGET (togglebutton), TRUE);
	else
		gtk_widget_set_sensitive (GTK_WIDGET (togglebutton), FALSE);
	}

void on_switches_reverse_toggled (GtkToggleButton *togglebutton, gpointer user_data)
	{
	/* This function takes care of shading, which represents availability of    */
	/* some specific widget; it is attached to a toggle-button change. If the   */
	/* toggle button is turned on, the widget will be unavailable.              */

	if (GTK_TOGGLE_BUTTON (user_data)->active == TRUE)
		gtk_widget_set_sensitive (GTK_WIDGET (togglebutton), FALSE);
	else
		gtk_widget_set_sensitive (GTK_WIDGET (togglebutton), TRUE);
	}

void on_data_lc_no_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	/* Be sure that the 2D parameter correlation Calculate button is off if     */
	/* there are no lightcurves present:                                        */
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "fitting_chi2_calculate_button"), FALSE);
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "fitting_chi2_calculate_button"), TRUE);
	if (lc_no == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"), FALSE);
	if (lc_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"), TRUE);

	allocate_memory_for_data_record (&PHOEBE_lc_data, lc_no);
	add_empty_record_to_all_lc_dependent_info_lists ();
	}

void on_data_rv_no_value_changed (GtkEditable *editable, gpointer user_data)
	{
	/* This function takes care of shading of radial velocity fields that are  */
	/* supposed to be available or unavailable, depending on RVNo.             */

	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	GtkWidget *readout_widget;

	/* Be sure that the SMA adjustability switch is off if there are no RVs:    */
	readout_widget = lookup_widget (PHOEBE, "basic_sma_adjust");
	if (rv_no == 0)
		{
		if (GTK_TOGGLE_BUTTON (readout_widget)->active) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
		gtk_widget_set_sensitive (readout_widget, FALSE);
		}
	if (rv_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "basic_sma_adjust"), TRUE);

	/* Be sure that the VGA adjustability switch is off if there are no RVs:    */
	readout_widget = lookup_widget (PHOEBE, "basic_vga_adjust");
	if (rv_no == 0)
		{
		if (GTK_TOGGLE_BUTTON (readout_widget)->active) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
		gtk_widget_set_sensitive (readout_widget, FALSE);
		}
	if (rv_no != 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "basic_vga_adjust"), TRUE);

	allocate_memory_for_data_record (&PHOEBE_rv_data, rv_no);
	add_empty_record_to_all_rv_dependent_info_lists ();
	}

void on_data_lc_filter_changed ()
	{
	/* This is not an actual callback, because CList widget doesn't support     */
	/* "changed" signal emission. If there is such a signal in GTK2.0, it will  */
	/* be fixed.                                                                */

	/* This function changes the labels "Undefined" and "None Specified" to     */
	/* filter names.                                                            */

	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int i;

	for (i = 0; i < lc_no; i++)
		{
		/* First, let's take care of the luminosities:                            */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), i, 0, PHOEBE_lc_data[i].filter);

		/* Next, let's take care of the 3rd light:                                */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), i, 0, PHOEBE_lc_data[i].filter);

		/* Then, let's change the weighting labels:                               */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_weighting_info_list")), i, 0, PHOEBE_lc_data[i].filter);

		/* And finally, let's change limb darkening labels:                       */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), i, 0, PHOEBE_lc_data[i].filter);
		}
	}

void on_data_rv_filter_changed ()
	{
	/* This is not an actual callback, because CList widget doesn't support     */
	/* "changed" signal emission. If there is such a signal in GTK2.0, it will  */
	/* be fixed.                                                                */

	/* This function changes the labels "Undefined" and "None Specified" to     */
	/* filter names.                                                            */

	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	int i;

	for (i = 0; i < rv_no; i++)
		{
		/* Let's take care of the luminosities:                                   */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), i, 0, PHOEBE_rv_data[i].filter);

		/* Let's change limb darkening labels:                                    */
		gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), i, 0, PHOEBE_rv_data[i].filter);
		}
	}

void on_configuration_browse_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_configuration_browse);

	gtk_object_set_data (GTK_OBJECT (PHOEBE_configuration_browse), "browse_button", button);
	}

void on_open_data_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	/* This function assigns a string to point to the chosen keyword file that  */
	/* will be opened in a moment.                                              */

	char *readout_str;

	readout_str = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_open_data_file));
	gtk_entry_set_text (GTK_ENTRY (lookup_widget (PHOEBE_open_data_file, "output_entry")), readout_str);

	gtk_widget_hide (PHOEBE_open_data_file);
	}

void on_configuration_browse_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	char *file_name_ptr;

	GtkWidget *file_name = lookup_widget (GTK_WIDGET (PHOEBE_configuration_browse), "browse_button");

	file_name_ptr = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_configuration_browse));
	gtk_entry_set_text (GTK_ENTRY (file_name), file_name_ptr);

	gtk_widget_hide (PHOEBE_configuration_browse);
	}

void on_advanced_phsv_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *readout_widget;
	double readout_dbl;

	readout_widget = lookup_widget (PHOEBE, "basic_rm_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_rm_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);

	readout_widget = lookup_widget (PHOEBE, "advanced_f1_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_f1_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);

	print_to_status_bar ("PHSV calculation initiated...");

	gtk_widget_show (PHOEBE_calculate_phsv);
	}

void on_advanced_pcsv_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *readout_widget;
	double readout_dbl;

	readout_widget = lookup_widget (PHOEBE, "basic_rm_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_calculate_pcsv, "calculate_pcsv_rm_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);

	readout_widget = lookup_widget (PHOEBE, "advanced_f1_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_calculate_pcsv, "calculate_pcsv_f1_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);

	print_to_status_bar ("PCSV calculation initiated...");

	gtk_widget_show (PHOEBE_calculate_pcsv);
	}

void on_menu_bar_file_exit_activated (GtkMenuItem *menuitem, gpointer user_data)
	{
	GtkWidget *warning_window = create_warning_window (
		"PHOEBE Question",
		"Quit PHOEBE?",
		"By quitting PHOEBE all unsaved data will be lost.",
		"Are you sure you want to quit?",
		on_warning_on_exit_ok_button_clicked,
		gtk_widget_destroy);
	}

void on_warning_on_exit_ok_button_clicked (GtkWidget *widget, gpointer user_data)
	{
	/* This function cleans all temporary files and terminates PHOEBE cleanly:  */

	char system_string[255];
	char *system_str = system_string;

	/* Let's clean everything up first: */
	sprintf (system_str, "rm -f %s/phoebe_*", PHOEBE_TEMP_DIR);
	system (system_str);

	free (PHOEBE_lc_data);

	gtk_main_quit ();

	/* If a user quits PHOEBE through the menu, this cleaning is not performed, */
	/* because of debugging. When mature enough, this will be fixed.            */
	}

void on_calculate_phsv_update_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *old_phsv_value = lookup_widget (GTK_WIDGET (PHOEBE), "advanced_phsv_value");
	GtkWidget *new_phsv_value = lookup_widget (GTK_WIDGET (PHOEBE_calculate_phsv), "calculate_phsv_phsv_value");

	gtk_spin_button_set_value (GTK_SPIN_BUTTON (old_phsv_value),
	      gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (new_phsv_value)));
	}

void on_calculate_pcsv_update_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *old_pcsv_value = lookup_widget (GTK_WIDGET (PHOEBE), "advanced_pcsv_value");
	GtkWidget *new_pcsv_value = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_pcsv_value");

	gtk_spin_button_set_value (GTK_SPIN_BUTTON (old_pcsv_value),
	      gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (new_pcsv_value)));
	}

void on_calculate_phsv_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *calculate_phsv_circular = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_circular_orbit");
	GtkWidget *calculate_phsv_d = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_d_value");
	GtkWidget *calculate_phsv_rm = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_rm_value");
	GtkWidget *calculate_phsv_r = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_r_value");
	GtkWidget *calculate_phsv_phsv = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_phsv_value");
	GtkWidget *calculate_phsv_f, *calculate_phsv_lambda, *calculate_phsv_nu;

	double D, q, r, F, lambda, nu, phsv;

	D = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_d));
	q = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_rm));
	r = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_r));

	if (GTK_TOGGLE_BUTTON (calculate_phsv_circular)->active)
		phsv = calculate_phsv_value (0, D, q, r, 0, 0, 0);
	else
		{
		calculate_phsv_f = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_f1_value");
		calculate_phsv_lambda = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_lambda_value");
		calculate_phsv_nu = lookup_widget (PHOEBE_calculate_phsv, "calculate_phsv_nu_value");

		F = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_f));
		lambda = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_lambda));
		nu = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_phsv_nu));

		phsv = calculate_phsv_value (1, D, q, r, F, lambda, nu);
		}

	gtk_spin_button_set_value (GTK_SPIN_BUTTON (calculate_phsv_phsv), phsv);
	}

void on_calculate_pcsv_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *calculate_pcsv_circular = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_circular_orbit");
	GtkWidget *calculate_pcsv_d = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_d_value");
	GtkWidget *calculate_pcsv_rm = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_rm_value");
	GtkWidget *calculate_pcsv_r = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_r_value");
	GtkWidget *calculate_pcsv_pcsv = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_pcsv_value");
	GtkWidget *calculate_pcsv_f, *calculate_pcsv_lambda, *calculate_pcsv_nu;

	double D, q, r, F, lambda, nu, pcsv;

	D = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_d));
	q = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_rm));
	r = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_r));

	if (GTK_TOGGLE_BUTTON (calculate_pcsv_circular)->active)
		{
		pcsv = calculate_pcsv_value (0, D, q, r, 0, 0, 0);
		}
	else
		{
		calculate_pcsv_f = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_f1_value");
		calculate_pcsv_lambda = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_lambda_value");
		calculate_pcsv_nu = lookup_widget (GTK_WIDGET (PHOEBE_calculate_pcsv), "calculate_pcsv_nu_value");

		F = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_f));
		lambda = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_lambda));
		nu = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (calculate_pcsv_nu));

		pcsv = calculate_pcsv_value (1, D, q, r, F, lambda, nu);
		}

	gtk_spin_button_set_value (GTK_SPIN_BUTTON (calculate_pcsv_pcsv), pcsv);
	}

void on_save_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_save_keyword_file);
	}

void on_save_keyword_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	/* This function assigns a filename to the keyword file into which the con- */
	/* tents of PHOEBE will be written into. It also checks if that file aready */
	/* exists and if it does, it displays a warning. Finally, when the new file */
	/* is saved, it is appended to the file selection window.                   */

	GtkWidget *warning_window = NULL;
	char *filename_str = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_save_keyword_file));

	if (filename_str[strlen(filename_str)-1] == '/')
		{
		/* This means that the output file isn't a file, but a directory!         */
		warning_window = create_notice_window (
			"Notice",
			"Filename choice problem",
		  "Seems that you have accidentally left the",
			"filename blank or selected the directory.",
			gtk_widget_destroy);
		return;
		}
	if (file_exists (filename_str))
		{
		warning_window = create_warning_window (
			"Warning",
			"Overwrite keyword file?",
		  "This will overwrite an existing keyword file.",
			"Are you sure you want to proceed?",
			on_warning_keyword_file_exists_ok_button_clicked,
			gtk_widget_destroy);
		gtk_object_set_data (GTK_OBJECT (PHOEBE), "warning_window", warning_window);
		}
	else
		{
		save_keyword_file ();

		/* This updates the keyword GUI to contain the saved name: */
		update_keyword_file_list ();

		print_to_status_bar ("Keyword File Saved...");
		}
	}

void on_open_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_open_keyword_file);
	}

void on_open_keyword_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	char *filename = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_open_keyword_file));

	open_keyword_file (filename);
	gtk_widget_hide (PHOEBE_open_keyword_file);

	/* We have no callback, so we have to change labels manually:               */
	on_data_lc_filter_changed ();
	on_data_rv_filter_changed ();
	add_filters_to_available_filter_lists ();

	print_to_status_bar ("Keyword File Opened... ");
	}

void on_lc_plot_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_plot_lc);
	}

void on_rv_plot_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_plot_rv);
	}

void on_plot_lc_plot_button_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("LC Plotting Window opened... ");
	plot_lc_plot (x11, NULL);
	}

void on_plot_lc_clear_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *readout_widget;

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_image_frame");
	draw_image_to_screen (readout_widget, "empty_lc.xpm");

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_chi2_ptsno_value");
	gtk_label_set_text (GTK_LABEL (readout_widget), "0");

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_chi2_chi2_value");
	gtk_label_set_text (GTK_LABEL (readout_widget), "not calculated");
	}

void on_plot_lc_done_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_plot_lc);	
	}

void on_plot_lc_shift_up_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Shifted Up...");

	plot_lc_shift_up ();
	}

void on_plot_lc_shift_left_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Shifted Left...");

	plot_lc_shift_left ();
	}

void on_plot_lc_shift_down_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Shifted Down...");

	plot_lc_shift_down ();
	}

void on_plot_lc_shift_right_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Shifted Right...");

	plot_lc_shift_right ();
	}

void on_plot_lc_zoom_in_button_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Zoomed In...");

	plot_lc_zoom_in ();
	}

void on_plot_lc_zoom_out_button_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("Plot Zoomed Out...");

	plot_lc_zoom_out ();
	}

void on_plot_lc_reset_button_clicked (GtkButton *button, gpointer user_data)
	{
	LC_ZOOM_FACTOR = 0.0;
	LC_X_OFFSET = 0.0;
	LC_Y_OFFSET = 0.0;

	on_plot_lc_plot_button_clicked (GTK_BUTTON (button), NULL);
	}

void on_menu_bar_settings_configure_clicked (GtkMenuItem *menuitem, gpointer user_data)
	{
	GtkWidget *readout_widget;
	
	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_base_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_BASE_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_source_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_SOURCE_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_share_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_SHARE_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_working_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_TEMP_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_data_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_DATA_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_lc_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_LC_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_dc_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_DC_DIR);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_plotting_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_PLOTTING_DIR);

	if (strcmp (PHOEBE_PLOTTING_PACKAGE, "sm") == 0) readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_sm_switch");
	if (strcmp (PHOEBE_PLOTTING_PACKAGE, "gnuplot") == 0) readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_gnuplot_switch");
	if (strcmp (PHOEBE_PLOTTING_PACKAGE, "pgplot") == 0) readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_pgplot_switch");

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_switch");
	if (PHOEBE_LD_SWITCH == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
	if (PHOEBE_LD_SWITCH == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_directory");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_LD_DIR);
	
	gtk_widget_show (PHOEBE_configuration);
	}

void on_configuration_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	/* This function takes the values that are currently in the Configuration   */
	/* window and applies them to the current session. The values do not per-   */
	/* tain after restart.                                                      */

	GtkWidget *readout_widget;
	char *readout_str;

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_base_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_BASE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_source_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_SOURCE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_share_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_SHARE_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_working_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_TEMP_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_data_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_DATA_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_lc_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_LC_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_dc_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_DC_DIR, "%s", readout_str);

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_sm_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		sprintf (PHOEBE_PLOTTING_PACKAGE, "sm");
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_gnuplot_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		sprintf (PHOEBE_PLOTTING_PACKAGE, "gnuplot");
	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_pgplot_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		sprintf (PHOEBE_PLOTTING_PACKAGE, "pgplot");

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE_configuration), "configuration_plotting_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_PLOTTING_DIR, "%s", readout_str);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE)
		PHOEBE_LD_SWITCH = 1;
	else
		PHOEBE_LD_SWITCH = 0;

	if (PHOEBE_LD_SWITCH == 0) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_vanhamme_interpolation"), FALSE);
	if (PHOEBE_LD_SWITCH == 1) gtk_widget_set_sensitive (lookup_widget (PHOEBE, "ld_vanhamme_interpolation"), TRUE);

	readout_widget = lookup_widget (PHOEBE_configuration, "configuration_ld_directory");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (PHOEBE_LD_DIR, "%s", readout_str);

	print_to_status_bar ("Temporary PHOEBE configuration applied. Defaults will be restored after restart.");
	gtk_widget_hide (PHOEBE_configuration);
	}

void on_configuration_save_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *warning_window;

	char working_string[255];
	char *working_str = working_string;

	sprintf (working_str, "%s/phoebe.config", PHOEBE_HOME_DIR);

	if (file_exists (working_str))
		{
		warning_window = create_warning_window
			("PHOEBE configuration file already exists",
			 "Overwrite existing PHOEBE configuration?",
			 "A PHOEBE configuration file phoebe.config already exists in PHOEBE home directory.",
			 "Are you sure you want to overwrite it?",
			 on_warning_configuration_file_exists_ok_button_clicked,
			 gtk_widget_destroy);
		gtk_object_set_data (GTK_OBJECT (PHOEBE), "warning_window", warning_window);
		}
	else
		configuration_save_file (GTK_WIDGET (button), user_data);
	}

void on_warning_no_configuration_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *warning_window = lookup_widget (GTK_WIDGET (PHOEBE), "warning_window");
	GtkWidget *settings = lookup_widget (GTK_WIDGET (PHOEBE), "menu_bar_settings_configuration");

	char working_string[255];
	char *working_str = working_string;

	mkdir (PHOEBE_HOME_DIR, 0755);

	gtk_widget_hide (warning_window);
	on_menu_bar_settings_configure_clicked (GTK_MENU_ITEM (settings), user_data);

	sprintf (working_str, "PHOEBE Configuration directory %s created...", PHOEBE_HOME_DIR);
	print_to_status_bar (working_str);
	}

void on_warning_keyword_file_exists_ok_button_clicked (GtkWidget *widget, gpointer user_data)
	{
	GtkWidget *warning_window = lookup_widget (GTK_WIDGET (PHOEBE), "warning_window");
	gtk_widget_destroy (warning_window);

	save_keyword_file ();

	print_to_status_bar ("Keyword File Overwritten...");
	}

void on_warning_configuration_file_exists_ok_button_clicked (GtkWidget *widget, gpointer user_data)
	{
	GtkWidget *warning_window = lookup_widget (GTK_WIDGET (PHOEBE), "warning_window");
	gtk_widget_destroy (warning_window);

	configuration_save_file (widget, user_data);
	}

void on_plot_rv_plot_button_clicked (GtkButton *button, gpointer user_data)
	{
	print_to_status_bar ("RV Plotting Window opened... ");
	plot_rv_plot (x11, NULL);
	}

void on_plot_rv_done_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_plot_rv);
	}

void on_plot_rv_shift_up_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_shift_up ();
	}

void on_plot_rv_shift_left_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_shift_left ();
	}

void on_plot_rv_shift_down_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_shift_down ();
	}

void on_plot_rv_shift_right_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_shift_right ();
	}

void on_plot_rv_reset_button_clicked (GtkButton *button, gpointer user_data)
	{
	RV_ZOOM_FACTOR = 0.0;
	RV_X_OFFSET = 0.0;
	RV_Y_OFFSET = 0.0;

	on_plot_rv_plot_button_clicked (GTK_BUTTON (button), NULL);
	}

void on_plot_rv_zoom_out_button_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_zoom_out ();
	}

void on_plot_rv_zoom_in_button_clicked (GtkButton *button, gpointer user_data)
	{
	plot_rv_zoom_in ();
	}

void on_plot_rv_clear_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *readout_widget;

	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_image_frame");
	draw_image_to_screen (readout_widget, "empty_rv.xpm");

	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_chi2_ptsno_value");
	gtk_label_set_text (GTK_LABEL (readout_widget), "0");

	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_chi2_chi2_value");
	gtk_label_set_text (GTK_LABEL (readout_widget), "not calculated");
	}

void on_plot_lc_dependent_variable_changed (GtkEditable *editable, gpointer user_data)
	{
	/* This function disables data switch if the user chooses to plot such      */
	/* plots where data plotting has no sense. Also, it takes care of what le-  */
	/* vel-dependent value (flux factor) should be displayed.                   */

	GtkWidget *readout_widget;

	GtkWidget *data = lookup_widget (PHOEBE_plot_lc, "plot_lc_experimental_data");
	GtkWidget *lc_no = lookup_widget (PHOEBE, "data_lc_no_value");

	char *readout_str;

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_dependent_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));

	/* Make flux-oriented widgets sensitive only in case of normalized flux:    */
	if (strcmp (readout_str, "Normalized Flux") == 0)
		{
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_label");
		gtk_widget_set_sensitive (readout_widget, TRUE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_value");
		gtk_widget_set_sensitive (readout_widget, TRUE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_label");
		gtk_widget_set_sensitive (readout_widget, TRUE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_value");
		gtk_widget_set_sensitive (readout_widget, TRUE);
		}
	else
		{
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_label");
		gtk_widget_set_sensitive (readout_widget, FALSE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_value");
		gtk_widget_set_sensitive (readout_widget, FALSE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_label");
		gtk_widget_set_sensitive (readout_widget, FALSE);
		readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_value");
		gtk_widget_set_sensitive (readout_widget, FALSE);
		}
	}

void on_plot_rv_dependent_variable_changed (GtkEditable *editable, gpointer user_data)
	{
	/* This function disables data switch if the user chooses to plot such      */
	/* plots where data plotting has no sense.                                  */

	GtkWidget *dependent = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_dependent_combo_box_entry");
	GtkWidget *data = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_experimental_data");
	GtkWidget *data_switch = lookup_widget (GTK_WIDGET (PHOEBE_plot_rv), "plot_rv_data_switch");
	GtkWidget *rv_no = lookup_widget (GTK_WIDGET (PHOEBE), "data_rv_no_value");

	char *readout_str;

	readout_str = gtk_entry_get_text (GTK_ENTRY (dependent));

	/* It should make toggle button available only if data is available: */

	if ( ( GTK_TOGGLE_BUTTON (data_switch)->active == TRUE ) &&
	     ( gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (rv_no)) != 0 ) )
		{
		if ( ( strcmp (readout_str, "Primary eclipse-proximity corrections")   == 0 ) ||
		     ( strcmp (readout_str, "Secondary eclipse-proximity corrections") == 0 ) )
					gtk_widget_set_sensitive (GTK_WIDGET (data), FALSE);
		else
					gtk_widget_set_sensitive (GTK_WIDGET (data), TRUE);
		}
	}

void on_ld_interpolation_clicked (GtkButton *button, gpointer user_data)
	{
	set_values_of_ld_window ();
	gtk_widget_show (PHOEBE_ld_interpolation);
	}

void on_ld_interpolation_interpolate_button_clicked (GtkButton *button, gpointer user_data)
	{
	PHOEBE_data ld_coefs;
	GtkWidget *readout_widget;

	char *readout_str;

	int T;
	double lg, M;
	int ld;
	
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_ldlaw_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Linear Cosine Law") == 0) ld = 0;
	if (strcmp (readout_str, "Logarithmic Law") == 0)   ld = 1;
	if (strcmp (readout_str, "Square Root Law") == 0)   ld = 2;

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_filter_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_tavh_value");
	T = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_primary_logg_value");
	lg = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_primary_metallicity_value");
	M = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	
	ld_coefs = interpolate_from_ld_tables (readout_str, T, lg, M, ld);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_x1a_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), ld_coefs.indep);
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_y1a_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), ld_coefs.dep);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_tavc_value");
	T = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_secondary_logg_value");
	lg = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_secondary_metallicity_value");
	M = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	ld_coefs = interpolate_from_ld_tables (readout_str, T, lg, M, ld);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_x2a_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), ld_coefs.indep);
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_y2a_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), ld_coefs.dep);
	}

void on_ld_interpolation_update_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *ld_list;

	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	GtkWidget *readout_widget;
	double readout_dbl;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	int i;
	int bolometric = 0;
	int lc_match = 0;
	int rv_match = 0;

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_filter_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));

	if (strcmp (readout_str, "Bolometric") == 0) bolometric = 1;
	else
		{
		/* Check whether we update LC or RV coefficients and assign i to the par- */
		/* ticular filter:                                                        */
		for (i = 0; i < lc_no; i++)
			if (strcmp (readout_str, PHOEBE_lc_data[i].filter) == 0) { lc_match = 1; break; }
		if (lc_match == 0)
			for (i = 0; i < rv_no; i++)
				if (strcmp (readout_str, PHOEBE_rv_data[i].filter) == 0) { rv_match = 1; break; }

		if (lc_match == 1) ld_list = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
		if (rv_match == 1) ld_list = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");

		if ( (lc_match == 0) && (rv_match == 0) ) phoebe_fatal ("Severe Logistical Problem in on_ld_interpolation_update_button_clicked ().");
		}
	
	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_x1a_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", readout_dbl);
	if (bolometric == 1) gtk_spin_button_set_value (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "ld_xbol1_value")), readout_dbl);
	else gtk_clist_set_text (GTK_CLIST (ld_list), i, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_y1a_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", readout_dbl);
	if (bolometric == 1) gtk_spin_button_set_value (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "ld_ybol1_value")), readout_dbl);
	else gtk_clist_set_text (GTK_CLIST (ld_list), i, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_x2a_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", readout_dbl);
	if (bolometric == 1) gtk_spin_button_set_value (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "ld_xbol2_value")), readout_dbl);
	else gtk_clist_set_text (GTK_CLIST (ld_list), i, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_y2a_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", readout_dbl);
	if (bolometric == 1) gtk_spin_button_set_value (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "ld_ybol2_value")), readout_dbl);
	else gtk_clist_set_text (GTK_CLIST (ld_list), i, 4, working_str);
	}

void on_ld_interpolation_update_all_button_clicked (GtkButton *button, gpointer user_data)
	{
	phoebe_warning ("Function not implemented yet.");
	}

void on_menu_bar_about_clicked (GtkMenuItem *menuitem, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_about);
	print_to_status_bar ("About PHOEBE...");
	}

void on_fitting_chi2_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *readout_widget;
	
	char *readout_str;

	int x_param, y_param;
	double x_param_min, x_param_max;
	double y_param_min, y_param_max;
	int x_param_steps, y_param_steps;

	int plot_type;
	
	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_indep");
	readout_str = gtk_entry_get_text (GTK_ENTRY (GTK_COMBO (readout_widget)->entry));

	if (strcmp (readout_str, "Orbital Semi-Major Axis") == 0) x_param = 9;
	if (strcmp (readout_str, "Orbital Eccentricity") == 0) x_param = 10;
	if (strcmp (readout_str, "Argument of Periastron") == 0)  x_param = 11;
	if (strcmp (readout_str, "Primary Star Synchronicity Parameter") == 0)  x_param = 12;
	if (strcmp (readout_str, "Secondary Star Synchronicity Parameter") == 0)  x_param = 13;
	if (strcmp (readout_str, "Phase Shift") == 0)  x_param = 14;
	if (strcmp (readout_str, "Systemic Radial Velocity") == 0)  x_param = 15;
	if (strcmp (readout_str, "Orbital Inclination") == 0)  x_param = 16;
	if (strcmp (readout_str, "Primary Star Gravity Brightening") == 0)  x_param = 17;
	if (strcmp (readout_str, "Secondary Star Gravity Brightening") == 0)  x_param = 18;
	if (strcmp (readout_str, "Primary Star Temperature") == 0)  x_param = 19;
	if (strcmp (readout_str, "Secondary Star Temperature") == 0)  x_param = 20;
	if (strcmp (readout_str, "Primary Star Bolometric Albedo") == 0)  x_param = 21;
	if (strcmp (readout_str, "Secondary Star Bolometric Albedo") == 0)  x_param = 22;
	if (strcmp (readout_str, "Primary Star Surface Potential") == 0)  x_param = 23;
	if (strcmp (readout_str, "Secondary Star Surface Potential") == 0)  x_param = 24;
	if (strcmp (readout_str, "Mass Ratio") == 0)  x_param = 25;
	if (strcmp (readout_str, "HJD0 Reference Frame") == 0)  x_param = 26;
	if (strcmp (readout_str, "Orbital Period") == 0)  x_param = 27;
	if (strcmp (readout_str, "Period Time Derivative") == 0)  x_param = 28;
	if (strcmp (readout_str, "HJD0 Time Derivative") == 0)  x_param = 29;

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_dep");
	readout_str = gtk_entry_get_text (GTK_ENTRY (GTK_COMBO (readout_widget)->entry));

	if (strcmp (readout_str, "Orbital Semi-Major Axis") == 0) y_param = 9;
	if (strcmp (readout_str, "Orbital Eccentricity") == 0) y_param = 10;
	if (strcmp (readout_str, "Argument of Periastron") == 0)  y_param = 11;
	if (strcmp (readout_str, "Primary Star Synchronicity Parameter") == 0)  y_param = 12;
	if (strcmp (readout_str, "Secondary Star Synchronicity Parameter") == 0)  y_param = 13;
	if (strcmp (readout_str, "Phase Shift") == 0)  y_param = 14;
	if (strcmp (readout_str, "Systemic Radial Velocity") == 0)  y_param = 15;
	if (strcmp (readout_str, "Orbital Inclination") == 0)  y_param = 16;
	if (strcmp (readout_str, "Primary Star Gravity Brightening") == 0)  y_param = 17;
	if (strcmp (readout_str, "Secondary Star Gravity Brightening") == 0)  y_param = 18;
	if (strcmp (readout_str, "Primary Star Temperature") == 0)  y_param = 19;
	if (strcmp (readout_str, "Secondary Star Temperature") == 0)  y_param = 20;
	if (strcmp (readout_str, "Primary Star Bolometric Albedo") == 0)  y_param = 21;
	if (strcmp (readout_str, "Secondary Star Bolometric Albedo") == 0)  y_param = 22;
	if (strcmp (readout_str, "Primary Star Surface Potential") == 0)  y_param = 23;
	if (strcmp (readout_str, "Secondary Star Surface Potential") == 0)  y_param = 24;
	if (strcmp (readout_str, "Mass Ratio") == 0)  y_param = 25;
	if (strcmp (readout_str, "HJD0 Reference Frame") == 0)  y_param = 26;
	if (strcmp (readout_str, "Orbital Period") == 0)  y_param = 27;
	if (strcmp (readout_str, "Period Time Derivative") == 0)  y_param = 28;
	if (strcmp (readout_str, "HJD0 Time Derivative") == 0)  y_param = 29;

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_indep_min_value");
	x_param_min = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_indep_max_value");
	x_param_max = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_x_steps_value");
	x_param_steps = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_dep_min_value");
	y_param_min = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_dep_max_value");
	y_param_max = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_y_steps_value");
	y_param_steps = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_2d_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) plot_type = 1;
	else plot_type = 2;

	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_filter_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));

	if (strcmp (readout_str, "Filter: None Specified") == 0)
		{
		readout_widget = create_notice_window ("PHOEBE Notice", "PHOEBE Notice: Filter name invalid", "You have not assigned a proper filter to the calculation routine.", "Please make sure you defined filters in Data tab.", gtk_widget_destroy);
		return;
		}

	create_chi2_plot (readout_str, plot_type, x_param, x_param_min, x_param_max, x_param_steps, y_param, y_param_min, y_param_max, y_param_steps);
	}

void on_luminosities_seed_button_clicked (GtkButton *button, gpointer user_data)
	{
	int seed;
	GtkWidget *readout_widget = lookup_widget (PHOEBE, "luminosities_seed_value");

	srand (time (0));
	seed = (int) (100000001.0 + (double) rand () / RAND_MAX * 100000000.0);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), seed);
	}

void on_fitting_mms_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int i;
	int mms_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "fitting_mms_value")));

	const char *mms[] = {"fitting_mms_hbox_1", "fitting_mms_hbox_2", "fitting_mms_hbox_3", "fitting_mms_hbox_4", "fitting_mms_hbox_5"};

	for (i = 0; i < mms_no; i++)
		gtk_widget_set_sensitive (lookup_widget (PHOEBE, mms[i]), TRUE);
	for (i = mms_no; i < 5; i++)
		gtk_widget_set_sensitive (lookup_widget (PHOEBE, mms[i]), FALSE);
	}

void on_utilities_calculate_grid_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *grid_list = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");
	int i;

	char *row1[] = {"1.", "0.30", "5500",  "0.40", "0.10", "0.60", "coupled"};
	char *row2[] = {"2.", "0.40", "6000",  "0.50", "0.15", "0.70", "coupled"};
	char *row3[] = {"3.", "0.50", "7000",  "0.60", "0.20", "0.80", "coupled"};
	char *row4[] = {"4.", "0.60", "8000",  "0.70", "0.25", "0.90", "coupled"};
	char *row5[] = {"5.", "0.70", "8500",  "0.80", "0.30", "1.00", "coupled"};
	char *row6[] = {"6.", "0.75", "9000",  "0.90", "0.35", "1.10", "coupled"};
	char *row7[] = {"7.", "0.80", "9500",  "1.00", "0.40", "1.20", "coupled"};
	char *row8[] = {"8.", "0.90", "10000", "1.10", "0.45", "1.50", "coupled"};

	gtk_clist_clear (GTK_CLIST (grid_list));

	gtk_clist_set_column_title (GTK_CLIST (grid_list), 0, "Node");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 1, "q");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 2, "T1[K]");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 3, "T2/T1");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 4, "R1/a");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 5, "R2/R1");
	gtk_clist_set_column_title (GTK_CLIST (grid_list), 6, "i");

	for (i = 0; i < 7; i++)
		gtk_clist_set_column_justification (GTK_CLIST (grid_list), i, GTK_JUSTIFY_FILL);
	gtk_clist_append (GTK_CLIST (grid_list), row1);
	gtk_clist_append (GTK_CLIST (grid_list), row2);
	gtk_clist_append (GTK_CLIST (grid_list), row3);
	gtk_clist_append (GTK_CLIST (grid_list), row4);
	gtk_clist_append (GTK_CLIST (grid_list), row5);
	gtk_clist_append (GTK_CLIST (grid_list), row6);
	gtk_clist_append (GTK_CLIST (grid_list), row7);
	gtk_clist_append (GTK_CLIST (grid_list), row8);

	gtk_widget_show (PHOEBE_calculate_grid);
	}

void on_utilities_use_grid_button_clicked (GtkButton *button, gpointer user_data)
	{
	
	}

void on_synthetic_grid_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	int i, j;
	char *readout_str;

	GtkWidget *grid_list   = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");

	int params_no   = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_params_value")));
	int nodes_no    = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_nodes_value")));
	int vertexes_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_vertexes_value")));
	int filters_no  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_filters_value")));

/* FIX ME! */
	double grid_nodes[6][8];
/* ******* */

	/* These will go to the calculation function: */

	double R;
	int i0, i1, i2, i3, i4, i5;
	int filt;

	char working_string[255];
	char *working_str = working_string;

	PHOEBE_main_parameters main;
	PHOEBE_switches switches;
	PHOEBE_curve_parameters curve;
	PHOEBE_limb_darkening ld;
	PHOEBE_spots spots;
	PHOEBE_wl_dependent_parameters mono;

	int syn_points;
	PHOEBE_data *syn_data = NULL;

	FILE *grid_file;

	GtkWidget *progress_bar = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_progress_bar");
	double percentage = 0.0;

	GtkWidget *notice_window;

	char *filter_names[] = {"synthetic_grid_filter_1_entry", "synthetic_grid_filter_2_entry", "synthetic_grid_filter_3_entry"};

	time_t current_time;
	
	/* ****************************************** */

	for (i = 0; i < params_no; i++)
		for (j = 0; j < nodes_no; j++)
			{
			gtk_clist_get_text (GTK_CLIST (grid_list), j, i+1, &readout_str);
			if (strcmp (readout_str, "coupled") != 0)
				grid_nodes[i][j] = atof (readout_str);
			else
				grid_nodes[i][j] = -1.0;                      /* change to sqrt (-1)? */
			}

	/* The basic idea now would be to call the calculation function located so- */
	/* mewhere else, but right now we shall keep it here for testing purposes!  */

	/* Initialize constant parameters: */
	main.SMA     = 1.0;    switches.MPAGE   = 1;    ld.LD        = 1;
	main.PERIOD  = 1.0;    switches.MODE    = 2;    ld.XBOL1     = 1.0;
	main.HJD0    = 0.5;    switches.NLC     = 0;    ld.XBOL2     = 1.0;
	main.VGA     = 0.0;    switches.IFVC1   = 0;    ld.YBOL1     = 1.0;
	main.GR1     = 1.0;    switches.IFVC2   = 0;    ld.YBOL2     = 1.0;
	main.GR2     = 1.0;    switches.BINNING = 0;
	main.ALB1    = 1.0;    switches.BINNO   = 0;    spots.IFSMV1 = 0.0;
	main.ALB2    = 1.0;    switches.NPPL    = 1;    spots.IFSMV2 = 0.0;
	main.F1      = 1.0;    switches.MREF    = 0;    spots.KSPA   = 0.0;
	main.F2      = 1.0;    switches.NREF    = 0;    spots.NSPA   = 0.0;
	main.E       = 0.0;    switches.ICOR1   = 0;    spots.KSPB   = 0.0;
	main.PERR0   = 0.0;    switches.ICOR2   = 0;    spots.NSPB   = 0.0;
	main.DPERDT  = 0.0;    switches.JDPHS   = 2;    spots.XLAT1  = 0.0;
	main.DPDT    = 0.0;    switches.NOISE   = 0;    spots.XLONG1 = 0.0;
	main.PSHIFT  = 0.0;    switches.IPB     = 0;    spots.RADSP1 = 0.0;
                         switches.IFAT1   = 0;    spots.TEMSP1 = 0.0;
  curve.PHNORM = 0.25;   switches.IFAT2   = 0;    spots.XLAT2  = 0.0;
  curve.FACTOR = 1.0;    switches.N1      = 30;   spots.XLONG2 = 0.0;
  curve.HJDST  = 0.0;    switches.N2      = 30;   spots.RADSP2 = 0.0;
  curve.HJDSP  = 1.0;    switches.N1L     = 5;    spots.TEMSP2 = 0.0;
  curve.HJDIN  = 0.0;    switches.N2L     = 5;
  curve.PHSTRT = -0.5;   switches.ISYM    = 0;    mono.HLA     = 10.0;
  curve.PHSTOP = 0.5;    switches.K0      = 0;    mono.CLA     = 10.0;
                         switches.KDISK   = 0;    mono.X1A     = 1.0;
                         switches.THE     = 0;    mono.X2A     = 1.0;
                                                  mono.Y1A     = 1.0;
                                                  mono.Y2A     = 1.0;
  curve.PHIN  = 1.0 / (vertexes_no - 1);          mono.EL3     = 0.0;
                                                  mono.OPSF    = 0.0;
                                                  mono.SIGMA   = 1.0;

	for (i = 0; i < filters_no; i++)
		{
		readout_str = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE_calculate_grid, filter_names[i])));
		if (strcmp (readout_str, "Undefined") == 0)
			{
			notice_window = create_notice_window ("PHOEBE Notice", "PHOEBE Notice: Filter missing", "You have not assigned enough filters in the", "calculation window. Please supply the missing information!", gtk_widget_destroy);
			return;
			}
		}

	grid_file = fopen ("src/grid.data", "w");

	/* Let's create a small header file:                                        */
	current_time = time (NULL);
	fprintf (grid_file, "# PHOEBE synthetic LC grid created:  %s", asctime (localtime(&current_time)));
	fprintf (grid_file, "#\n");
	fprintf (grid_file, "# Number of gridded parameters:      %d\n", params_no);
	fprintf (grid_file, "# Number of nodes per parameter:     %d\n", nodes_no);
	fprintf (grid_file, "# Number of vertexes per lightcurve: %d\n", vertexes_no);
	fprintf (grid_file, "# Number of used filters:            %d\n", filters_no);
	fprintf (grid_file, "#\n");
	for (i = 0; i < params_no; i++)
		{
		readout_str = gtk_clist_get_column_title (GTK_CLIST (grid_list), i+1);
		fprintf (grid_file, "# P%d: %6s: ", i+1, readout_str);
		for (j = 0; j < nodes_no; j++)
			{
			if (grid_nodes[i][j] > 0) fprintf (grid_file, "%9.2lf", grid_nodes[i][j]);
			else                      fprintf (grid_file, "%9s", "coupled");
			}
		fprintf (grid_file, "\n");
		}
	fprintf (grid_file, "#\n");
	for (i = 0; i < filters_no; i++)
		{
		readout_str = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE_calculate_grid, filter_names[i])));
		fprintf (grid_file, "# F%d: %15s\n", i+1, readout_str);
		}
	fprintf (grid_file, "#\n");

	gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_calculate_button")), FALSE);

	for (i0 = 0; i0 < nodes_no; i0++)
		{
		main.RM = grid_nodes[0][i0];

		for (i1 = 0; i1 < nodes_no; i1++)
			{
			main.TAVH = grid_nodes[1][i1];

			for (i2 = 0; i2 < nodes_no; i2++)
				{
				main.TAVC = main.TAVH * grid_nodes[2][i2];

				for (i3 = 0; i3 < nodes_no; i3++)
					{
					R = grid_nodes[3][i3];
					main.PHSV = calculate_phsv_value (0, 1, main.RM, R, 1, 0, 0);
					main.PCSV = calculate_pcsv_value (0, 1, main.RM, R, 1, 0, 0);

					for (i4 = 0; i4 < nodes_no; i4++)
						{
						for (i5 = 0; i5 < nodes_no; i5++)
							{
							main.XINCL = 90.0 - i5 * 180.0 / 7.0 / M_PI * acos (R + R * grid_nodes[4][i4]);

							for (filt = 0; filt < filters_no; filt++)
								{
								readout_str = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE_calculate_grid, filter_names[filt])));
								sscanf (readout_str, "%lf nm", &mono.WLA);

								create_lci_input_file ("phoebe_lc", main, switches, ld, spots, curve, mono, 100000002., 0.0);

								i = scan_temporary_directory_for_lci_file_index ("phoebe_lc");
								sprintf (working_str, "%s/lc < %s/phoebe_lc_%03d.lci > %s/phoebe_lc_%03d.lco", PHOEBE_LC_DIR, PHOEBE_TEMP_DIR, i, PHOEBE_TEMP_DIR, i);
								system (working_str);
/* FIX ME !!! */ /*
								syn_points = get_synthetic_data (2, 6, &syn_data, PHOEBE_lc);
*/ /* ********** */
								for (i = 0; i < syn_points; i++) fprintf (grid_file, "%f", (float) syn_data[i].dep);
								fprintf (grid_file, "\n");

								while (gtk_events_pending()) gtk_main_iteration ();
								percentage += 1.0 / pow (nodes_no, 6) / filters_no;
								gtk_progress_bar_update (GTK_PROGRESS_BAR (progress_bar), percentage);
								}
							}
						}
					}
				}
			}
		}

	fclose (grid_file);

	gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_calculate_button")), TRUE);
	gtk_label_set_text (GTK_LABEL (GTK_BIN (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_cancel_button"))->child), "OK");
	}

void on_synthetic_grid_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_calculate_grid);
	}

void on_synthetic_grid_filters_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int params_no   = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_params_value")));
	int nodes_no    = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_nodes_value")));
	int vertexes_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_vertexes_value")));
	int filters_no  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_filters_value")));

	char working_string[255];
	char *working_str = working_string;

	int i;

	char *widgets[] = {"synthetic_grid_filter_1_combo", "synthetic_grid_filter_2_combo", "synthetic_grid_filter_3_combo"};
	
	for (i = 0; i < filters_no; i++)
		gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE_calculate_grid, widgets[i])), TRUE);
	for (i = filters_no; i < 3; i++)
		gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE_calculate_grid, widgets[i])), FALSE);

	calculate_estimated_synthetic_grid_file_size (params_no, nodes_no, vertexes_no, filters_no, &working_str);
	gtk_label_set_text (GTK_LABEL (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_size_label")), working_str);
	}

void on_synthetic_grid_params_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int params_no   = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_params_value")));
	int nodes_no    = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_nodes_value")));
	int vertexes_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_vertexes_value")));
	int filters_no  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_filters_value")));

	char working_string[255];
	char *working_str = working_string;

	calculate_estimated_synthetic_grid_file_size (params_no, nodes_no, vertexes_no, filters_no, &working_str);
	gtk_label_set_text (GTK_LABEL (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_size_label")), working_str);
	}

void on_synthetic_grid_vertexes_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int params_no   = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_params_value")));
	int nodes_no    = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_nodes_value")));
	int vertexes_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_vertexes_value")));
	int filters_no  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_filters_value")));

	char working_string[255];
	char *working_str = working_string;

	calculate_estimated_synthetic_grid_file_size (params_no, nodes_no, vertexes_no, filters_no, &working_str);
	gtk_label_set_text (GTK_LABEL (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_size_label")), working_str);
	}

void on_synthetic_grid_nodes_value_changed (GtkEditable *editable, gpointer user_data)
	{
	int params_no   = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_params_value")));
	int nodes_no    = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_nodes_value")));
	int vertexes_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_vertexes_value")));
	int filters_no  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_filters_value")));

	char working_string[255];
	char *working_str = working_string;

	GtkWidget *grid_list = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");
	int rows_already_present = GTK_CLIST (grid_list)->rows;
	int i;

	char entry_string[7][10];
	char *entry[7] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4], entry_string[5], entry_string[6]};

	if (nodes_no < rows_already_present)
		{
		for (i = rows_already_present; i > nodes_no; i--)
			gtk_clist_remove (GTK_CLIST (grid_list), i-1);
		}

	if (nodes_no > rows_already_present)
		for (i = rows_already_present; i < nodes_no; i++)
			{
			sprintf (entry[0], "%d.", i+1);
			sprintf (entry[1], "1.0");
			sprintf (entry[2], "6000");
			sprintf (entry[3], "1.0");
			sprintf (entry[4], "0.1");
			sprintf (entry[5], "1.0");
			sprintf (entry[6], "coupled");

			gtk_clist_append (GTK_CLIST (grid_list), entry);
			}

	calculate_estimated_synthetic_grid_file_size (params_no, nodes_no, vertexes_no, filters_no, &working_str);
	gtk_label_set_text (GTK_LABEL (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_size_label")), working_str);
	}

void on_synthetic_grid_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *grid_list = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");
	int selected_row = (int) ((GList *) (GTK_CLIST (grid_list)->selection))->data;

	GtkWidget *readout_widget;
	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_main_label");
	sprintf (working_str, "Synthetic Grid Entry at Node %d:", selected_row + 1);
	gtk_label_set_text (GTK_LABEL (readout_widget), working_str);

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_q_value");
	gtk_clist_get_text (GTK_CLIST (grid_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_T1_value");
	gtk_clist_get_text (GTK_CLIST (grid_list), selected_row, 2, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_T2T1_value");
	gtk_clist_get_text (GTK_CLIST (grid_list), selected_row, 3, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_R1a_value");
	gtk_clist_get_text (GTK_CLIST (grid_list), selected_row, 4, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_R2R1_value");
	gtk_clist_get_text (GTK_CLIST (grid_list), selected_row, 5, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	/* Unfortunately, this line must be commented, otherwise double-clicking    */
	/* doesn't work (disabling grid_list disables "event" callback too).        */

	/* gtk_widget_set_sensitive (grid_list, FALSE); */

	gtk_widget_show (PHOEBE_calculate_grid_edit_parameters);
	}

gboolean on_synthetic_grid_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *grid_list = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");

	if ( event->type == GDK_2BUTTON_PRESS )
		on_synthetic_grid_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_edit_entry_button")), (gpointer) grid_list);

	return FALSE;
	}

void on_synthetic_grid_parameters_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *grid_list = lookup_widget (PHOEBE_calculate_grid, "synthetic_grid_list");
	int selected_row = (int) ((GList *) (GTK_CLIST (grid_list)->selection))->data;

	GtkWidget *readout_widget;
	double readout_dbl;
	int readout_int;

	char working_string[255];
	char *working_str = working_string;

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_q_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%2.2lf", readout_dbl);
	gtk_clist_set_text (GTK_CLIST (grid_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_T1_value");
	readout_int = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%d", readout_int);
	gtk_clist_set_text (GTK_CLIST (grid_list), selected_row, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_T2T1_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%2.2lf", readout_dbl);
	gtk_clist_set_text (GTK_CLIST (grid_list), selected_row, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_R1a_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%2.2lf", readout_dbl);
	gtk_clist_set_text (GTK_CLIST (grid_list), selected_row, 4, working_str);

	readout_widget = lookup_widget (PHOEBE_calculate_grid_edit_parameters, "synthetic_grid_parameters_R2R1_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%2.2lf", readout_dbl);
	gtk_clist_set_text (GTK_CLIST (grid_list), selected_row, 5, working_str);

	gtk_widget_hide (PHOEBE_calculate_grid_edit_parameters);
	}

void on_synthetic_grid_parameters_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_calculate_grid_edit_parameters);
	}

void read_in_data_file_info (GtkWidget *parent, PHOEBE_data_record *input)
	{
	/* This function reads in the experimental data values from parent widget,  */
	/* which can be either PHOEBE_assign_data_file for LCs or PHOEBE_assign_rv_ */
	/* _data_file for RVs. Variable input holds only one element of LC and RV   */
	/* array records - the one selected in main PHOEBE window.                  */
	/*                                                                          */
	/* Data that is read here:                                                  */
	/*                                                                          */
	/* Column 1 contents:  independent variable (HJD, phase)                    */
	/* Column 2 contents:  dependent variable (magnitude, flux)                 */
	/* Column 3 contents:  weighting (real weights, integer weights, undefined) */
	/* Filename:           experimental data filename                           */
	/* Standard deviation: sigma of experimental data set                       */
	/* Filter:             filter of experimental data set                      */

	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	int selected_row;

	int i;
	int modified = 0;

	char working_string[255];
	char *working_str = working_string;

	GtkWidget *readout_widget;
	char      *readout_str;
	double     readout_dbl;

	/* Read out what's in column 1 of the data file:                            */
	readout_widget = lookup_widget (parent, "data_file_column_1_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (input->column1, "%s", readout_str);

	/* Read out what's in column 2 of the data file:                            */
	readout_widget = lookup_widget (parent, "data_file_column_2_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (input->column2, "%s", readout_str);

	/* Read out what's in column 3 of the data file:                            */
	readout_widget = lookup_widget (parent, "data_file_column_3_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (input->column3, "%s", readout_str);

	/* Read out the filename:                                                   */
	readout_widget = lookup_widget (parent, "data_file_filename_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	sprintf (input->filename, "%s", readout_str);

	/* Read out standard deviation:                                             */
	readout_widget = lookup_widget (parent, "data_file_sigma_value");
	readout_dbl = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (input->sigma, "%lf", readout_dbl);

	/* Read out the filter name:                                                */
	readout_widget = lookup_widget (parent, "data_file_filter_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));

	/* This is where things get a little trickier: if there are two or more LCs */
	/* or RVs in the same filter, we want to tell them apart somehow; that is   */
	/* why we append a #number to their names. We have to do it for all possi-  */
	/* ble combinations -- even if one LC and one RV are in the same filter,    */
	/* they must be separated the same way.                                     */

	/* First, let's see what record are we editing, because we don't want to    */
	/* compare filter's name against itself:                                    */
	if (parent == PHOEBE_assign_data_file)
		selected_row = (int) ((GList *) (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list"))->selection))->data;
	if (parent == PHOEBE_assign_rv_data_file)
		selected_row = (int) ((GList *) (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list"))->selection))->data;

	i = 0;
	while (i < lc_no)
		{
		if (
		   (strncmp (PHOEBE_lc_data[i].filter, readout_str, strlen (readout_str)) == 0) &&
		   (strchr (readout_str, '#') == NULL) &&
			 (strcmp (readout_str, PHOEBE_lc_data[selected_row].filter) != 0)
			 )
			{
			sprintf (PHOEBE_lc_data[i].filter, "%s #%d", readout_str, modified+1);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), i, 3, PHOEBE_lc_data[i].filter);
			modified += 1;
			}
		i++;
		}

	i = 0;
	while (i < rv_no)
		{
		if (
		   (strncmp (PHOEBE_rv_data[i].filter, readout_str, strlen (readout_str)) == 0) &&
			 (strchr (readout_str, '#') == NULL) &&
			 (strcmp (readout_str, PHOEBE_rv_data[selected_row].filter) != 0)
			 )
			{
			sprintf (PHOEBE_rv_data[i].filter, "%s #%d", readout_str, modified+1);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), i, 3, PHOEBE_rv_data[i].filter);
			modified += 1;
			}
		i++;
		}

	if (modified > 0)
		{
		sprintf (working_str, "%s #%d", readout_str, modified+1);
		readout_str = working_string;
		}

	sprintf (input->filter, "%s", readout_str);

	return;
	}

void on_data_lc_edit_data_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "data_lc_info_list");
	int selected_row = (int) ((GList *) (GTK_CLIST (lc_list)->selection))->data;

	GtkWidget *readout_widget;

	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_column_1_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_lc_data[selected_row].column1);

	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_column_2_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_lc_data[selected_row].column2);

	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_column_3_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_lc_data[selected_row].column3);
	
	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_filename_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_lc_data[selected_row].filename);

	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_sigma_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (PHOEBE_lc_data[selected_row].sigma));

	readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_filter_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_lc_data[selected_row].filter);

	gtk_widget_show (PHOEBE_assign_data_file);
	}

gboolean on_data_lc_info_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "data_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (lc_no != 0) )
		on_data_lc_edit_data_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "data_lc_edit_data_entry_button")), (gpointer) lc_list);

	return FALSE;
	}

void on_data_rv_edit_data_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "data_rv_info_list");
	int selected_row = (int) ((GList *) (GTK_CLIST (rv_list)->selection))->data;

	GtkWidget *readout_widget;

	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_column_1_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_rv_data[selected_row].column1);

	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_column_2_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_rv_data[selected_row].column2);

	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_column_3_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_rv_data[selected_row].column3);
	
	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_filename_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_rv_data[selected_row].filename);

	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_sigma_value");
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (PHOEBE_rv_data[selected_row].sigma));

	readout_widget = lookup_widget (PHOEBE_assign_rv_data_file, "data_file_filter_entry");
	gtk_entry_set_text (GTK_ENTRY (readout_widget), PHOEBE_rv_data[selected_row].filter);

	gtk_widget_show (PHOEBE_assign_rv_data_file);
	}

gboolean on_data_rv_info_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "data_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (rv_no != 0) )
		on_data_rv_edit_data_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "data_rv_edit_data_entry_button")), (gpointer) rv_list);

	return FALSE;
	}

void on_data_rv_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "data_rv_info_list");

	int selected_row = (int) ((GList *) (GTK_CLIST (rv_list)->selection))->data;

	read_in_data_file_info (PHOEBE_assign_rv_data_file, &PHOEBE_rv_data[selected_row]);

	/* And now let's fill that row with new information:                        */
	gtk_clist_set_text (GTK_CLIST (rv_list), selected_row, 1, PHOEBE_rv_data[selected_row].filename);
	gtk_clist_set_text (GTK_CLIST (rv_list), selected_row, 2, PHOEBE_rv_data[selected_row].sigma);
	gtk_clist_set_text (GTK_CLIST (rv_list), selected_row, 3, PHOEBE_rv_data[selected_row].filter);

	/* Since we have no callback for changing labels, we have to do it manual-  */
	/* ly:                                                                      */
	on_data_rv_filter_changed ();
	add_filters_to_available_filter_lists ();

	/* Finally, let's hide the window and return to the main window.            */
	gtk_widget_hide (PHOEBE_assign_rv_data_file);
	}

void on_data_rv_file_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_rv_data_file);
	}

void on_data_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "data_lc_info_list");

	int selected_row = (int) ((GList *) (GTK_CLIST (lc_list)->selection))->data;

	read_in_data_file_info (PHOEBE_assign_data_file, &PHOEBE_lc_data[selected_row]);

	/* And now let's fill that row with new information:                        */
	gtk_clist_set_text (GTK_CLIST (lc_list), selected_row, 1, PHOEBE_lc_data[selected_row].filename);
	gtk_clist_set_text (GTK_CLIST (lc_list), selected_row, 2, PHOEBE_lc_data[selected_row].sigma);
	gtk_clist_set_text (GTK_CLIST (lc_list), selected_row, 3, PHOEBE_lc_data[selected_row].filter);

	/* Since we have no callback for changing labels, we have to do it manual-  */
	/* ly:                                                                      */
	on_data_lc_filter_changed ();
	add_filters_to_available_filter_lists ();

	/* Finally, let's hide the window and return to the main window.            */
	gtk_widget_hide (PHOEBE_assign_data_file);

	return;
	}

void on_data_file_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_data_file);
	}

void on_data_file_browse_button_clicked (GtkButton *button, gpointer user_data)
	{
	/* Function description... */

	/* We don't want to have file selection widgets for each different browse   */
	/* button, so we make a following trick: we assign an "output_entry" name   */
	/* to the calling entry widget; this is stored in user_data. The widget may */
	/* be either PHOEBE_assign_data_file for LCs or PHOEBE_assign_rv_data_file  */
	/* for RVs. Entry widgets in both parents have the same local names, so it  */
	/* it is safe to declare it this way. This declaration in no way overrides  */
	/* the original name declaration.                                           */
	gtk_object_set_data (GTK_OBJECT (PHOEBE_open_data_file), "output_entry", lookup_widget (GTK_WIDGET (user_data), "data_file_filename_entry"));

	gtk_widget_show (PHOEBE_open_data_file);
	}

void on_luminosities_lc_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (lc_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_filter_value");
	gtk_clist_get_text (GTK_CLIST (lc_list), selected_row, 0, &readout_str);
	gtk_label_set_text (GTK_LABEL (readout_widget), readout_str);

	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_hla_value");
	gtk_clist_get_text (GTK_CLIST (lc_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
	gtk_clist_get_text (GTK_CLIST (lc_list), selected_row, 2, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	gtk_widget_show (PHOEBE_assign_lc_luminosity);
	}

gboolean on_luminosities_lc_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (lc_no != 0) )
		on_luminosities_lc_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_lc_edit_entry_button")), (gpointer) lc_list);

	return FALSE;
	}

void on_luminosities_rv_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "luminosities_rv_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (rv_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_filter_value");
	gtk_clist_get_text (GTK_CLIST (rv_list), selected_row, 0, &readout_str);
	gtk_label_set_text (GTK_LABEL (readout_widget), readout_str);

	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_hla_value");
	gtk_clist_get_text (GTK_CLIST (rv_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
	gtk_clist_get_text (GTK_CLIST (rv_list), selected_row, 2, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	gtk_widget_show (PHOEBE_assign_rv_luminosity);
	}

gboolean on_luminosities_rv_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "luminosities_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (rv_no != 0) )
		on_luminosities_rv_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_rv_edit_entry_button")), (gpointer) rv_list);

	return FALSE;
	}

void on_assign_lc_luminosity_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char working_string[255];
	char *working_str = working_string;

	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (lc_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_hla_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (lc_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (lc_list), selected_row, 2, working_str);

	gtk_widget_hide (PHOEBE_assign_lc_luminosity);
	}

void on_assign_lc_luminosity_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_lc_luminosity);
	}

void on_assign_rv_luminosity_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *rv_list = lookup_widget (PHOEBE, "luminosities_rv_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (rv_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_hla_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (rv_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (rv_list), selected_row, 2, working_str);

	gtk_widget_hide (PHOEBE_assign_rv_luminosity);
	}

void on_assign_rv_luminosity_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_rv_luminosity);
	}

void on_defaults_button_clicked (GtkButton *button, gpointer user_data)
	{
	char filename_string[255];
	char *filename = filename_string;

	GtkWidget *notice_window;

	sprintf (filename, "%s/default.phoebe", PHOEBE_SHARE_DIR);
	if (file_exists (filename))
		{
		open_keyword_file (filename);
		print_to_status_bar ("Defaults restored.");
		}
	else
		notice_window = create_notice_window ("PHOEBE Notice", "PHOEBE Notice: Defaults file cannot be found", "The defaults file, \"defaults.phoebe\", resides in PHOEBE shared directory.", "Please verify the path to the shared directory in Settings->Configuration menu.", gtk_widget_destroy);
	}

gboolean on_luminosities_el3_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *lc_list = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (lc_no != 0) )
		on_luminosities_el3_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_lc_edit_entry_button")), (gpointer) lc_list);

	return FALSE;
	}

void on_luminosities_el3_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *el3_list = lookup_widget (PHOEBE, "luminosities_el3_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (el3_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_el3, "assign_el3_filter_value");
	gtk_clist_get_text (GTK_CLIST (el3_list), selected_row, 0, &readout_str);
	gtk_label_set_text (GTK_LABEL (readout_widget), readout_str);

	readout_widget = lookup_widget (PHOEBE_assign_el3, "assign_el3_el3_value");
	gtk_clist_get_text (GTK_CLIST (el3_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	gtk_widget_show (PHOEBE_assign_el3);
	}

void on_assign_el3_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *el3_list = lookup_widget (PHOEBE, "luminosities_el3_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (el3_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_el3, "assign_el3_el3_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (el3_list), selected_row, 1, working_str);

	gtk_widget_hide (PHOEBE_assign_el3);
	}

void on_assign_el3_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_el3);
	}

gboolean on_ld_monochromatic_lc_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (lc_no != 0) )
		on_ld_monochromatic_lc_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_lc_edit_entry_button")), (gpointer) ld_list);

	return FALSE;
	}

void on_ld_monochromatic_lc_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (ld_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_filter_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 0, &readout_str);
	gtk_label_set_text (GTK_LABEL (readout_widget), readout_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_x1a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_y1a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 2, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_x2a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 3, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_y2a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 4, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	gtk_widget_show (PHOEBE_assign_ld_monochromatic_lc);
	}

void on_assign_ld_monochromatic_lc_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (ld_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_x1a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_y1a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_x2a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_lc, "assign_ld_monochromatic_lc_y2a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 4, working_str);

	gtk_widget_hide (PHOEBE_assign_ld_monochromatic_lc);
	}

void on_assign_ld_monochromatic_lc_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_ld_monochromatic_lc);
	}

gboolean on_luminosities_weighting_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "luminosities_weighting_info_list");
	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (lc_no != 0) )
		on_luminosities_weighting_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_weighting_edit_entry_button")), (gpointer) w_list);

	return FALSE;
	}

void on_luminosities_weighting_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "luminosities_weighting_info_list");
	GtkWidget *readout_widget;

	int selected_row;

	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (w_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_weighting, "assign_weighting_weighting_list_entry");
	gtk_clist_get_text (GTK_CLIST (w_list), selected_row, 1, &readout_str);
	gtk_entry_set_text (GTK_ENTRY (readout_widget), readout_str);

	gtk_widget_show (PHOEBE_assign_weighting);
	}

gboolean on_spots_primary_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "spots_primary_info_list");

	if (event->type == GDK_2BUTTON_PRESS)
		on_spots_edit_primary_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "spots_edit_primary_button")), (gpointer) w_list);

	return FALSE;
	}

void on_spots_edit_primary_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_assign_primary_spots);
	}

gboolean on_spots_secondary_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "spots_secondary_info_list");

	if (event->type == GDK_2BUTTON_PRESS)
		on_spots_edit_secondary_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "spots_edit_secondary_button")), (gpointer) w_list);

	return FALSE;
	}

void on_spots_edit_secondary_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_assign_secondary_spots);
	}

void on_assign_weighting_ok_button_clicked  (GtkButton *button, gpointer user_data)
	{
	GtkWidget *w_list = lookup_widget (PHOEBE, "luminosities_weighting_info_list");
	GtkWidget *readout_widget;

	int selected_row;

	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (w_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_weighting, "assign_weighting_weighting_list_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	gtk_clist_set_text (GTK_CLIST (w_list), selected_row, 1, readout_str);

	gtk_widget_hide (PHOEBE_assign_weighting);
	}

void on_assign_weighting_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_weighting);
	}

gboolean on_ld_monochromatic_rv_info_list_double_clicked (GtkWidget *widget, GdkEvent *event, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	if ( (event->type == GDK_2BUTTON_PRESS) && (rv_no != 0) )
		on_ld_monochromatic_rv_edit_entry_button_clicked (GTK_BUTTON (lookup_widget (PHOEBE, "luminosities_rv_edit_entry_button")), (gpointer) ld_list);

	return FALSE;
	}

void on_ld_monochromatic_rv_edit_entry_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (ld_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_filter_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 0, &readout_str);
	gtk_label_set_text (GTK_LABEL (readout_widget), readout_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_x1a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 1, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_y1a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 2, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_x2a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 3, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_y2a_value");
	gtk_clist_get_text (GTK_CLIST (ld_list), selected_row, 4, &readout_str);
	gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));

	gtk_widget_show (PHOEBE_assign_ld_monochromatic_rv);
	}

void on_assign_ld_monochromatic_rv_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *ld_list = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char *readout_str;

	char working_string[255];
	char *working_str = working_string;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (ld_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_x1a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_y1a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_x2a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_ld_monochromatic_rv, "assign_ld_monochromatic_rv_y2a_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%lf", value);
	gtk_clist_set_text (GTK_CLIST (ld_list), selected_row, 4, working_str);

	gtk_widget_hide (PHOEBE_assign_ld_monochromatic_rv);
	}

void on_assign_ld_monochromatic_rv_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_ld_monochromatic_rv);
	}

void populate_dc_chi2_info_list ()
	{
	GtkWidget *chi2_list = lookup_widget (PHOEBE_dc, "dc_chi2_info_list");
	int lc_no = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	int i;

	char entry_string[4][20];
	char *entry[4] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3]};

	gtk_clist_clear (GTK_CLIST (chi2_list));
	
	for (i = 0; i < rv_no; i++)
		{
		sprintf (entry[0], "%s", PHOEBE_rv_data[i].filter);
		sprintf (entry[1], "not calculated");
		sprintf (entry[2], "not calculated");
		sprintf (entry[3], "not calculated");
		gtk_clist_append (GTK_CLIST (chi2_list), entry);
		}
	for (i = 0; i < lc_no; i++)
		{
		sprintf (entry[0], "%s", PHOEBE_lc_data[i].filter);
		sprintf (entry[1], "not calculated");
		sprintf (entry[2], "not calculated");
		sprintf (entry[3], "not calculated");
		gtk_clist_append (GTK_CLIST (chi2_list), entry);
		}
	}

void populate_dc_parameters_info_list ()
	{
	GtkWidget *param_list = lookup_widget (PHOEBE_dc, "dc_parameters_info_list");
	int lc_no = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int i, j;
	int KEP[35];

	const char *keps[] = {"", "", "", "", "", "", "", "", "basic_sma_adjust", "orbit_e_adjust", "orbit_perr0_adjust", "advanced_f1_adjust", "advanced_f2_adjust", "orbit_pshift_adjust", "basic_vga_adjust", "basic_xincl_adjust", "advanced_gr1_adjust", "advanced_gr2_adjust", "basic_tavh_adjust", "basic_tavc_adjust", "advanced_alb1_adjust", "advanced_alb2_adjust", "advanced_phsv_adjust", "advanced_pcsv_adjust", "basic_rm_adjust", "basic_hjd0_adjust", "basic_period_adjust", "orbit_dpdt_adjust", "orbit_dperdt_adjust", "", "luminosities_hla_adjust", "luminosities_cla_adjust", "ld_x1a_adjust", "ld_x2a_adjust", "luminosities_el3_adjust"};
	const char *values[] = {"", "", "", "", "", "", "", "", "basic_sma_value", "orbit_e_value", "orbit_perr0_value", "advanced_f1_value", "advanced_f2_value", "orbit_pshift_value", "basic_vga_value", "basic_xincl_value", "advanced_gr1_value", "advanced_gr2_value", "basic_tavh_value", "basic_tavc_value", "advanced_alb1_value", "advanced_alb2_value", "advanced_phsv_value", "advanced_pcsv_value", "basic_rm_value", "basic_hjd0_value", "basic_period_value", "orbit_dpdt_value", "orbit_dperdt_value", "", "", "", "", "", ""};
	const char *keyword[] = {"XLAT1", "XLONG1", "RADSP1", "TEMSP1", "XLAT2", "XLONG2", "RADSP2", "TEMSP2", "SMA", "E", "PERR0", "F1", "F2", "PSHIFT", "VGA", "XINCL", "GR1", "GR2", "T1", "T2", "ALB1", "ALB2", "POT1", "POT2", "Q", "HJD0", "PERIOD", "DPDT", "DPERDT", "reserved", "HLA", "CLA", "X1A", "X2A", "EL3"};

	char entry_string[5][20];
	char *entry[5] = {entry_string[0], entry_string[1], entry_string[2], entry_string[3], entry_string[4]};

	GtkWidget *readout_widget;

	gtk_clist_clear (GTK_CLIST (param_list));

	for (i = 0; i <= 34; i++)
		{
		/* Reserved channel: */
		if (i == 29) continue;

		/* Spots: */
		if ( (i >= 0) && (i <= 7) )
			{
			KEP[i] = 1;
			continue;
			}

		/* Read out KEP value: */
		readout_widget = lookup_widget (PHOEBE, keps[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) KEP[i] = 0; else KEP[i] = 1;

                          /* P0  */    /* DPDT */   /* DPERDT */ /* HLA */    /* CLA */    /* X1A */    /* X2A */    /* EL3 */
		if ( (KEP[i] == 0) && (i != 26) && (i != 27) && (i != 28) && (i != 30) && (i != 31) && (i != 32) && (i != 33) && (i != 34) )
			{
			sprintf (entry[0], "%s", keyword[i]);
			sprintf (entry[1], "%lf", gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, values[i]))));
			sprintf (entry[2], "not calculated");
			sprintf (entry[3], "not calculated");
			sprintf (entry[4], "not calculated");
			gtk_clist_append (GTK_CLIST (param_list), entry);
			}
		if ( (KEP[i] == 0) && (i == 26) /* PERIOD */)
			{
			sprintf (entry[0], "%s", keyword[i]);
			sprintf (entry[1], "%s", gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE, values[i]))));
			sprintf (entry[2], "not calculated");
			sprintf (entry[3], "not calculated");
			sprintf (entry[4], "not calculated");
			gtk_clist_append (GTK_CLIST (param_list), entry);
			}
		if ( (KEP[i] == 0) && (i == 27) /* DPDT */)
			{
			sprintf (entry[0], "%s", keyword[i]);
			sprintf (entry[1], "%s", gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE, values[i]))));
			sprintf (entry[2], "not calculated");
			sprintf (entry[3], "not calculated");
			sprintf (entry[4], "not calculated");
			gtk_clist_append (GTK_CLIST (param_list), entry);
			}
		if ( (KEP[i] == 0) && (i == 28) /* DPERDT */)
			{
			sprintf (entry[0], "%s", keyword[i]);
			sprintf (entry[1], "%s", gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE, values[i]))));
			sprintf (entry[2], "not calculated");
			sprintf (entry[3], "not calculated");
			sprintf (entry[4], "not calculated");
			gtk_clist_append (GTK_CLIST (param_list), entry);
			}
		if ( (KEP[i] == 0) && (i == 30) /* HLA */)
			{
			for (j = 0; j < lc_no; j++)
				{
				sprintf (entry[0], "%s [%d]", keyword[i], j+1);
				gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), j, 1, &entry[1]);
				sprintf (entry[2], "not calculated");
				sprintf (entry[3], "not calculated");
				sprintf (entry[4], "not calculated");
				gtk_clist_append (GTK_CLIST (param_list), entry);
				}
			}
		if ( (KEP[i] == 0) && (i == 31) /* CLA */)
			{
			for (j = 0; j < lc_no; j++)
				{
				sprintf (entry[0], "%s [%d]", keyword[i], j+1);
				gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), j, 2, &entry[1]);
				sprintf (entry[2], "not calculated");
				sprintf (entry[3], "not calculated");
				sprintf (entry[4], "not calculated");
				gtk_clist_append (GTK_CLIST (param_list), entry);
				}
			}
		if ( (KEP[i] == 0) && (i == 32) /* X1A */)
			{
			for (j = 0; j < lc_no; j++)
				{
				sprintf (entry[0], "%s [%d]", keyword[i], j+1);
				gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), j, 1, &entry[1]);
				sprintf (entry[2], "not calculated");
				sprintf (entry[3], "not calculated");
				sprintf (entry[4], "not calculated");
				gtk_clist_append (GTK_CLIST (param_list), entry);
				}
			}
		if ( (KEP[i] == 0) && (i == 33) /* X2A */)
			{
			for (j = 0; j < lc_no; j++)
				{
				sprintf (entry[0], "%s [%d]", keyword[i], j+1);
				gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), j, 3, &entry[1]);
				sprintf (entry[2], "not calculated");
				sprintf (entry[3], "not calculated");
				sprintf (entry[4], "not calculated");
				gtk_clist_append (GTK_CLIST (param_list), entry);
				}
			}
		if ( (KEP[i] == 0) && (i == 34) /* EL3 */)
			{
			for (j = 0; j < lc_no; j++)
				{
				sprintf (entry[0], "%s [%d]", keyword[i], j+1);
				gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), j, 1, &entry[1]);
				sprintf (entry[2], "not calculated");
				sprintf (entry[3], "not calculated");
				sprintf (entry[4], "not calculated");
				gtk_clist_append (GTK_CLIST (param_list), entry);
				}
			}
		}

	return;
	}

void on_dc_calculate_button_clicked (GtkButton *button, gpointer user_data)
	{
	double DEL[35];
	int KEP[35];
	int i, j, k;

	char working_string[255];
	char *working_str = working_string;

	GtkWidget *readout_widget;

	const char *dels[] = {"", "", "", "", "", "", "", "", "basic_sma_del_value", "orbit_e_del_value", "orbit_perr0_del_value", "advanced_f1_del_value", "advanced_f2_del_value", "orbit_pshift_del_value", "basic_vga_del_value", "basic_xincl_del_value", "advanced_gr1_del_value", "advanced_gr2_del_value", "basic_tavh_del_value", "basic_tavc_del_value", "advanced_alb1_del_value", "advanced_alb2_del_value", "advanced_phsv_del_value", "advanced_pcsv_del_value", "basic_rm_del_value", "basic_hjd0_del_value", "basic_period_del_value", "orbit_dpdt_del_value", "orbit_dperdt_del_value", "", "luminosities_hla_del_value", "luminosities_cla_del_value", "ld_x1a_del_value", "ld_x2a_del_value", "luminosities_el3_del_value"};
	const char *keps[] = {"", "", "", "", "", "", "", "", "basic_sma_adjust", "orbit_e_adjust", "orbit_perr0_adjust", "advanced_f1_adjust", "advanced_f2_adjust", "orbit_pshift_adjust", "basic_vga_adjust", "basic_xincl_adjust", "advanced_gr1_adjust", "advanced_gr2_adjust", "basic_tavh_adjust", "basic_tavc_adjust", "advanced_alb1_adjust", "advanced_alb2_adjust", "advanced_phsv_adjust", "advanced_pcsv_adjust", "basic_rm_adjust", "basic_hjd0_adjust", "basic_period_adjust", "orbit_dpdt_adjust", "orbit_dperdt_adjust", "", "luminosities_hla_adjust", "luminosities_cla_adjust", "ld_x1a_adjust", "ld_x2a_adjust", "luminosities_el3_adjust"};

	PHOEBE_main_parameters main     = read_in_main_parameters ();
	PHOEBE_limb_darkening  ld       = read_in_ld_coefficients ();
	PHOEBE_spots           spots    = read_in_spots           ();
	PHOEBE_switches        switches = read_in_switches        ();
	PHOEBE_mms             mms      = read_in_mms             ();

	PHOEBE_dco_record      dco_record;
	double *correlation_matrix = NULL;

	GtkWidget *dc_cm_info_list_table;
	GtkWidget *dc_cm_info_list;
	char **dc_cm_list_column;
	double window_width, window_height;

	/* First, let us read out what is the independent variable that the user    */
	/* wants: this is the toggle-button in the Fitting tab:                     */
	readout_widget = lookup_widget (PHOEBE, "fitting_independent_variable_phases_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) switches.JDPHS = 2; else switches.JDPHS = 1;

	/* Let's set all DELs and KEPs to 0: */
	for (i = 0; i <= 34; i++)
		{
		DEL[i] = 0.0;
		KEP[i] = 1;
		}

	/* Here we go from 0 instead of 1 because cfortran.h takes care of OB1: */
	for (i = 0; i <= 34; i++)
		{
		/* Spots: */
		if ( (i >= 0) && (i <= 7) )
			{
			DEL[i] = 0.0;
			KEP[i] = 1;
			continue;
			}

		/* Reserved channel: */
		if (i == 29) continue;

		/* Read out KEP values:                                                   */
		readout_widget = lookup_widget (PHOEBE, keps[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) KEP[i] = 0; else KEP[i] = 1;

		/* Read out DEL values; the following ones are automatic:                 */
		if (i ==  8) continue;
		if (i == 14) continue;
		if (i == 25) continue;
		if (i == 26) continue;
		if (i == 27) continue;
		if (i == 28) continue;

		readout_widget = lookup_widget (PHOEBE, dels[i]);
		DEL[i] = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

		/* We have to fix units for T1 and T2 to T/10000K; VGA has its own DEL    */
		/* computation and the units of DEL are thus irrelevant.                  */
		if ( (i == 18) || (i == 19) ) DEL[i] /= 10000.0;
		}

	create_dci_input_file (DEL, KEP, main, ld, spots, switches, mms);

	sprintf (working_str, "%s/dc < /tmp/phoebe.dci > /tmp/phoebe.dco", PHOEBE_DC_DIR);
	system (working_str);

	/* Initialize arrays that will contain data from dco file:                  */
	dco_record.points_no      = phoebe_malloc ((switches.NLC + switches.IFVC1 + switches.IFVC2) * sizeof (*dco_record.points_no));
	dco_record.chi2           = phoebe_malloc ((switches.NLC + switches.IFVC1 + switches.IFVC2) * sizeof (*dco_record.chi2));

	readout_widget = lookup_widget (PHOEBE_dc, "dc_parameters_info_list");
	i = GTK_CLIST (readout_widget)->rows;      /* How many parameters are there */
	dco_record.param_no       = phoebe_malloc (i * sizeof (*dco_record.param_no));
	dco_record.curve_no       = phoebe_malloc (i * sizeof (*dco_record.curve_no));
	dco_record.original_value = phoebe_malloc (i * sizeof (*dco_record.original_value));
	dco_record.correction     = phoebe_malloc (i * sizeof (*dco_record.correction));
	dco_record.modified_value = phoebe_malloc (i * sizeof (*dco_record.modified_value));
	dco_record.sigma          = phoebe_malloc (i * sizeof (*dco_record.sigma));

	/* Initialize the correlation matrix space:                                 */
	correlation_matrix = phoebe_malloc (i*i * sizeof (*correlation_matrix));

	read_in_dco_values ("/tmp/phoebe.dco", &dco_record, correlation_matrix);

	/* 1. step: update parameter values:                                        */
	for (j = 0; j < i; j++)
		{
		sprintf (working_str, "%G", dco_record.original_value[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 1, working_str);
		sprintf (working_str, "%G", dco_record.correction[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 2, working_str);
		sprintf (working_str, "%G", dco_record.modified_value[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 3, working_str);
		sprintf (working_str, "%G", dco_record.sigma[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 4, working_str);
		}

	/* 2. step: update chi2 values:                                             */
	readout_widget = lookup_widget (PHOEBE_dc, "dc_chi2_info_list");
	for (j = 0; j < switches.NLC + switches.IFVC1 + switches.IFVC2; j++)
		{
		sprintf (working_str, "%d", dco_record.points_no[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 1, working_str);
		sprintf (working_str, "%lf", dco_record.chi2[j]);
		gtk_clist_set_text (GTK_CLIST (readout_widget), j, 3, working_str);
		}

	/* 3. step: update correlation matrix output:                               */

	/* If the matrix exists from previous calculation, destroy it:              */
	if (GTK_BIN (lookup_widget (PHOEBE_dc_correlation_matrix, "dc_correlation_matrix_main_frame"))->child != NULL)
		gtk_widget_destroy (GTK_WIDGET (GTK_BIN (lookup_widget (PHOEBE_dc_correlation_matrix, "dc_correlation_matrix_main_frame"))->child));

	/* Let's resize the window:                                                 */
	if (i < 10) window_width  = 48+(i+1)*67; else window_width  = 48+11*67;
	if (i < 10) window_height = 62+(i+1)*16; else window_height = 62+11*16;
	gtk_window_set_default_size (GTK_WINDOW (PHOEBE_dc_correlation_matrix), window_width, window_height);

	dc_cm_info_list_table = gtk_scrolled_window_new (NULL, NULL);
	gtk_widget_ref (dc_cm_info_list_table);
	gtk_object_set_data_full (GTK_OBJECT (PHOEBE_dc_correlation_matrix), "dc_parameters_info_list_table", dc_cm_info_list_table, (GtkDestroyNotify) gtk_widget_unref);
	gtk_widget_show (dc_cm_info_list_table);
	gtk_container_add (GTK_CONTAINER (lookup_widget (PHOEBE_dc_correlation_matrix, "dc_correlation_matrix_main_frame")), dc_cm_info_list_table);
	gtk_container_set_border_width (GTK_CONTAINER (dc_cm_info_list_table), 5);
	gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (dc_cm_info_list_table), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

	/* We create the list with (i+1) dimension because of heading labels.       */
	dc_cm_info_list = gtk_clist_new (i+1);
	gtk_widget_ref (dc_cm_info_list);
	gtk_object_set_data_full (GTK_OBJECT (PHOEBE_dc_correlation_matrix), "dc_cm_info_list", dc_cm_info_list, (GtkDestroyNotify) gtk_widget_unref);
	gtk_widget_show (dc_cm_info_list);
	gtk_container_add (GTK_CONTAINER (dc_cm_info_list_table), dc_cm_info_list);
	for (j = 0; j <= i; j++)
		{
	  gtk_clist_set_column_width (GTK_CLIST (dc_cm_info_list), j, 60);
		gtk_clist_set_column_justification (GTK_CLIST (dc_cm_info_list), j, GTK_JUSTIFY_RIGHT);
		}
	gtk_clist_set_column_justification (GTK_CLIST (dc_cm_info_list), 0, GTK_JUSTIFY_CENTER);
	gtk_clist_column_titles_hide (GTK_CLIST (dc_cm_info_list));

	/* First we allocate space for a single row entry:                          */
	dc_cm_list_column = phoebe_malloc ( (i+1) * sizeof (char *) );
	for (j = 0; j <= i; j++)
		dc_cm_list_column[j] = phoebe_malloc (15 * sizeof (char));

	/* Let's populate the heading row:                                          */
	readout_widget = lookup_widget (PHOEBE_dc, "dc_parameters_info_list");
	sprintf (dc_cm_list_column[0], "");
	for (j = 1; j <= i; j++)
		{
		gtk_clist_get_text (GTK_CLIST (readout_widget), j-1, 0, &working_str);
		sprintf (dc_cm_list_column[j], "%s", working_str);
		}
	gtk_clist_append (GTK_CLIST (dc_cm_info_list), dc_cm_list_column);

	/* Next, we put in all correlation matrix values:                           */
	for (j = 0; j < i; j++)
		{
		gtk_clist_get_text (GTK_CLIST (readout_widget), j, 0, &working_str);
		sprintf (dc_cm_list_column[0], "%s", working_str);
		for (k = 1; k <= i; k++)
			sprintf (dc_cm_list_column[k], "%lf", correlation_matrix[j*i+(k-1)]);
		gtk_clist_append (GTK_CLIST (dc_cm_info_list), dc_cm_list_column);
		}

	/* Finally, let's free the row space:                                       */
	for (j = 0; j <= i; j++) free (dc_cm_list_column[j]);
	free (dc_cm_list_column);

	/* Free all dco_record arrays:                                              */
	free (dco_record.points_no);
	free (dco_record.chi2);
	free (dco_record.param_no);
	free (dco_record.curve_no);
	free (dco_record.original_value);
	free (dco_record.correction);
	free (dco_record.modified_value);
	free (dco_record.sigma);
	
	/* Free the correlation matrix:                                             */
	free (correlation_matrix);
	}

void on_dc_update_corrections_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *par_list = lookup_widget (PHOEBE_dc, "dc_parameters_info_list");
	int rows_present = GTK_CLIST (par_list)->rows;

	const char *values[] = {"", "", "", "", "", "", "", "", "basic_sma_value", "orbit_e_value", "orbit_perr0_value", "advanced_f1_value", "advanced_f2_value", "orbit_pshift_value", "basic_vga_value", "basic_xincl_value", "advanced_gr1_value", "advanced_gr2_value", "basic_tavh_value", "basic_tavc_value", "advanced_alb1_value", "advanced_alb2_value", "advanced_phsv_value", "advanced_pcsv_value", "basic_rm_value", "basic_hjd0_value", "basic_period_value", "orbit_dpdt_value", "orbit_dperdt_value", "", "", "", "", "", ""};
	const char *keyword[] = {"XLAT1", "XLONG1", "RADSP1", "TEMSP1", "XLAT2", "XLONG2", "RADSP2", "TEMSP2", "SMA", "E", "PERR0", "F1", "F2", "PSHIFT", "VGA", "XINCL", "GR1", "GR2", "T1", "T2", "ALB1", "ALB2", "POT1", "POT2", "Q", "HJD0", "PERIOD", "DPDT", "DPERDT", "reserved", "HLA", "CLA", "X1A", "X2A", "EL3"};

	int i, j;

	GtkWidget *readout_widget;
	char      *readout_str;
	int        readout_int;

	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	/* First, let's check if the list contains any elements:                    */
	if (rows_present == 0) return;

	/* Next, let's check if we have anything to update, because if the user     */
	/* clicked on this button when nothing was calculated, atof() would fail.   */
	gtk_clist_get_text (GTK_CLIST (par_list), 0, 3, &readout_str);
	if (strcmp (readout_str, "not calculated") == 0) return;
	
	for (i = 0; i < rows_present; i++)
		{
		gtk_clist_get_text (GTK_CLIST (par_list), i, 0, &readout_str);
		for (j = 0; j < 34; j++)
			{
			if (strcmp (readout_str, keyword[j]) == 0)
				{
				gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
				readout_widget = lookup_widget (PHOEBE, values[j]);

				/* At this point we must differentiate between spin buttons and entry */
				/* boxes (for double-precision parameters):                           */
				if ( (strcmp (keyword[j], "DPDT") == 0)   ||
				     (strcmp (keyword[j], "PERIOD") == 0) ||
				     (strcmp (keyword[j], "HJD0") == 0)   ||
				     (strcmp (keyword[j], "DPERDT") == 0) )
					gtk_entry_set_text (GTK_ENTRY (readout_widget), readout_str);
				else
					gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), atof (readout_str));
				}
			if (strncmp (readout_str, keyword[j], 3) == 0)
				{
				/* We have to take care of the curve-dependent parameters HLA, CLA,   */
				/* X1A, X2A and EL3:                                                  */
				if (strncmp (readout_str, "HLA", 3) == 0)
					{
					sscanf (readout_str, "HLA [%d]", &readout_int);
					gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
					readout_widget = lookup_widget (PHOEBE, "luminosities_lc_info_list");
					gtk_clist_set_text (GTK_CLIST (readout_widget), readout_int - 1, 1, readout_str);
					}
				if (strncmp (readout_str, "CLA", 3) == 0)
					{
					sscanf (readout_str, "CLA [%d]", &readout_int);
					gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
					readout_widget = lookup_widget (PHOEBE, "luminosities_lc_info_list");
					gtk_clist_set_text (GTK_CLIST (readout_widget), readout_int - 1, 2, readout_str);
					}
				if (strncmp (readout_str, "X1A", 3) == 0)
					{
					sscanf (readout_str, "X1A [%d]", &readout_int);
					gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
					readout_widget = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
					gtk_clist_set_text (GTK_CLIST (readout_widget), readout_int - 1, 1, readout_str);
					}
				if (strncmp (readout_str, "X2A", 3) == 0)
					{
					sscanf (readout_str, "X2A [%d]", &readout_int);
					gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
					readout_widget = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
					gtk_clist_set_text (GTK_CLIST (readout_widget), readout_int - 1, 3, readout_str);
					}
				if (strncmp (readout_str, "EL3", 3) == 0)
					{
					sscanf (readout_str, "EL3 [%d]", &readout_int);
					gtk_clist_get_text (GTK_CLIST (par_list), i, 3, &readout_str);
					readout_widget = lookup_widget (PHOEBE, "luminosities_el3_info_list");
					gtk_clist_set_text (GTK_CLIST (readout_widget), readout_int - 1, 1, readout_str);
					}
				}
			}
		}

	/* We have now updated all main PHOEBE widgets, we have to update DC window */
	/* as well (move changed to original value and erase corrections):          */
	populate_dc_parameters_info_list ();

	/* Finally, we have to update chi2 info list:                               */
	readout_widget = lookup_widget (PHOEBE_dc, "dc_chi2_info_list");
	rows_present = GTK_CLIST (readout_widget)->rows;
	for (i = 0; i < rows_present; i++)
		{
		gtk_clist_get_text (GTK_CLIST (readout_widget), i, 3, &readout_str);
		gtk_clist_set_text (GTK_CLIST (readout_widget), i, 2, readout_str);
		gtk_clist_set_text (GTK_CLIST (readout_widget), i, 3, "not calculated");
		}
	}

void on_dc_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_dc);
	}

void on_dc_update_selection_button_clicked (GtkButton *button, gpointer user_data)
	{
	}

void on_dc_show_quickbar_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_fitting_quickbar);
	}

void on_fitting_fit_button_clicked (GtkButton *button, gpointer user_data)
	{
	/* This function shows the fitting window on the screen. The values within  */
	/* need not be populated here, for every click (toggle) of Adjust switches  */
	/* is catched and the change reflected in this window through a separate    */
	/* callback.                                                                */

	gtk_widget_show (PHOEBE_dc);
	}

void on_adjust_switch_toggled_update_fitting_window (GtkToggleButton *togglebutton, gpointer user_data)
	{
	populate_dc_parameters_info_list ();
	populate_dc_chi2_info_list ();
	}

void on_plot_lc_plot_to_file_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_plot_to_file);
	gtk_object_set_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on", user_data);
	}

void on_plot_rv_plot_to_file_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_plot_to_file);
	gtk_object_set_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on", user_data);
	}

void on_fitting_chi2_plot_to_file_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_plot_to_file);
	gtk_object_set_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on", user_data);
	}

void on_plot_to_file_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	char *device = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE_plot_to_file, "plot_to_file_device_list_entry")));

	char prefix_string[255];
	char *prefix_str = prefix_string;

	char working_string[255];
	char *working_str = working_string;

	if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
		sprintf (prefix_str, "my_lc_plot");
	if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
		sprintf (prefix_str, "my_rv_plot");
	if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
		sprintf (prefix_str, "my_chi2_plot");

	if (strcmp (device, "Encapsulated Postscript (.eps)") == 0)
		sprintf (working_str, "%s.eps", prefix_str);
	if (strcmp (device, "Plain Text Table (.ascii)") == 0)
		sprintf (working_str, "%s.ascii", prefix_str);
	if (strcmp (device, "X-Windows Pixmap (.xpm)") == 0)
		sprintf (working_str, "%s.xpm", prefix_str);
	if (strcmp (device, "Graphics Interchange Format (.gif)") == 0)
		sprintf (working_str, "%s.gif", prefix_str);
	if (strcmp (device, "Small GIF: 256x128 (.gif)") == 0)
		sprintf (working_str, "%s.gif", prefix_str);
	if (strcmp (device, "Portable Pixmap (.ppm)") == 0)
		sprintf (working_str, "%s.ppm", prefix_str);

	gtk_file_selection_set_filename (GTK_FILE_SELECTION (PHOEBE_plot_to_file_selector), working_str);

	gtk_widget_hide (PHOEBE_plot_to_file);
	gtk_widget_show (PHOEBE_plot_to_file_selector);
	}

void on_plot_to_file_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_plot_to_file);
	}

void on_plot_to_file_selector_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	char *device = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE_plot_to_file, "plot_to_file_device_list_entry")));
	char *filename = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_plot_to_file_selector));

	if (strcmp (device, "Encapsulated Postscript (.eps)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (eps, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (eps, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (eps, filename);
		}
	if (strcmp (device, "Plain Text Table (.ascii)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (ascii, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (ascii, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (ascii, filename);
		}
	if (strcmp (device, "X-Windows Pixmap (.xpm)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (xpm, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (xpm, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (xpm, filename);
		}
	if (strcmp (device, "Graphics Interchange Format (.gif)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (gif, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (gif, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (gif, filename);
		}
	if (strcmp (device, "Small GIF: 256x128 (.gif)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (tinygif, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (tinygif, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (tinygif, filename);
		}
	if (strcmp (device, "Portable Pixmap (.ppm)") == 0)
		{
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_lc, "plot_lc_plot_to_file_button"))
			plot_lc_plot (ppm, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE_plot_rv, "plot_rv_plot_to_file_button"))
			plot_rv_plot (ppm, filename);
		if (GTK_WIDGET (gtk_object_get_data (GTK_OBJECT (PHOEBE_plot_to_file), "initiated_by_clicking_on")) == lookup_widget (PHOEBE, "fitting_chi2_plot_to_file_button"))
			plot_chi2_plot (ppm, filename);
		}

	gtk_widget_hide (PHOEBE_plot_to_file_selector);
	}

void on_plot_to_file_selector_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_plot_to_file_selector);
	}

void on_data_model_entry_changed (GtkEditable *editable, gpointer user_data)
	{
	/* First let's put together a list of constrained parameters along with all */
	/* associated widgets for easier handling:                                  */
	const char *pcsv[] = {"advanced_pcsv_label", "advanced_pcsv_calculate_button", "advanced_pcsv_description", "advanced_pcsv_value", "advanced_pcsv_adjust", "advanced_pcsv_del_label", "advanced_pcsv_del_value", "advanced_pcsv_label_min", "advanced_pcsv_label_max", "advanced_pcsv_value_min", "advanced_pcsv_value_max"};
	const char *gr2[]  = {"advanced_gr2_label", "advanced_gr2_description", "advanced_gr2_value", "advanced_gr2_adjust", "advanced_gr2_del_label", "advanced_gr2_del_value", "advanced_gr2_label_min", "advanced_gr2_label_max", "advanced_gr2_value_min", "advanced_gr2_value_max"};
	const char *alb2[] = {"advanced_alb2_label", "advanced_alb2_description", "advanced_alb2_value", "advanced_alb2_adjust", "advanced_alb2_del_label", "advanced_alb2_del_value", "advanced_alb2_label_min", "advanced_alb2_label_max", "advanced_alb2_value_min", "advanced_alb2_value_max"};
	const char *tavc[] = {"basic_tavc_label", "basic_tavc_description", "basic_tavc_value", "basic_tavc_adjust", "basic_tavc_del_label", "basic_tavc_del_value", "basic_tavc_label_min", "basic_tavc_label_max", "basic_tavc_value_min", "basic_tavc_value_max"};
	const char *cla[]  = {"luminosities_lc_info_secondary_star_label", "luminosities_cla_adjust", "luminosities_cla_del_label", "luminosities_cla_del_value", "luminosities_rv_info_secondary_star_label"};
	const char *ld[]   = {"ld_monochromatic_lc_x2a_label", "ld_monochromatic_lc_y2a_label", "ld_monochromatic_rv_x2a_label", "ld_monochromatic_rv_y2a_label", "ld_x2a_adjust", "ld_x2a_del_label", "ld_x2a_del_value"};
	const char *the[]  = {"data_the_description", "data_the_label", "data_the_value", "data_the_description_2"};
	int i;

	char *readout_str = gtk_entry_get_text (GTK_ENTRY (lookup_widget (PHOEBE, "data_model_list_entry")));
	GtkWidget *readout_widget;

	if (strcmp (readout_str, "Detached binary") == 0)
		{
		/* 1. Surface potential PCSV isn't constrained:                           */
		for (i = 0; i < 11; i++)
			{
			readout_widget = lookup_widget (PHOEBE, pcsv[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 2. Gravity brightening GR2 isn't constrained:                          */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, gr2[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 3. Bolometric albedo ALB2 isn't constrained:                           */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, alb2[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 4. Secondary temperature TAVC isn't constrained:                       */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, tavc[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 5. Secondary star luminosities CLA are constrained:                    */
		for (i = 0; i < 5; i++)
			{
			readout_widget = lookup_widget (PHOEBE, cla[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
		/* 6. Limb darkening coefficients X2A and Y2A aren't constrained:         */
		for (i = 0; i < 7; i++)
			{
			readout_widget = lookup_widget (PHOEBE, ld[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 7. The duration of eclipse for X-Ray binaries is constrained:          */
		for (i = 0; i < 4; i++)
			{
			readout_widget = lookup_widget (PHOEBE, the[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		}
	
	if (strcmp (readout_str, "Double contact binary") == 0)
		{
		/* 1. Surface potential PCSV is constrained:                              */
		for (i = 0; i < 11; i++)
			{
			readout_widget = lookup_widget (PHOEBE, pcsv[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 2. Gravity brightening GR2 is constrained:                             */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, gr2[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 3. Bolometric albedo ALB2 is constrained:                              */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, alb2[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 4. Secondary temperature TAVC is constrained:                          */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, tavc[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 5. Secondary star luminosities CLA are constrained:                    */
		for (i = 0; i < 5; i++)
			{
			readout_widget = lookup_widget (PHOEBE, cla[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
		}
		/* 6. Limb darkening coefficients X2A and Y2A are constrained:            */
		for (i = 0; i < 7; i++)
			{
			readout_widget = lookup_widget (PHOEBE, ld[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 7. The duration of eclipse for X-Ray binaries is constrained:          */
		for (i = 0; i < 4; i++)
			{
			readout_widget = lookup_widget (PHOEBE, the[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}

	if (strcmp (readout_str, "Overcontact binary not in thermal contact") == 0)
		{
		/* 1. Surface potential PCSV is constrained:                              */
		for (i = 0; i < 11; i++)
			{
			readout_widget = lookup_widget (PHOEBE, pcsv[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 2. Gravity brightening GR2 is constrained:                             */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, gr2[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 3. Bolometric albedo ALB2 is constrained:                              */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, alb2[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 4. Secondary temperature TAVC isn't constrained:                       */
		for (i = 0; i < 10; i++)
			{
			readout_widget = lookup_widget (PHOEBE, tavc[i]);
			gtk_widget_set_sensitive (readout_widget, TRUE);
			}
		/* 5. Secondary star luminosities CLA are constrained:                    */
		for (i = 0; i < 5; i++)
			{
			readout_widget = lookup_widget (PHOEBE, cla[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_label");
			gtk_widget_set_sensitive (readout_widget, FALSE);
			readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
			gtk_widget_set_sensitive (readout_widget, FALSE);
		/* 6. Limb darkening coefficients X2A and Y2A are constrained:            */
		for (i = 0; i < 7; i++)
			{
			readout_widget = lookup_widget (PHOEBE, ld[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		/* 7. The duration of eclipse for X-Ray binaries is constrained:          */
		for (i = 0; i < 4; i++)
			{
			readout_widget = lookup_widget (PHOEBE, the[i]);
			gtk_widget_set_sensitive (readout_widget, FALSE);
			}
		}

	}

void on_ipb_switch_toggled (GtkToggleButton *togglebutton, gpointer user_data)
	{
	/* The change of the model also changes the sensitivity of this switch, so  */
	/* we don't have to check for constraints. We may freely change the sensi-  */
	/* tivity of dependent widgets.                                             */

	const char *cla[]  = {"luminosities_lc_info_secondary_star_label", "luminosities_cla_adjust", "luminosities_cla_del_label", "luminosities_cla_del_value"};
	int i;
	GtkWidget *readout_widget;

	int activity;
	
	if (GTK_TOGGLE_BUTTON (togglebutton)->active == TRUE) activity = TRUE; else activity = FALSE;
	
	for (i = 0; i < 4; i++)
		{
		readout_widget = lookup_widget (PHOEBE, cla[i]);
		gtk_widget_set_sensitive (readout_widget, activity);
		}
	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_label");
	gtk_widget_set_sensitive (readout_widget, activity);
	readout_widget = lookup_widget (PHOEBE_assign_lc_luminosity, "assign_lc_luminosity_cla_value");
	gtk_widget_set_sensitive (readout_widget, activity);
	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_label");
	gtk_widget_set_sensitive (readout_widget, activity);
	readout_widget = lookup_widget (PHOEBE_assign_rv_luminosity, "assign_rv_luminosity_cla_value");
	gtk_widget_set_sensitive (readout_widget, activity);
	}

void on_fitting_initiate_scripter_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *script_list = lookup_widget (PHOEBE_scripter, "scripter_info_list");

	char entry_string[3][255];
	char *entry[3] = {entry_string[0], entry_string[1], entry_string[2]};

	gtk_widget_show (PHOEBE_scripter);

	/* These are temporary script contents for the GAIA conference:             */
	gtk_clist_clear (GTK_CLIST (script_list));

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "HLA");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "XINCL");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Calculate");
	sprintf (entry[1], "PHSV, PCSV");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "PHSV, PCSV");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "HLA, XINCL, PHSV, PCSV");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "SMA, VGA");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);

	sprintf (entry[0], "Adjust");
	sprintf (entry[1], "HLA, XINCL, TAVH, TAVC, PHSV, PCSV");
	sprintf (entry[2], "not executed");
	gtk_clist_append (GTK_CLIST (script_list), entry);
	}

void on_scripter_close_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_scripter);
	}

void on_adjust_switch_toggled_update_fitting_quickbar (GtkToggleButton *togglebutton, gpointer user_data)
	{
	char *main_switches[]     = {"", "", "", "", "", "", "", "", "basic_sma_adjust", "orbit_e_adjust", "orbit_perr0_adjust", "advanced_f1_adjust", "advanced_f2_adjust", "orbit_pshift_adjust", "basic_vga_adjust", "basic_xincl_adjust", "advanced_gr1_adjust", "advanced_gr2_adjust", "basic_tavh_adjust", "basic_tavc_adjust", "advanced_alb1_adjust", "advanced_alb2_adjust", "advanced_phsv_adjust", "advanced_pcsv_adjust", "basic_rm_adjust", "basic_hjd0_adjust", "basic_period_adjust", "orbit_dpdt_adjust", "orbit_dperdt_adjust", "luminosities_hla_adjust", "luminosities_cla_adjust", "ld_x1a_adjust", "ld_x2a_adjust", "luminosities_el3_adjust"};
	char *quickbar_switches[] = {"", "", "", "", "", "", "", "", "fitting_quickbar_sma_switch", "fitting_quickbar_e_switch", "fitting_quickbar_perr0_switch", "fitting_quickbar_f1_switch", "fitting_quickbar_f2_switch", "fitting_quickbar_pshift_switch", "fitting_quickbar_vga_switch", "fitting_quickbar_xincl_switch", "fitting_quickbar_gr1_switch", "fitting_quickbar_gr2_switch", "fitting_quickbar_tavh_switch", "fitting_quickbar_tavc_switch", "fitting_quickbar_alb1_switch", "fitting_quickbar_alb2_switch", "fitting_quickbar_phsv_switch", "fitting_quickbar_pcsv_switch", "fitting_quickbar_rm_switch", "fitting_quickbar_hjd0_switch", "fitting_quickbar_period_switch", "fitting_quickbar_dpdt_switch", "fitting_quickbar_dperdt_switch", "fitting_quickbar_hla_switch", "fitting_quickbar_cla_switch", "fitting_quickbar_x1a_switch", "fitting_quickbar_x2a_switch", "fitting_quickbar_el3_switch"};

	GtkWidget *phoebe_switch, *quickbar_switch;

	int i;

	for (i = 0; i < 34; i++)
		{
		/* Spots still have to be supported:                                      */
		if (i < 8) continue;

		phoebe_switch   = lookup_widget (PHOEBE, main_switches[i]);
		quickbar_switch = lookup_widget (PHOEBE_fitting_quickbar, quickbar_switches[i]);

		if ( (GTK_TOGGLE_BUTTON (phoebe_switch)->active == TRUE) && (GTK_TOGGLE_BUTTON (quickbar_switch)->active == FALSE) )
			gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (quickbar_switch), TRUE);
		if ( (GTK_TOGGLE_BUTTON (phoebe_switch)->active == FALSE) && (GTK_TOGGLE_BUTTON (quickbar_switch)->active == TRUE) )
			gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (quickbar_switch), FALSE);
		}
	}

void on_fitting_quickbar_adjust_switch_toggled_update_main_switches (GtkToggleButton *togglebutton, gpointer user_data)
	{
	char *main_switches[]     = {"", "", "", "", "", "", "", "", "basic_sma_adjust", "orbit_e_adjust", "orbit_perr0_adjust", "advanced_f1_adjust", "advanced_f2_adjust", "orbit_pshift_adjust", "basic_vga_adjust", "basic_xincl_adjust", "advanced_gr1_adjust", "advanced_gr2_adjust", "basic_tavh_adjust", "basic_tavc_adjust", "advanced_alb1_adjust", "advanced_alb2_adjust", "advanced_phsv_adjust", "advanced_pcsv_adjust", "basic_rm_adjust", "basic_hjd0_adjust", "basic_period_adjust", "orbit_dpdt_adjust", "orbit_dperdt_adjust", "luminosities_hla_adjust", "luminosities_cla_adjust", "ld_x1a_adjust", "ld_x2a_adjust", "luminosities_el3_adjust"};
	char *quickbar_switches[] = {"", "", "", "", "", "", "", "", "fitting_quickbar_sma_switch", "fitting_quickbar_e_switch", "fitting_quickbar_perr0_switch", "fitting_quickbar_f1_switch", "fitting_quickbar_f2_switch", "fitting_quickbar_pshift_switch", "fitting_quickbar_vga_switch", "fitting_quickbar_xincl_switch", "fitting_quickbar_gr1_switch", "fitting_quickbar_gr2_switch", "fitting_quickbar_tavh_switch", "fitting_quickbar_tavc_switch", "fitting_quickbar_alb1_switch", "fitting_quickbar_alb2_switch", "fitting_quickbar_phsv_switch", "fitting_quickbar_pcsv_switch", "fitting_quickbar_rm_switch", "fitting_quickbar_hjd0_switch", "fitting_quickbar_period_switch", "fitting_quickbar_dpdt_switch", "fitting_quickbar_dperdt_switch", "fitting_quickbar_hla_switch", "fitting_quickbar_cla_switch", "fitting_quickbar_x1a_switch", "fitting_quickbar_x2a_switch", "fitting_quickbar_el3_switch"};

	GtkWidget *phoebe_switch, *quickbar_switch;

	int i;

	for (i = 0; i < 34; i++)
		{
		/* Spots still have to be supported:                                      */
		if (i < 8) continue;

		quickbar_switch = lookup_widget (PHOEBE_fitting_quickbar, quickbar_switches[i]);
		phoebe_switch   = lookup_widget (PHOEBE, main_switches[i]);

		if ( (GTK_TOGGLE_BUTTON (quickbar_switch)->active == TRUE) && (GTK_TOGGLE_BUTTON (phoebe_switch)->active == FALSE) )
			gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (phoebe_switch), TRUE);
		if ( (GTK_TOGGLE_BUTTON (quickbar_switch)->active == FALSE) && (GTK_TOGGLE_BUTTON (phoebe_switch)->active == TRUE) )
			gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (phoebe_switch), FALSE);
		}
	}

void on_step_value_changed_update_fitting_quickbar (GtkEditable *editable, gpointer user_data)
	{
	char *main_steps[]     = {"", "", "", "", "", "", "", "", "basic_sma_del_value", "orbit_e_del_value", "orbit_perr0_del_value", "advanced_f1_del_value", "advanced_f2_del_value", "orbit_pshift_del_value", "basic_vga_del_value", "basic_xincl_del_value", "advanced_gr1_del_value", "advanced_gr2_del_value", "basic_tavh_del_value", "basic_tavc_del_value", "advanced_alb1_del_value", "advanced_alb2_del_value", "advanced_phsv_del_value", "advanced_pcsv_del_value", "basic_rm_del_value", "basic_hjd0_del_value", "basic_period_del_value", "orbit_dpdt_del_value", "orbit_dperdt_del_value", "luminosities_hla_del_value", "luminosities_cla_del_value", "ld_x1a_del_value", "ld_x2a_del_value", "luminosities_el3_del_value"};
	char *quickbar_steps[] = {"", "", "", "", "", "", "", "", "fitting_quickbar_sma_step_value", "fitting_quickbar_e_step_value", "fitting_quickbar_perr0_step_value", "fitting_quickbar_f1_step_value", "fitting_quickbar_f2_step_value", "fitting_quickbar_pshift_step_value", "fitting_quickbar_vga_step_value", "fitting_quickbar_xincl_step_value", "fitting_quickbar_gr1_step_value", "fitting_quickbar_gr2_step_value", "fitting_quickbar_tavh_step_value", "fitting_quickbar_tavc_step_value", "fitting_quickbar_alb1_step_value", "fitting_quickbar_alb2_step_value", "fitting_quickbar_phsv_step_value", "fitting_quickbar_pcsv_step_value", "fitting_quickbar_rm_step_value", "fitting_quickbar_hjd0_step_value", "fitting_quickbar_period_step_value", "fitting_quickbar_dpdt_step_value", "fitting_quickbar_dperdt_step_value", "fitting_quickbar_hla_step_value", "fitting_quickbar_cla_step_value", "fitting_quickbar_x1a_step_value", "fitting_quickbar_x2a_step_value", "fitting_quickbar_el3_step_value"};

	GtkWidget *main_step, *quickbar_step;

	int i;

	for (i = 0; i < 34; i++)
		{
		/* Spots still have to be supported:                                      */
		if (i < 8) continue;

		if ( (i == 25) || (i == 26) )
			{
			/* These widgets are not spin-buttons and thus we cannot check their    */
			/* values the same way as others.                                       */
			continue;
			}

		main_step     = lookup_widget (PHOEBE, main_steps[i]);
		quickbar_step = lookup_widget (PHOEBE_fitting_quickbar, quickbar_steps[i]);

		if ( fabs (gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (main_step)) - gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (quickbar_step))) > 1E-5 )
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (quickbar_step), gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (main_step)));
		}
	}

void on_fitting_quickbar_step_value_changed_update_main_step_values (GtkEditable *editable, gpointer user_data)
	{
	char *main_steps[]     = {"", "", "", "", "", "", "", "", "basic_sma_del_value", "orbit_e_del_value", "orbit_perr0_del_value", "advanced_f1_del_value", "advanced_f2_del_value", "orbit_pshift_del_value", "basic_vga_del_value", "basic_xincl_del_value", "advanced_gr1_del_value", "advanced_gr2_del_value", "basic_tavh_del_value", "basic_tavc_del_value", "advanced_alb1_del_value", "advanced_alb2_del_value", "advanced_phsv_del_value", "advanced_pcsv_del_value", "basic_rm_del_value", "basic_hjd0_del_value", "basic_period_del_value", "orbit_dpdt_del_value", "orbit_dperdt_del_value", "luminosities_hla_del_value", "luminosities_cla_del_value", "ld_x1a_del_value", "ld_x2a_del_value", "luminosities_el3_del_value"};
	char *quickbar_steps[] = {"", "", "", "", "", "", "", "", "fitting_quickbar_sma_step_value", "fitting_quickbar_e_step_value", "fitting_quickbar_perr0_step_value", "fitting_quickbar_f1_step_value", "fitting_quickbar_f2_step_value", "fitting_quickbar_pshift_step_value", "fitting_quickbar_vga_step_value", "fitting_quickbar_xincl_step_value", "fitting_quickbar_gr1_step_value", "fitting_quickbar_gr2_step_value", "fitting_quickbar_tavh_step_value", "fitting_quickbar_tavc_step_value", "fitting_quickbar_alb1_step_value", "fitting_quickbar_alb2_step_value", "fitting_quickbar_phsv_step_value", "fitting_quickbar_pcsv_step_value", "fitting_quickbar_rm_step_value", "fitting_quickbar_hjd0_step_value", "fitting_quickbar_period_step_value", "fitting_quickbar_dpdt_step_value", "fitting_quickbar_dperdt_step_value", "fitting_quickbar_hla_step_value", "fitting_quickbar_cla_step_value", "fitting_quickbar_x1a_step_value", "fitting_quickbar_x2a_step_value", "fitting_quickbar_el3_step_value"};

	GtkWidget *main_step, *quickbar_step;

	int i;

	for (i = 0; i < 34; i++)
		{
		/* Spots still have to be supported:                                      */
		if (i < 8) continue;

		if ( (i == 25) || (i == 26) )
			{
			/* These widgets are not spin-buttons and thus we cannot check their    */
			/* values the same way as others.                                       */
			continue;
			}

		quickbar_step = lookup_widget (PHOEBE_fitting_quickbar, quickbar_steps[i]);
		main_step     = lookup_widget (PHOEBE, main_steps[i]);

		if ( fabs (gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (quickbar_step)) - gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (main_step))) > 1E-5 )
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (main_step), gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (quickbar_step)));
		}
	}

void on_test_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_menu_popup (GTK_MENU (PHOEBE_filter_menu), NULL, NULL, NULL, NULL, 1, 0);
	}

void on_data_file_dependent_variable_changed (GtkEditable *editable, gpointer user_data)
	{
	/* This function takes care that the reddening is allowed to be removed on- */
	/* ly when magnitudes are the dependent variable:                           */

	GtkWidget *readout_widget = lookup_widget (PHOEBE_assign_data_file, "data_file_column_2_entry");
	if (strcmp (gtk_entry_get_text (GTK_ENTRY (readout_widget)), "Magnitude") != 0)
		{
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (lookup_widget (PHOEBE_assign_data_file, "data_file_reddening_switch")), FALSE);
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_reddening_switch"), FALSE);
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_r_label"), FALSE);
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_r_value"), FALSE);
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_color_excess_label"), FALSE);
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_color_excess_value"), FALSE);
		}
	else
		gtk_widget_set_sensitive (lookup_widget (PHOEBE_assign_data_file, "data_file_reddening_switch"), TRUE);
	}

void on_spots_sprim_value_changed (GtkEditable *editable, gpointer user_data)
	{
	add_empty_record_to_spots_primary_info_list ();
	}

void on_spots_ssec_value_changed (GtkEditable *editable, gpointer user_data)
	{
	add_empty_record_to_spots_secondary_info_list ();
	}

void on_assign_primary_spots_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *sp_list = lookup_widget (PHOEBE, "spots_primary_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char working_string[255];
	char *working_str = working_string;

	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (sp_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_primary_spots, "assign_spots_xlat_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_primary_spots, "assign_spots_xlong_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_primary_spots, "assign_spots_radsp_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_primary_spots, "assign_spots_temsp_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 4, working_str);

	gtk_widget_hide (PHOEBE_assign_primary_spots);
	}

void on_assign_primary_spots_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_primary_spots);
	}

void on_assign_secondary_spots_ok_button_clicked (GtkButton *button, gpointer user_data)
	{
	GtkWidget *sp_list = lookup_widget (PHOEBE, "spots_secondary_info_list");
	GtkWidget *readout_widget;

	int selected_row;
	double value;

	char working_string[255];
	char *working_str = working_string;

	char *readout_str;

	/* Let's find the selected row:                                             */
	selected_row = (int) ((GList *) (GTK_CLIST (sp_list)->selection))->data;

	readout_widget = lookup_widget (PHOEBE_assign_secondary_spots, "assign_spots_xlat_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 1, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_secondary_spots, "assign_spots_xlong_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 2, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_secondary_spots, "assign_spots_radsp_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 3, working_str);

	readout_widget = lookup_widget (PHOEBE_assign_secondary_spots, "assign_spots_temsp_value");
	value = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
	sprintf (working_str, "%5.5lf", value);
	gtk_clist_set_text (GTK_CLIST (sp_list), selected_row, 4, working_str);

	gtk_widget_hide (PHOEBE_assign_secondary_spots);
	}

void on_assign_secondary_spots_cancel_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_hide (PHOEBE_assign_secondary_spots);
	}

void on_dc_show_correlation_matrix_button_clicked (GtkButton *button, gpointer user_data)
	{
	gtk_widget_show (PHOEBE_dc_correlation_matrix);
	}

