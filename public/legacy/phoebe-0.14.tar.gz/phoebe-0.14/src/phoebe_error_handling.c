#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void phoebe_fatal (char *message)
	{
	printf ("\nPHOEBE fatal: %s\n", message);
	exit (EXIT_FAILURE);
	}

void phoebe_warning (char *message)
	{
	printf ("\nPHOEBE warning: %s\n", message);
	}

void *phoebe_malloc (size_t size)
	{
	register void *value = malloc (size);
	if (value == 0) phoebe_fatal ("Virtual memory exhauseted.\n");
	return value;
	}

void *phoebe_realloc (void *ptr, size_t size)
	{
	register void *value = realloc (ptr, size);
	if (value == 0) phoebe_fatal ("Virtual memory exhauseted.\n");
	return value;
	}
