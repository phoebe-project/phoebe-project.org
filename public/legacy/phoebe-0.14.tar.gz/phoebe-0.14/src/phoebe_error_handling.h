#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void phoebe_fatal (char *message);
void phoebe_warning (char *message);
void *phoebe_malloc (size_t size);
void *phoebe_realloc (void *ptr, size_t size);
