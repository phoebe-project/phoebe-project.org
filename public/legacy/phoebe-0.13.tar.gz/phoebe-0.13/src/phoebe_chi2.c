#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "phoebe_global.h"

double calculate_chi2 (new_PHOEBE_data synthetic_data, new_PHOEBE_data experimental_data, double sigma)
	{
	int i, j;
	int breaked;
	double interpolated_y;

	double chi2 = 0.0;

	for (i = 0; i < experimental_data.ptsno; i++)
		{
		breaked = 0;
		for (j = 1; j < synthetic_data.ptsno; j++)
			{
			if (synthetic_data.indep[j] > experimental_data.indep[i])
				{
				breaked = 1;
				break;
				}
			}
		if (breaked == 1)
			{
			interpolated_y = synthetic_data.dep[j-1] + (experimental_data.indep[i] - 
			                 synthetic_data.indep[j-1]) / (synthetic_data.indep[j] - 
			                 synthetic_data.indep[j-1]) * (synthetic_data.dep[j] -
			                 synthetic_data.dep[j-1]);

			chi2 += pow (interpolated_y - experimental_data.dep[i], 2);
			}
		}

	return chi2 / 2.0 / sigma / sigma;
	}
