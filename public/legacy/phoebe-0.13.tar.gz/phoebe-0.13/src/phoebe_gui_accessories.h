#ifndef PHOEBE_GUI_ACCESSORIES_H
#define PHOEBE_GUI_ACCESSORIES_H 1

#include <gtk/gtk.h>

void phoebe_init ();

int  file_exists         (char *file_name);
void strip_string_tail   (char *in);
void print_to_status_bar (char *text);

GtkWidget *create_warning_window (char *title, char *main_label, char *description1, char *description2, GtkSignalFunc ok_function, GtkSignalFunc cancel_function);
GtkWidget *create_notice_window  (char *title, char *main_label, char *description1, char *description2, GtkSignalFunc ok_function);

void set_clist_justifications ();

void add_empty_record_to_all_lc_dependent_info_lists ();
void add_empty_record_to_all_rv_dependent_info_lists ();
void add_empty_record_to_lc_info_list ();
void add_empty_record_to_rv_info_list ();
void add_empty_record_to_luminosities_lc_info_list ();
void add_empty_record_to_luminosities_rv_info_list ();
void add_empty_record_to_luminosities_el3_info_list ();
void add_empty_record_to_ld_monochromatic_lc_info_list ();
void add_empty_record_to_ld_monochromatic_rv_info_list ();
void add_empty_record_to_luminosities_weighting_info_list ();

void add_filters_to_available_filter_lists ();
void add_filters_to_lc_plot_filter_list ();
void add_filters_to_rv_plot_filter_list ();
void add_filters_to_chi2_filter_list ();
void add_filters_to_ld_filter_list ();

#endif
