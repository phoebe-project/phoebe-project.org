#ifndef PHOEBE_GLOBAL_H
#define PHOEBE_GLOBAL_H 1

#include <gtk/gtk.h>

/* ************************************************************************** */
/*                       Global PHOEBE GTK+ widgets:                          */
/* ************************************************************************** */

GtkWidget *PHOEBE;
GtkWidget *PHOEBE_about;
GtkWidget *PHOEBE_assign_data_file;
GtkWidget *PHOEBE_assign_rv_data_file;
GtkWidget *PHOEBE_assign_lc_luminosity;
GtkWidget *PHOEBE_assign_rv_luminosity;
GtkWidget *PHOEBE_assign_el3;
GtkWidget *PHOEBE_assign_ld_monochromatic_lc;
GtkWidget *PHOEBE_assign_ld_monochromatic_rv;
GtkWidget *PHOEBE_assign_weighting;
GtkWidget *PHOEBE_calculate_grid;
GtkWidget *PHOEBE_calculate_grid_edit_parameters;
GtkWidget *PHOEBE_calculate_pcsv;
GtkWidget *PHOEBE_calculate_phsv;
GtkWidget *PHOEBE_configuration;
GtkWidget *PHOEBE_configuration_browse;
GtkWidget *PHOEBE_dc;
GtkWidget *PHOEBE_fitting_quickbar;
GtkWidget *PHOEBE_open_keyword_file;
GtkWidget *PHOEBE_open_data_file;
GtkWidget *PHOEBE_plot_lc;
GtkWidget *PHOEBE_plot_rv;
GtkWidget *PHOEBE_plot_to_file;
GtkWidget *PHOEBE_plot_to_file_selector;
GtkWidget *PHOEBE_ld_interpolation;
GtkWidget *PHOEBE_save_keyword_file;
GtkWidget *PHOEBE_scripter;

/* ************************************************************************** */
/*                     Global PHOEBE information strings:                     */
/* ************************************************************************** */

char PHOEBE_VERSION_NUMBER[20];
char PHOEBE_VERSION_DATE[20];

char USER_HOME_DIR[255];

char PHOEBE_HOME_DIR[255];
char PHOEBE_BASE_DIR[255];
char PHOEBE_CONFIG[255];
char PHOEBE_SOURCE_DIR[255];
char PHOEBE_SHARE_DIR[255];
char PHOEBE_TEMP_DIR[255];
char PHOEBE_DATA_DIR[255];
char PHOEBE_LC_DIR[255];
char PHOEBE_DC_DIR[255];
char PHOEBE_PLOTTING_PACKAGE[255];
char PHOEBE_PLOTTING_DIR[255];
int  PHOEBE_LD_SWITCH;
char PHOEBE_LD_DIR[255];


/* ************************************************************************** */
/*                     Global PHOEBE plotting constants:                      */
/* ************************************************************************** */

double LC_ZOOM_FACTOR;
double LC_X_OFFSET;
double LC_Y_OFFSET;

double RV_ZOOM_FACTOR;
double RV_X_OFFSET;
double RV_Y_OFFSET;


/* ************************************************************************** */
/*                       PHOEBE typedefs and structs:                         */
/* ************************************************************************** */

typedef struct PHOEBE_main_parameters
	{
	double SMA;       /* Semi-major axis                                        */
	double RM;        /* Mass ratio                                             */
	double PERIOD;    /* Period                                                 */
	double HJD0;      /* Heliocentric julian date at phase 0                    */
	double TAVH;      /* Primary star surface temperature                       */
	double TAVC;      /* Secondary star surface temperature                     */
	double XINCL;     /* Inclination                                            */
	double VGA;       /* System radial velocity                                 */
	double PHSV;      /* Primary star surface potential                         */
	double PCSV;      /* Secondary star surface potential                       */
	double GR1;       /* Primary star gravity brightening                       */
	double GR2;       /* Secondary star gravity brightening                     */
	double ALB1;      /* Primary star albedo                                    */
	double ALB2;      /* Secondary star albedo                                  */
	double F1;        /* Primary star synchronicity parameter                   */
	double F2;        /* Secondary star synchronicity parameter                 */
	double E;         /* Orbital eccentricity                                   */
	double PERR0;     /* Argument of periastron at phase 0                      */
	double DPERDT;    /* First time derivative of the argument of periastron    */
	double DPDT;      /* First time derivative of period                        */
	double PSHIFT;    /* Phase shift                                            */
	double MNORM;     /* Normalizing magnitude for input data files             */
	} PHOEBE_main_parameters;

typedef struct PHOEBE_switches
	{
	int    MPAGE;    /* What operation we want from WD                          */
	int    MODE;     /* What kind of binaries do we simulate                    */
	int    NLC;      /* Number of light curves                                  */
	int    IFVC1;    /* Is there a primary star RV curve available              */
	int    IFVC2;    /* Is there a secondary star RV curve available            */
	int    BINNING;  /* Should data be binned (useful for large databases)      */
	int    BINNO;    /* In case BINNING is on, this is the number of bins       */
	int    NPPL;     /* Number of points per line in a DCI file                 */
	int    MREF;     /* Reflection effect switch                                */
	int    NREF;     /* Number of reflections                                   */
	int    ICOR1;    /* Proximity and eclipse effects on primary star rv        */
	int    ICOR2;    /* Proximity and eclipse effects on secondary star rv      */
	int    JDPHS;    /* Independent variable: time or phase                     */
	int    NOISE;    /* Application of level-dependent weights                  */
	int    IPB;      /* Decouple temperature and luminosity for secondary star  */
	int    IFAT1;    /* Atmosphere model for primary star                       */
	int    IFAT2;    /* Atmosphere model for secondary star                     */
	int    N1;       /* Grid size for primary star                              */
	int    N2;       /* Grid size for secondary star                            */
	int    N1L;      /* Coarse grid size for primary star                       */
	int    N2L;      /* Coarse grid size for secondary star                     */
	int    ISYM;     /* Use symetrical derivatives                              */
	int    K0;       /* Scratch file option                                     */
	int    KDISK;    /* Scratch file switch                                     */
	double VUNIT;    /* Radial velocity units                                   */
	double THE;      /* The semi-duration of primary eclipse in phase units     */
	double XLAMDA;   /* Levenberg-Marquardt Step Coeficient Lambda              */
	} PHOEBE_switches;

typedef struct PHOEBE_curve_parameters
	{
	double PHNORM;   /* Phase where flux is normalized to FACTOR (usually 1)    */
	double MZERO;    /* Systematic magnitude shift for synthetic light curves   */
	double FACTOR;   /* Multiplication factor: flux -> FACTOR * flux            */
	double HJDST;    /* HJD of the starting point of the graph                  */
	double HJDSP;    /* HJD of the ending point of the graph                    */
	double HJDIN;    /* HJD increment between nodes                             */
	double PHSTRT;   /* Phase of the starting point of the graph                */
	double PHSTOP;   /* Phase of the ending point of the graph                  */
	double PHIN;     /* Phase increment between nodes                           */
	} PHOEBE_curve_parameters;


typedef struct PHOEBE_limb_darkening
	{
	int LD;          /* Which limb-darkening law to use                         */
	double XBOL1;    /* Primary star linear coefficient                         */
	double XBOL2;    /* Secondary star linear coefficient                       */
	double YBOL1;    /* Primary star non-linear coefficient                     */
	double YBOL2;    /* Secondary star non-linear coefficient                   */
	} PHOEBE_limb_darkening;

typedef struct PHOEBE_spots
	{
	int    IFSMV1;   /* Do spots move longitudinally on primary star            */
	int    IFSMV2;   /* Do spots move longitudinally on secondary star          */
	int    KSPA;     /* Is the adjustable spot on a primary star?   [1,2]       */
	int    NSPA;     /* Which spot do we want to adjust?                        */
	int    KSPB;     /* Is the adjustable spot on a secondary star? [1,2]       */
	int    NSPB;     /* Which spot do we want to adjust?                        */
	double XLAT1;    /* Primary star spot latitude                              */
	double XLONG1;   /* Primary star spot longitude                             */
	double RADSP1;   /* Primary star spot angular radius                        */
	double TEMSP1;   /* Primary star spot temperature                           */
	double XLAT2;    /* Secondary star spot latitude                            */
	double XLONG2;   /* Secondary star spot longitude                           */
	double RADSP2;   /* Secondary star spot angular radius                      */
	double TEMSP2;   /* Secondary star spot temperature                         */
	} PHOEBE_spots;

typedef struct PHOEBE_wl_dependent_parameters
	{
	double WLA;      /* Central wavelength of a given filter                    */
	double HLA;      /* Primary star luminosity                                 */
	double CLA;      /* Secondary star luminosity                               */
	double X1A;      /* Primary star linear limb darkening coefficient          */
	double Y1A;      /* Secondary star linear limb darkening coefficient        */
	double X2A;      /* Primary star non-linear limb darkening coefficient      */
	double Y2A;      /* Secondary star non-linear limb darkening coefficient    */
	double EL3;      /* Third light                                             */
	double OPSF;     /* Opacity function                                        */
	int    NOISE;    /* How level-dependent weights are to be applied           */
	double SIGMA;    /* Standard deviation of experimental data                 */
	double VGA;      /* Systemic radial velocity                                */
	} PHOEBE_wl_dependent_parameters;

/* OBSOLETE */
	typedef struct PHOEBE_data
		{
		double indep;
		double dep;
		double weight;
		} PHOEBE_data;
/* ******** */

typedef struct new_PHOEBE_data
	{
	int     ptsno;   /* The number of points that PHOEBE_data currently holds   */
	double *indep;   /* An array of independent data points                     */
	double *dep;     /* An array of dependent data points                       */
	double *weight;  /* An array of weights for data points                     */
	} new_PHOEBE_data;

typedef struct PHOEBE_data_record
	{
	char column1[20];
	char column2[20];
	char column3[20];
	char filename[255];
	char sigma[20];
	char filter[20];
	} PHOEBE_data_record;

typedef struct PHOEBE_synthetic_lc_record
	{
	double hjd;
	double phase;
	double primary_flux;
	double secondary_flux;
	double total_flux;
	double normalized_flux;
	double separation;
	double magnitude;
	} PHOEBE_synthetic_lc_record;

typedef struct PHOEBE_synthetic_rv_record
	{
	double hjd;
	double phase;
	double primary_norm_rv;
	double secondary_norm_rv;
	double primary_eclipse_corr;
	double secondary_eclipse_corr;
	double primary_rv;
	double secondary_rv;
	} PHOEBE_synthetic_rv_record;

typedef struct PHOEBE_dco_record
	{
	int    *points_no;      /* Array of data point numbers for all data curves  */
	double *chi2;           /* Array of chi2 values based on individual weights */
	int    *param_no;       /* The number of adjusted parameter (1--35)         */
	int    *curve_no;       /* The curve for which a given parameter applies    */
	double *original_value; /* Original value of a given parameter              */
	double *correction;     /* The correction to a given parameter              */
	double *modified_value; /* Modified value of a given parameter              */
	double *sigma;          /* Standard deviation of the parameter fit          */
	} PHOEBE_dco_record;

typedef struct PHOEBE_calculated_parameters
	{
	double mass_p;
	double mass_s;
	double radius_p;
	double radius_s;
	double mbol_p;
	double mbol_s;
	double logg_p;
	double logg_s;
	double psb_p;
	double psb_s;
	double surface_p;
	double surface_s;
	double rpole_p;
	double rpole_s;
	double rpoint_p;
	double rpoint_s;
	double rside_p;
	double rside_s;
	double rback_p;
	double rback_s;
	} PHOEBE_calculated_parameters;

typedef struct PHOEBE_mms
	{
	int on;          /* A switch to tell the program whether to use MMS or not  */
	int no;          /* A number of multiple subsets                            */
	int s1[35];      /* Multiple subset 1                                       */
	int s2[35];      /* Multiple subset 2                                       */
	int s3[35];      /* Multiple subset 3                                       */
	int s4[35];      /* Multiple subset 4                                       */
	int s5[35];      /* Multiple subset 5                                       */
	} PHOEBE_mms;

typedef enum PHOEBE_plot_device
	{
	x11,
	eps,
	ascii,
	xpm,
	gif,
	tinygif,
	ppm
	} PHOEBE_plot_device;

/* ************************************************************************** */
/*                         Static struct declarations:                        */
/* ************************************************************************** */

PHOEBE_data_record *PHOEBE_lc_data;
PHOEBE_data_record *PHOEBE_rv_data;

#endif
