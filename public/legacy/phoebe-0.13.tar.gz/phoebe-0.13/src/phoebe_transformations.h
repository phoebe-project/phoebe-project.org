#ifndef PHOEBE_TRANSFORMATIONS_H
#define PHOEBE_TRANSFORMATIONS_H 1

#include <gtk/gtk.h>

void transform_phase_to_hjd      (new_PHOEBE_data *data, double hjd0, double period);
void transform_hjd_to_phase      (new_PHOEBE_data *data, double hjd0, double period);
void transform_magnitude_to_flux (new_PHOEBE_data *data, double mnorm);
void transform_flux_to_magnitude (new_PHOEBE_data *data, double mnorm);
void transform_100kms_to_kms     (new_PHOEBE_data *data);
void transform_kms_to_100kms     (new_PHOEBE_data *data);

void normalize_rv_to_orbit       (new_PHOEBE_data *data, double sma, double period);

void transform_flux_sigma_to_magnitude_sigma (double flux_sigma, double mag_sigma);
void transform_magnitude_sigma_to_flux_sigma (double mag_sigma, double flux_sigma);

double estimate_zero_magnitude (PHOEBE_data *data, int pts_no);

PHOEBE_data *normalize_lc_at_phnorm      (PHOEBE_data *data, double bin_width, double factor, int PTSNO);

void get_plot_limits_of_data (new_PHOEBE_data data, double *xmin, double *ymin, double *xmax, double *ymax);

#endif
