/* src/config.h.  Generated automatically by configure.  */
/* src/config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have Linux gcc compiler. */
#define f2cFortran 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the mkdir function.  */
#define HAVE_MKDIR 1

/* Define if you have the <errno.h> header file.  */
#define HAVE_ERRNO_H 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the gdk_pixbuf library (-lgdk_pixbuf).  */
#define HAVE_LIBGDK_PIXBUF 1

/* Name of package */
#define PACKAGE "phoebe"

/* Version number of package */
#define VERSION "0.12"

