#include <stdlib.h>

#include <gtk/gtk.h>
#include <math.h>

#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_gui_support.h"

void transform_phase_to_hjd (new_PHOEBE_data *data, double hjd0, double period)
	{
	int i;
	
	for (i = 0; i < data->ptsno; i++)
		data->indep[i] = hjd0 + data->indep[i] * period;
	}

void transform_hjd_to_phase (new_PHOEBE_data *data, double hjd0, double period)
	{
	/* This function transforms heliocentric julian date (HJD) with given ori-  */
	/* gin HJD0 and period P to phase on interval [-0.5,0.5].                   */

	int i;

	for (i = 0; i < data->ptsno; i++)
		{
		data->indep[i] = fmod ((data->indep[i]-hjd0)/period, 1.0);

		/* If HJD0 is larger than HJD, then the difference is negative and we     */
		/* must fix that:                                                         */
		if (data->indep[i] < 0.0) data->indep[i] += 1.0;

		/* Now we have the phase interval [0,1], but we want [-0.5, 0.5]:         */
		if (data->indep[i] > 0.5) data->indep[i] -= 1.0;
		}
	}

void alias_phase_to_interval (new_PHOEBE_data *data, double phmin, double phmax)
	{
	/* This function redimensiones the array of data phases by aliasing points  */
	/* to outside the [-0.5, 0.5] range. If the new interval is narrower, the   */
	/* points are omitted, otherwise they are aliased.                          */

	int i;
	new_PHOEBE_data new_data;
	
	/* Make a new array record to keep the original array, since it will be mo- */
	/* dified at the end:                                                       */
	new_data.ptsno  = data->ptsno;
	new_data.indep  = phoebe_malloc (new_data.ptsno * sizeof (*new_data.indep));
	new_data.dep    = phoebe_malloc (new_data.ptsno * sizeof (*new_data.dep));
	new_data.weight = phoebe_malloc (new_data.ptsno * sizeof (*new_data.weight));

	/* Do the actual copying:                                                   */
	for (i = 0; i < new_data.ptsno; i++)
		{
		new_data.indep[i]  = data->indep[i];
		new_data.dep[i]    = data->dep[i];
		new_data.weight[i] = data->weight[i];
		}

	/* Release the input array record:                                          */
	data->indep = NULL; data->dep = NULL; data->weight = NULL; data->ptsno = 0;

	/* "Rewind" the phase to the lowermost aliased phase:                       */
	for (i = 0; i < new_data.ptsno; i++)
		while (new_data.indep[i] > phmin + 1.0)
			new_data.indep[i] -= 1;

	/* Now make a loop that does the actual aliasing:                           */
	for (i = 0; i < new_data.ptsno; i++)
		{
		while ( (new_data.indep[i] < phmax) && (new_data.indep[i] > phmin) )
			{
			data->ptsno++;
			data->indep  = phoebe_realloc (data->indep,  data->ptsno * sizeof (*data->indep));
			data->dep    = phoebe_realloc (data->dep,    data->ptsno * sizeof (*data->dep));
			data->weight = phoebe_realloc (data->weight, data->ptsno * sizeof (*data->weight));
			data->indep[data->ptsno-1]  = new_data.indep[i];
			data->dep[data->ptsno-1]    = new_data.dep[i];
			data->weight[data->ptsno-1] = new_data.weight[i];
			new_data.indep[i] += 1;
			}
		}

	/* Free the temporary array record:                                         */
	free (new_data.indep);
	free (new_data.dep);
	free (new_data.weight);
	new_data.ptsno = 0.0;
	}

void transform_magnitude_to_flux (new_PHOEBE_data *data, double mnorm)
	{
	int i;

	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = pow (10, -2./5. * (data->dep[i] - mnorm));
	}

void transform_flux_to_magnitude (new_PHOEBE_data *data, double mnorm)
	{
	int i;

	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = mnorm - 5./2. * log10 (data->dep[i]);
	}

void transform_100kms_to_kms (new_PHOEBE_data *data)
	{
	int i;
	
	for (i = 0; i < data->ptsno; i++)
		data->dep[i] *= 100.0;
	}

void transform_kms_to_100kms (new_PHOEBE_data *data)
	{
	int i;
	
	for (i = 0; i < data->ptsno; i++)
		data->dep[i] /= 100.0;
	}

void normalize_rv_to_orbit (new_PHOEBE_data *data, double sma, double period)
	{
	int i;

	const double R_SUN = 696000.0;
	const double SEC_IN_DAY = 24.0 * 3600.0;
	
	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = data->dep[i] * period * SEC_IN_DAY / 2.0 / M_PI / R_SUN / sma;
	}

PHOEBE_data *normalize_lc_at_phnorm (PHOEBE_data *data, double bin_width, double factor, int PTSNO)
	{
	int i;
	double PHNORM = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_value")));
	PHOEBE_data *out = malloc (PTSNO * sizeof (*out));

	double normalization = 0.0;
	int counted = 0;
	
	/* Let's find the arithmetic mean of PHNORM fluxes: */
	for (i = 0; i < PTSNO; i++)
		if ( (data[i].indep > PHNORM - bin_width) && (data[i].indep < PHNORM + bin_width) )
			{ normalization += data[i].dep; counted++; }
	normalization /= (double) counted;

	/* Now use it to normalize data (meaning we expect flux = 1 at PHNORM): */
	for (i = 0; i < PTSNO; i++)
		{
		out[i].indep  = data[i].indep;
		out[i].dep    = data[i].dep / normalization * factor;
		out[i].weight = data[i].weight;
		}

	free (data);
	return (out);
	}

double estimate_zero_magnitude (PHOEBE_data *data, int pts_no)
	{
	/* This routine calculates the average of all data points which must be in  */
	/* magnitudes. This is not a good way to do this; much better would be to   */
	/* calculate the median instead of unweighted average. This remains on top  */
	/* of a TODO list. There is a sound reason why this hasn't been done yet;   */
	/* the input flux may have arbitrary units, so it is not really important   */
	/* to what value we normalize. On the other hand, it would be nice to at    */
	/* least tend to normalize it to unity at quarter phase.                    */

	int i;
	double sum = 0;
	
	for (i = 0; i < pts_no; i++) sum += data[i].dep;
	return sum / i;
	}

void transform_flux_sigma_to_magnitude_sigma (double flux_sigma, double mag_sigma)
	{
	mag_sigma = -5./2. * log10 (flux_sigma);
	}

void transform_magnitude_sigma_to_flux_sigma (double mag_sigma, double flux_sigma)
	{
	flux_sigma = pow (10, -2./5. * mag_sigma);
	}

void get_plot_limits_of_data (new_PHOEBE_data data, double *xmin, double *ymin, double *xmax, double *ymax)
	{
	/* This function scans data and finds (x_min, y_min), (x_max, y_max) values */

	int i;

	*xmin = data.indep[0]; *xmax = data.indep[0];
	*ymin = data.dep[0];   *ymax = data.dep[0];
	
	for (i = 1; i < data.ptsno; i++)
		{
		if (*xmin > data.indep[i]) *xmin = data.indep[i];
		if (*xmax < data.indep[i]) *xmax = data.indep[i];
		if (*ymin > data.dep[i]  ) *ymin = data.dep[i];
		if (*ymax < data.dep[i]  ) *ymax = data.dep[i];
		}

	return;
	}
