int set_values_of_ld_window ();
