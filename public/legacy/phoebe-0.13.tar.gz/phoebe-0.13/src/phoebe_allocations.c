#include <stdio.h>
#include <string.h>

#include <gtk/gtk.h>

#include "phoebe_binning.h"
#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_support.h"
#include "phoebe_transformations.h"

int allocate_memory_for_data_record (PHOEBE_data_record **data, int records_no)
	{
	/* This function allocates memory to PHOEBE_data_record structure passed to */
	/* this routine as a pointer &var_name. It allocates memory for records_no  */
	/* entries and checks for errors. The return integer (error handler) is al- */
	/* ways 0 because phoebe_realloc stops the execution in case of failure.    */

	if (records_no == 0) *data = NULL;
	else *data = phoebe_realloc (*data, records_no * sizeof (**data));

	return 0;
	}

int allocate_memory_for_data (new_PHOEBE_data *data)
	{
	/* This function allocates memory to all three entries of the PHOEBE_data   */
	/* structure: indep, dep and weight. It reads the number of points from the */
	/* structure itself, data->ptsno, so be sure you initialize it prior to     */
	/* calling this function.                                                   */

	if (data->ptsno == 0)
		{
		data->indep  = NULL;
		data->dep    = NULL;
		data->weight = NULL;
		}
	else
		{
		data->indep  = phoebe_realloc (data->indep,  data->ptsno * sizeof (*data->indep));
		data->dep    = phoebe_realloc (data->dep,    data->ptsno * sizeof (*data->dep));
		data->weight = phoebe_realloc (data->weight, data->ptsno * sizeof (*data->weight));
		}

	return 0;
	}

PHOEBE_main_parameters read_in_main_parameters ()
	{
	GtkWidget *readout_widget;
	char *readout_str;
	PHOEBE_main_parameters parameters;

	readout_widget    = lookup_widget (PHOEBE, "basic_sma_value");
	parameters.SMA    = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "basic_rm_value");
	parameters.RM     = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "basic_period_value");
	readout_str       = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	parameters.PERIOD = atof (readout_str);

	readout_widget    = lookup_widget (PHOEBE, "basic_hjd0_value");
	readout_str       = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	parameters.HJD0   = atof (readout_str);

	readout_widget    = lookup_widget (PHOEBE, "basic_tavh_value");
	parameters.TAVH   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "basic_tavc_value");
	parameters.TAVC   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "basic_xincl_value");
	parameters.XINCL  = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "basic_vga_value");
	parameters.VGA    = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_phsv_value");
	parameters.PHSV   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_pcsv_value");
	parameters.PCSV   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_gr1_value");
	parameters.GR1    = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_gr2_value");
	parameters.GR2    = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_alb1_value");
	parameters.ALB1   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_alb2_value");
	parameters.ALB2   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_f1_value");
	parameters.F1     = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "advanced_f2_value");
	parameters.F2     = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "orbit_e_value");
	parameters.E      = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "orbit_perr0_value");
	parameters.PERR0  = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "orbit_dperdt_value");
	parameters.DPERDT = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "orbit_dpdt_value");
	parameters.DPDT   = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "orbit_pshift_value");
	parameters.PSHIFT = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget    = lookup_widget (PHOEBE, "data_zero_magnitude_value");
	parameters.MNORM  = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	return parameters;
	}

PHOEBE_switches read_in_switches ()
	{
	GtkWidget *readout_widget;

	char *readout_str;
	int readout_int;

	PHOEBE_switches switches;

/* FIX ME! Add MPAGE */

	switches.NLC = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));

	readout_int  = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));
	if (readout_int == 0) {switches.IFVC1 = 0; switches.IFVC2 = 0;}
	if (readout_int == 1) {switches.IFVC1 = 1; switches.IFVC2 = 0;}
	if (readout_int == 2) {switches.IFVC1 = 1; switches.IFVC2 = 1;}

	if (GTK_TOGGLE_BUTTON (lookup_widget (PHOEBE, "data_binning_switch"))->active == TRUE) switches.BINNING = 1;
	else switches.BINNING = 0;

	if (switches.BINNING == 0) switches.BINNO = 0;
	else
		{
		readout_widget = lookup_widget (PHOEBE, "data_binning_value");
		switches.BINNO = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
		}

	/* This is something the user shouldn't be bothered with: */
	switches.NPPL = 1;

	readout_widget = lookup_widget (PHOEBE, "luminosities_nref_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.MREF = 2;
	else                                            switches.MREF = 1;
	
	if (switches.MREF == 2)
		{
		readout_widget = lookup_widget (PHOEBE, "luminosities_nref_value");
		switches.NREF = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
		}
	else switches.NREF = 1;
	
	readout_widget = lookup_widget (PHOEBE, "luminosities_icor1_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.ICOR1 = 1; else switches.ICOR1 = 0;

	readout_widget = lookup_widget (PHOEBE, "luminosities_icor2_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.ICOR2 = 1; else switches.ICOR2 = 0;

	readout_widget = lookup_widget (PHOEBE, "data_model_list_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "X-ray binary"                                         ) == 0) switches.MODE = -1;
	if (strcmp (readout_str, "General binary system (no constraints)"               ) == 0) switches.MODE =  0;
	if (strcmp (readout_str, "Overcontact binary of the W UMa type"                 ) == 0) switches.MODE =  1;
	if (strcmp (readout_str, "Detached binary"                                      ) == 0) switches.MODE =  2;
	if (strcmp (readout_str, "Overcontact binary not in thermal contact"            ) == 0) switches.MODE =  3;
	if (strcmp (readout_str, "Semi-detached binary, primary star fills Roche lobe"  ) == 0) switches.MODE =  4;
	if (strcmp (readout_str, "Semi-detached binary, secondary star fills Roche lobe") == 0) switches.MODE =  5;
	if (strcmp (readout_str, "Double contact binary"                                ) == 0) switches.MODE =  6;

	readout_widget = lookup_widget (PHOEBE, "luminosities_ipb_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.IPB = 1; else switches.IPB = 0;

	readout_widget = lookup_widget (PHOEBE, "luminosities_ifat1_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.IFAT1 = 1; else switches.IFAT1 = 0;

	readout_widget = lookup_widget (PHOEBE, "luminosities_ifat2_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.IFAT2 = 1; else switches.IFAT2 = 0;

	readout_widget = lookup_widget (PHOEBE, "fitting_n1_value");
	switches.N1 = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_n2_value");
	switches.N2 = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_n1l_value");
	switches.N1L = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_n2l_value");
	switches.N2L = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_isym_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active) switches.ISYM = 1; else switches.ISYM = 0;

	readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_vunit_value");
	switches.VUNIT = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "data_the_value");
	switches.THE = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "fitting_xlamda_value");
	switches.XLAMDA = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

/* FIX ME! */
	switches.KDISK = 0;
	switches.K0    = 0;
	switches.NOISE = 0;
/* ******* */

	return switches;
	}

PHOEBE_curve_parameters read_in_curve_parameters ()
	{
	GtkWidget *readout_widget;
	PHOEBE_curve_parameters curve;

	double hjd0, period;
	
	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_value");
	curve.PHNORM = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_mzero_value");
	curve.MZERO = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_value");
	curve.FACTOR = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "basic_hjd0_value");
	hjd0 = atof (gtk_entry_get_text (GTK_ENTRY (readout_widget)));

	readout_widget = lookup_widget (PHOEBE, "basic_period_value");
	period = atof (gtk_entry_get_text (GTK_ENTRY (readout_widget)));

	curve.HJDST = hjd0 - 0.5 * period;
	curve.HJDSP = hjd0 + 0.5 * period;
	curve.HJDIN = period / 100.0;
	
	curve.PHSTRT = -0.5;
	curve.PHSTOP = 0.5;
	curve.PHIN = 0.01;

	return curve;
	}

PHOEBE_limb_darkening read_in_ld_coefficients ()
	{
	GtkWidget *readout_widget;
	char *readout_str;

	PHOEBE_limb_darkening ld;

	readout_widget = lookup_widget (GTK_WIDGET (PHOEBE), "ld_ld_law_combo_box_entry");
	readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
	if (strcmp (readout_str, "Linear Cosine Law") == 0) ld.LD = 1;
	if (strcmp (readout_str, "Logarithmic Law")   == 0) ld.LD = 2;
	if (strcmp (readout_str, "Square Root Law")   == 0) ld.LD = 3;

	readout_widget = lookup_widget (PHOEBE, "ld_xbol1_value");
	ld.XBOL1 = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "ld_xbol2_value");
	ld.XBOL2 = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "ld_ybol1_value");
	ld.YBOL1 = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	readout_widget = lookup_widget (PHOEBE, "ld_ybol2_value");
	ld.YBOL2 = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	return ld;
	}

PHOEBE_spots read_in_spots ()
	{
	PHOEBE_spots spots;
	
	spots.IFSMV1 = 0;
	spots.IFSMV2 = 0;

	spots.KSPA = 0;
	spots.NSPA = 0;

	spots.KSPB = 0;
	spots.NSPB = 0;

	spots.XLAT1  = 0.0;
	spots.XLONG1 = 0.0;
	spots.RADSP1 = 0.0;
	spots.TEMSP1 = 0.0;

	spots.XLAT2  = 0.0;
	spots.XLONG2 = 0.0;
	spots.RADSP2 = 0.0;
	spots.TEMSP2 = 0.0;

	return spots;
	}

PHOEBE_mms read_in_mms ()
	{
	int i;
	GtkWidget *readout_widget;

	const char *mms1[] =
		{
		"fitting_mms_switch_1_1",  "fitting_mms_switch_1_2",  "fitting_mms_switch_1_3",
		"fitting_mms_switch_1_4",  "fitting_mms_switch_1_5",  "fitting_mms_switch_1_6",
		"fitting_mms_switch_1_7",  "fitting_mms_switch_1_8",  "fitting_mms_switch_1_9",
		"fitting_mms_switch_1_10", "fitting_mms_switch_1_11", "fitting_mms_switch_1_12",
		"fitting_mms_switch_1_13", "fitting_mms_switch_1_14", "fitting_mms_switch_1_15",
		"fitting_mms_switch_1_16", "fitting_mms_switch_1_17", "fitting_mms_switch_1_18",
		"fitting_mms_switch_1_19", "fitting_mms_switch_1_20", "fitting_mms_switch_1_21",
		"fitting_mms_switch_1_22", "fitting_mms_switch_1_23", "fitting_mms_switch_1_24",
		"fitting_mms_switch_1_25", "fitting_mms_switch_1_26", "fitting_mms_switch_1_27",
		"fitting_mms_switch_1_28", "fitting_mms_switch_1_29", "fitting_mms_switch_1_30",
		"fitting_mms_switch_1_31", "fitting_mms_switch_1_32", "fitting_mms_switch_1_33",
		"fitting_mms_switch_1_34", "fitting_mms_switch_1_35"
		};

	const char *mms2[] =
		{
		"fitting_mms_switch_2_1",  "fitting_mms_switch_2_2",  "fitting_mms_switch_2_3",
		"fitting_mms_switch_2_4",  "fitting_mms_switch_2_5",  "fitting_mms_switch_2_6",
		"fitting_mms_switch_2_7",  "fitting_mms_switch_2_8",  "fitting_mms_switch_2_9",
		"fitting_mms_switch_2_10", "fitting_mms_switch_2_11", "fitting_mms_switch_2_12",
		"fitting_mms_switch_2_13", "fitting_mms_switch_2_14", "fitting_mms_switch_2_15",
		"fitting_mms_switch_2_16", "fitting_mms_switch_2_17", "fitting_mms_switch_2_18",
		"fitting_mms_switch_2_19", "fitting_mms_switch_2_20", "fitting_mms_switch_2_21",
		"fitting_mms_switch_2_22", "fitting_mms_switch_2_23", "fitting_mms_switch_2_24",
		"fitting_mms_switch_2_25", "fitting_mms_switch_2_26", "fitting_mms_switch_2_27",
		"fitting_mms_switch_2_28", "fitting_mms_switch_2_29", "fitting_mms_switch_2_30",
		"fitting_mms_switch_2_31", "fitting_mms_switch_2_32", "fitting_mms_switch_2_33",
		"fitting_mms_switch_2_34", "fitting_mms_switch_2_35"
		};

	const char *mms3[] =
		{
		"fitting_mms_switch_3_1",  "fitting_mms_switch_3_2",  "fitting_mms_switch_3_3",
		"fitting_mms_switch_3_4",  "fitting_mms_switch_3_5",  "fitting_mms_switch_3_6",
		"fitting_mms_switch_3_7",  "fitting_mms_switch_3_8",  "fitting_mms_switch_3_9",
		"fitting_mms_switch_3_10", "fitting_mms_switch_3_11", "fitting_mms_switch_3_12",
		"fitting_mms_switch_3_13", "fitting_mms_switch_3_14", "fitting_mms_switch_3_15",
		"fitting_mms_switch_3_16", "fitting_mms_switch_3_17", "fitting_mms_switch_3_18",
		"fitting_mms_switch_3_19", "fitting_mms_switch_3_20", "fitting_mms_switch_3_21",
		"fitting_mms_switch_3_22", "fitting_mms_switch_3_23", "fitting_mms_switch_3_24",
		"fitting_mms_switch_3_25", "fitting_mms_switch_3_26", "fitting_mms_switch_3_27",
		"fitting_mms_switch_3_28", "fitting_mms_switch_3_29", "fitting_mms_switch_3_30",
		"fitting_mms_switch_3_31", "fitting_mms_switch_3_32", "fitting_mms_switch_3_33",
		"fitting_mms_switch_3_34", "fitting_mms_switch_3_35"
		};

	const char *mms4[] =
		{
		"fitting_mms_switch_4_1",  "fitting_mms_switch_4_2",  "fitting_mms_switch_4_3",
		"fitting_mms_switch_4_4",  "fitting_mms_switch_4_5",  "fitting_mms_switch_4_6",
		"fitting_mms_switch_4_7",  "fitting_mms_switch_4_8",  "fitting_mms_switch_4_9",
		"fitting_mms_switch_4_10", "fitting_mms_switch_4_11", "fitting_mms_switch_4_12",
		"fitting_mms_switch_4_13", "fitting_mms_switch_4_14", "fitting_mms_switch_4_15",
		"fitting_mms_switch_4_16", "fitting_mms_switch_4_17", "fitting_mms_switch_4_18",
		"fitting_mms_switch_4_19", "fitting_mms_switch_4_20", "fitting_mms_switch_4_21",
		"fitting_mms_switch_4_22", "fitting_mms_switch_4_23", "fitting_mms_switch_4_24",
		"fitting_mms_switch_4_25", "fitting_mms_switch_4_26", "fitting_mms_switch_4_27",
		"fitting_mms_switch_4_28", "fitting_mms_switch_4_29", "fitting_mms_switch_4_30",
		"fitting_mms_switch_4_31", "fitting_mms_switch_4_32", "fitting_mms_switch_4_33",
		"fitting_mms_switch_4_34", "fitting_mms_switch_4_35"
		};

	const char *mms5[] =
		{
		"fitting_mms_switch_5_1",  "fitting_mms_switch_5_2",  "fitting_mms_switch_5_3",
		"fitting_mms_switch_5_4",  "fitting_mms_switch_5_5",  "fitting_mms_switch_5_6",
		"fitting_mms_switch_5_7",  "fitting_mms_switch_5_8",  "fitting_mms_switch_5_9",
		"fitting_mms_switch_5_10", "fitting_mms_switch_5_11", "fitting_mms_switch_5_12",
		"fitting_mms_switch_5_13", "fitting_mms_switch_5_14", "fitting_mms_switch_5_15",
		"fitting_mms_switch_5_16", "fitting_mms_switch_5_17", "fitting_mms_switch_5_18",
		"fitting_mms_switch_5_19", "fitting_mms_switch_5_20", "fitting_mms_switch_5_21",
		"fitting_mms_switch_5_22", "fitting_mms_switch_5_23", "fitting_mms_switch_5_24",
		"fitting_mms_switch_5_25", "fitting_mms_switch_5_26", "fitting_mms_switch_5_27",
		"fitting_mms_switch_5_28", "fitting_mms_switch_5_29", "fitting_mms_switch_5_30",
		"fitting_mms_switch_5_31", "fitting_mms_switch_5_32", "fitting_mms_switch_5_33",
		"fitting_mms_switch_5_34", "fitting_mms_switch_5_35"
		};

	PHOEBE_mms mms;

	readout_widget = lookup_widget (PHOEBE, "fitting_mms_switch");
	if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.on = 1; else mms.on = 0;

	readout_widget = lookup_widget (PHOEBE, "fitting_mms_value");
	mms.no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));

	for (i = 0; i < 35; i++)
		{
		readout_widget = lookup_widget (PHOEBE, mms1[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.s1[i] = 1; else mms.s1[i] = 0;
		readout_widget = lookup_widget (PHOEBE, mms2[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.s2[i] = 1; else mms.s2[i] = 0;
		readout_widget = lookup_widget (PHOEBE, mms3[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.s3[i] = 1; else mms.s3[i] = 0;
		readout_widget = lookup_widget (PHOEBE, mms4[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.s4[i] = 1; else mms.s4[i] = 0;
		readout_widget = lookup_widget (PHOEBE, mms5[i]);
		if (GTK_TOGGLE_BUTTON (readout_widget)->active == TRUE) mms.s5[i] = 1; else mms.s5[i] = 0;
		}

	return mms;
	}
	
PHOEBE_wl_dependent_parameters read_in_wl_dependent_parameters (char *filter)
	{
	/* This function reads in all wavelength-dependent parameters:              */
	/*                                                                          */
	/*   WLA         wavelength                                                 */
	/*   HLA         primary star luminosity                                    */
	/*   CLA         secondary star luminosity                                  */
	/*   X1A         primary star linear limb darkening coeficient              */
	/*   Y1A         primary star non-linear limb darkening coeficient          */
	/*   X2A         secondary star linear limb darkening coeficient            */
	/*   Y2A         secondary star non-linear limb darkening coeficient        */
	/*   EL3         third light                                                */
	/*   OPSF        opacity function                                           */
	/*   NOISE       level-dependent weighting model                            */
	/*   SIGMA       standard deviation of the data set                         */
	/*                                                                          */

	int lc_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_lc_no_value")));
	int rv_no = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget (PHOEBE, "data_rv_no_value")));

	int i;
	int match_lc = 0;
	int match_rv = 0;

	GtkWidget *readout_widget;
	char      *readout_str;

	PHOEBE_wl_dependent_parameters mono;

	/* If this function was called without any data files, we just set every-   */
	/* thing to 0 and return:                                                   */
	if ( (lc_no == 0) && (rv_no == 0) )
		{
		mono.WLA = mono.HLA = mono.CLA = mono.X1A = mono.X2A = mono.Y1A = mono.Y2A = mono.EL3 = mono.OPSF = mono.SIGMA = 0.0;
		return mono;
		}
	
	/* Within the following loop we examine all filter names and stop at one    */
	/* that successfully compares to the argument name.                         */
	for (i = 0; i < lc_no; i++)
		if (strcmp (filter, PHOEBE_lc_data[i].filter) == 0) { match_lc = 1; break; }
	if (match_lc == 0)
		for (i = 0; i < rv_no; i++)
			if (strcmp (filter, PHOEBE_rv_data[i].filter) == 0) { match_rv = 1; break; }
	if ( (match_lc == 0) && (match_rv == 0) ) phoebe_fatal ("read_in_wl_dependent_parameters, match_lc and match_rv both 0.");

	/* match_* now tells us what type of data file is analysed and i tells us   */
	/* which filter we want. With that we read in wavelength-dependent parame-  */
	/* ters:                                                                    */

	/* 1. Wavelength: */
	sscanf (filter, "%lfnm", &mono.WLA);

	/* 2. Luminosities: */
	if (match_lc == 1) readout_widget = lookup_widget (PHOEBE, "luminosities_lc_info_list");
	if (match_rv == 1) readout_widget = lookup_widget (PHOEBE, "luminosities_rv_info_list");
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
	mono.HLA = atof (readout_str);
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
	mono.CLA = atof (readout_str);

	/* 3. Limb darkening coefficients: */
	if (match_lc == 1) readout_widget = lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list");
	if (match_rv == 1) readout_widget = lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list");
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
	mono.X1A = atof (readout_str);
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
	mono.Y1A = atof (readout_str);
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 3, &readout_str);
	mono.X2A = atof (readout_str);
	gtk_clist_get_text (GTK_CLIST (readout_widget), i, 4, &readout_str);
	mono.Y2A = atof (readout_str);

	/* 4. Third light: */
	
	/* Third light is defined only for LCs, so we have to disable the readout   */
	/* for RVs:                                                                 */

	if (match_lc == 1)
		{
		gtk_clist_get_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), i, 1, &readout_str);
		mono.EL3 = atof (readout_str);
		}
	else
		mono.EL3 = 0.0;

	/* 5. Opacity function:                                                     */
	mono.OPSF = 0.0;

	/* 6. Level-dependent weighting:                                            */
	if (match_lc == 1)
		{
		readout_widget = lookup_widget (PHOEBE, "luminosities_weighting_info_list");
		gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
		if (strcmp (readout_str, "No Level-Dependent Weighting")    == 0) mono.NOISE = 0;
		if (strcmp (readout_str, "Scatter Scales With Square Root") == 0) mono.NOISE = 1;
		if (strcmp (readout_str, "Scatter Scales With Light Level") == 0) mono.NOISE = 2;
		}
	else
		mono.NOISE = 0;

	/* 7. Standard deviation:                                                   */
	if (match_lc == 1) mono.SIGMA = atof (PHOEBE_lc_data[i].sigma);
	if (match_rv == 1) mono.SIGMA = atof (PHOEBE_rv_data[i].sigma);

	/* 8. Systemic radial velocity:                                             */
	readout_widget = lookup_widget (PHOEBE, "basic_vga_value");
	mono.VGA = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));

	return mono;
	}

int read_in_dco_values (char *filename, PHOEBE_dco_record *dco_record)
	{
	/* This function opens the given DCO file from temp directory and reads in  */
	/* all available information to the variable passed as the argument.        */

	int i, j, k;

	PHOEBE_switches switches = read_in_switches ();

	int dummy_int;

	double readout_dbl;

	char working_string[255];
	char *working_str = working_string;

	FILE *dcout;

	dcout = fopen (filename, "r");

	while (feof (dcout) == FALSE)
		{
		fgets (working_str, 255, dcout);

		if (strcmp (working_str, " Sums of squares of residuals for separate curves, including only individual weights\n") == 0)
			{
			fgets (working_str, 255, dcout);      /* Skip an empty line in DCO file */
			fgets (working_str, 255, dcout);      /* Skip a header line in DCO file */
			for (i = 0; i < switches.NLC + switches.IFVC1 + switches.IFVC2; i++)
				fscanf (dcout, "%d %d %lf", &dummy_int, &dco_record->points_no[i], &dco_record->chi2[i]);
			}

		if (strcmp (working_str, "       CORRELATION COEFFICIENTS\n") == 0)
			{
			fgets (working_str, 255, dcout);      /* Skip an empty line in DCO file */

			/* How many rows does the DC list have -> this tells us what is the di- */
			/* mension of the correlation matrix:                                   */
			i = GTK_CLIST (lookup_widget (PHOEBE_dc, "dc_parameters_info_list"))->rows;

			/* Our correlation matrix is i x i in size. Let's read it in:           */
			for (j = 0; j < i; j++)
				{
				for (k = 0; k < i; k++)
					{
					fscanf (dcout, "%lf", &readout_dbl);
					printf ("%10.5lf", readout_dbl);
					}
				printf ("\n");
				}
			}

		if (strcmp (working_str, "                      Input-Output in F Format\n") == 0)
			{
			fgets (working_str, 255, dcout);      /* Skip an empty line in DCO file */
			fgets (working_str, 255, dcout);      /* Skip a header line in DCO file */
			i = 0;
			while (fscanf (dcout, "%d %d %lf %lf %lf %lf", &dco_record->param_no[i], &dco_record->curve_no[i], &dco_record->original_value[i], &dco_record->correction[i], &dco_record->modified_value[i], &dco_record->sigma[i]) == 6)
				{
				/* If we adjusted temperatures, we have to modify the units:          */
				if ( (dco_record->param_no[i] == 19) || (dco_record->param_no[i] == 20) )
					{
					dco_record->original_value[i] *= 10000.0;
					dco_record->correction[i] *= 10000.0;
					dco_record->modified_value[i] *= 10000.0;
					dco_record->sigma[i] *= 10000.0;
					}
				i++;
				}
			}
		}

	fclose (dcout);
	}

int read_in_synthetic_lc_data (char *filename, new_PHOEBE_data *data, PHOEBE_calculated_parameters *params, int indep, int dep)
	{
	/* This function opens the given LCO file from temp directory and reads in  */
	/* calculated values of a synthetic lightcurve. It allocates memory for da- */
	/* ta through the allocate_memory_for_data call and writes in the values    */
	/* according to parameters indep and dep. It sets all weights to 1.0.       */

	int i;
	double dummy;

	char working_string[255];
	char *working_str = working_string;

	/* All warnings reported in .lco file will be rerouted to screen through a  */
	/* notice window:                                                           */
	GtkWidget *notice_window;
	
	FILE *data_file;

	/* This is a temporary variable that is freed at the end of the function:   */
	PHOEBE_synthetic_lc_record *lc_output = phoebe_malloc (sizeof (*lc_output));

	/* Initialize everything to 0, so we don't get any accidental appending:    */
	data->ptsno = 0; data->indep = NULL; data->dep = NULL; data->weight = NULL;

	data_file = fopen (filename, "r");

	/* We shall read in all the values through a checkup "while" loop, because  */
	/* the output format of .lco file is only *more or less* standard, which    */
	/* means that WD98 sometimes appends some comments to that file (such as    */
	/* the warning that the secondary component exceeds critical lobe).         */
	while (! feof (data_file))
		{
		fgets (working_str, 255, data_file);
		printf ("->%s\n", working_str);

		/* If there are any warnings appended to a .lco file, put them on screen: */
		if (strcmp (working_str, " PRIMARY COMPONENT EXCEEDS CRITICAL LOBE\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the primary component exceeds its critical lobe.", gtk_widget_destroy);
		if (strcmp (working_str, " SECONDARY COMPONENT EXCEEDS CRITICAL LOBE\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the secondary component exceeds its critical lobe.", gtk_widget_destroy);
		if (strcmp (working_str, " Primary star exceeds outer contact surface\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the primary star exceeds outer contact surface.", gtk_widget_destroy);
		if (strcmp (working_str, " Secondary star exceeds outer contact surface\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the secondary star exceeds outer contact surface.", gtk_widget_destroy);

		/* Read in the first set of calculated parameters:                        */
		if (strcmp (working_str, " Star     M/Msun      (Mean Radius)/Rsun   M Bol    Log g (cgs)\n") == 0)
			{
			if (fscanf (data_file, "%d %lf %lf %lf %lf\n", &i, &params->mass_p, &params->radius_p, &params->mbol_p, &params->logg_p) != 5) phoebe_warning ("Error in read_in_synthetic_lc_data line 1!\n");
			if (fscanf (data_file, "%d %lf %lf %lf %lf\n", &i, &params->mass_s, &params->radius_s, &params->mbol_s, &params->logg_s) != 5) phoebe_warning ("Error in read_in_synthetic_lc_data line 2!\n");
			}

		/* Read in the second set of calculated parameters:                       */
		if (strcmp (working_str, "GRID1/4    GRID2/4  POLAR SBR 1   POLAR SBR 2   SURF. AREA 1  SURF. AREA 2   PERI. PH.   CONJ. PH. \n") == 0)
			if (fscanf (data_file, "%d %d %lf %lf %lf %lf %lf %lf\n", &i, &i, &params->psb_p, &params->psb_s, &params->surface_p, &params->surface_s, &dummy, &dummy) != 8) phoebe_warning ("Error in read_in_synthetic_lc_data line 3!\n");

		/* Read in synthetic data:                                                */
		if (strcmp (working_str, "JD                 Phase     light 1     light 2     (1+2+3)    norm lite   dist      mag+K\n") == 0)
			{
			i = 0;
			while (fscanf (data_file, "%lf %lf %lf %lf %lf %lf %lf %lf\n", &lc_output[i].hjd, &lc_output[i].phase, &lc_output[i].primary_flux, &lc_output[i].secondary_flux, &lc_output[i].total_flux, &lc_output[i].normalized_flux, &lc_output[i].separation, &lc_output[i].magnitude) == 8)
				{
				i++;
				lc_output = phoebe_realloc (lc_output, (i+1) * sizeof (*lc_output));
				}
			data->ptsno = i;
			}

		/* Read in the third set of calculated parameters:                        */
		if (strcmp (working_str, "star    r pole     deriv     r point     deriv      r side      deriv     r back      deriv\n") == 0)
			{
			fscanf (data_file, "\n");                              /* An empty line */
			if (fscanf (data_file, "%d %lf %lf %lf %lf %lf %lf %lf %lf\n", &i, &params->rpole_p, &dummy, &params->rpoint_p, &dummy, &params->rside_p, &dummy, &params->rback_p, &dummy) != 9) phoebe_warning ("Error in read_in_synthetic_lc_data line 4!\n");
			if (fscanf (data_file, "%d %lf %lf %lf %lf %lf %lf %lf %lf\n", &i, &params->rpole_s, &dummy, &params->rpoint_s, &dummy, &params->rside_s, &dummy, &params->rback_s, &dummy) != 9) phoebe_warning ("Error in read_in_synthetic_lc_data line 5!\n");
			}
		}

	fclose (data_file);

	allocate_memory_for_data (data);

	for (i = 0; i < data->ptsno; i++)
		{
		if (indep == 1) data->indep[i]  = lc_output[i].hjd;
		if (indep == 2) data->indep[i]  = lc_output[i].phase;
		if (  dep == 3) data->dep[i]    = lc_output[i].primary_flux;
		if (  dep == 4) data->dep[i]    = lc_output[i].secondary_flux;
		if (  dep == 5) data->dep[i]    = lc_output[i].total_flux;
		if (  dep == 6) data->dep[i]    = lc_output[i].normalized_flux;
		if (  dep == 8) data->dep[i]    = lc_output[i].magnitude;
                    data->weight[i] = 1.0;
		}

	free (lc_output);

	return 0;
	}

int read_in_synthetic_rv_data (char *filename, new_PHOEBE_data *data, PHOEBE_calculated_parameters *params, int indep, int dep)
	{
	/* This function opens the given LCO file from temp directory and reads in  */
	/* calculated values of a synthetic RV curve. It allocates memory for data  */
	/* through the allocate_memory_for_data call and writes in the values       */
	/* according to parameters indep and dep. It sets all weights to 1.0.       */

	int i;
	double dummy;

	char working_string[255];
	char *working_str = working_string;
	
	/* All warnings reported in .lco file will be rerouted to screen through a  */
	/* notice window:                                                           */
	GtkWidget *notice_window;

	FILE *data_file;

	/* This is a temporary variable that is freed at the end of the function:   */
	PHOEBE_synthetic_rv_record *rv_output = phoebe_malloc (sizeof (*rv_output));

	/* Initialize everything to 0, so we don't get any accidental appending:    */
	data->ptsno = 0; data->indep = NULL; data->dep = NULL; data->weight = NULL;

	data_file = fopen (filename, "r");

	/* We shall read in all the values through a checkup "while" loop, because  */
	/* the output format of .lco file is only *more or less* standard, which    */
	/* means that WD98 sometimes appends some comments to that file (such as    */
	/* the warning that the secondary component exceeds critical lobe).         */
	while (! feof (data_file))
		{
		fgets (working_str, 255, data_file);

		/* If there are any warnings appended to a .lco file, put them on screen: */
		if (strcmp (working_str, " PRIMARY COMPONENT EXCEEDS CRITICAL LOBE\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the primary component exceeds its critical lobe.", gtk_widget_destroy);
		if (strcmp (working_str, " SECONDARY COMPONENT EXCEEDS CRITICAL LOBE\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the secondary component exceeds its critical lobe.", gtk_widget_destroy);
		if (strcmp (working_str, " Primary star exceeds outer contact surface\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the primary star exceeds outer contact surface.", gtk_widget_destroy);
		if (strcmp (working_str, " Secondary star exceeds outer contact surface\n") == 0)
			notice_window = create_notice_window ("PHOEBE Notice", "Physical Content Feasibility Problem", "Your current set of parameters suggests that", "the secondary star exceeds outer contact surface.", gtk_widget_destroy);

		/* Read in the first set of calculated parameters:                        */
		if (strcmp (working_str, " Star     M/Msun      (Mean Radius)/Rsun   M Bol    Log g (cgs)\n") == 0)
			{
			if (fscanf (data_file, "%d %lf %lf %lf %lf\n", &i, &params->mass_p, &params->radius_p, &params->mbol_p, &params->logg_p) != 5) phoebe_warning ("Error in read_in_synthetic_lc_data line 1!\n");
			if (fscanf (data_file, "%d %lf %lf %lf %lf\n", &i, &params->mass_s, &params->radius_s, &params->mbol_s, &params->logg_s) != 5) phoebe_warning ("Error in read_in_synthetic_lc_data line 2!\n");
			}

		/* Read in the second set of calculated parameters:                       */
		if (strcmp (working_str, "GRID1/4    GRID2/4  POLAR SBR 1   POLAR SBR 2   SURF. AREA 1  SURF. AREA 2   PERI. PH.   CONJ. PH. \n") == 0)
			if (fscanf (data_file, "%d %d %lf %lf %lf %lf %lf %lf\n", &i, &i, &params->psb_p, &params->psb_s, &params->surface_p, &params->surface_s, &dummy, &dummy) != 8) phoebe_warning ("Error in read_in_synthetic_lc_data line 3!\n");

		/* Read in synthetic data:                                                */
		if (strcmp (working_str, "JD              Phase     V Rad 1     V Rad 2      del V1      del V2   V1 km/s      V2 km/s\n") == 0)
			{
			i = 0;
			while (fscanf (data_file, "%lf %lf %lf %lf %lf %lf %lf %lf\n", &rv_output[i].hjd, &rv_output[i].phase, &rv_output[i].primary_norm_rv, &rv_output[i].secondary_norm_rv, &rv_output[i].primary_eclipse_corr, &rv_output[i].secondary_eclipse_corr, &rv_output[i].primary_rv, &rv_output[i].secondary_rv) == 8)
				{
				i++;
				rv_output = phoebe_realloc (rv_output, (i+1) * sizeof (*rv_output));
				}
			data->ptsno = i;
			}

		/* Read in the third set of calculated parameters:                        */
		if (strcmp (working_str, "star    r pole     deriv     r point     deriv      r side      deriv     r back      deriv\n") == 0)
			{
			fscanf (data_file, "\n");                              /* An empty line */
			if (fscanf (data_file, "%d %lf %lf %lf %lf %lf %lf %lf %lf\n", &i, &params->rpole_p, &dummy, &params->rpoint_p, &dummy, &params->rside_p, &dummy, &params->rback_p, &dummy) != 9) phoebe_warning ("Error in read_in_synthetic_lc_data line 4!\n");
			if (fscanf (data_file, "%d %lf %lf %lf %lf %lf %lf %lf %lf\n", &i, &params->rpole_s, &dummy, &params->rpoint_s, &dummy, &params->rside_s, &dummy, &params->rback_s, &dummy) != 9) phoebe_warning ("Error in read_in_synthetic_lc_data line 5!\n");
			}
		}

	fclose (data_file);

	allocate_memory_for_data (data);

	for (i = 0; i < data->ptsno; i++)
		{
		if (indep == 1) data->indep[i]  = rv_output[i].hjd;
		if (indep == 2) data->indep[i]  = rv_output[i].phase;
		if (  dep == 3) data->dep[i]    = rv_output[i].primary_norm_rv;
		if (  dep == 4) data->dep[i]    = rv_output[i].secondary_norm_rv;
		if (  dep == 5) data->dep[i]    = rv_output[i].primary_eclipse_corr;
		if (  dep == 6) data->dep[i]    = rv_output[i].secondary_eclipse_corr;
		/* This isn't really very elegant, but I have no better solution at the   */
		/* time. VUNIT is currently fixated to 100.0, because fitting algorithm   */
		/* needs it to be 100.0. This influences LC output to be in 100km/s in-   */
		/* stead of 1km/s and we fix this by multiplying it with 100.0:           */
		if (  dep == 7) data->dep[i]    = rv_output[i].primary_rv * 100.0;
		if (  dep == 8) data->dep[i]    = rv_output[i].secondary_rv * 100.0;
                    data->weight[i] = 1.0;
		}

	free (rv_output);

	return 0;
	}

int read_in_experimental_lc_data (int curve, new_PHOEBE_data *data, int indep, int dep)
	{
	int i;
	int col_type;
	int comment;
	int readout_int;

	int phase, magnitude;

	int err_no;

	char working_string[255];
	char *working_str = working_string;

	GtkWidget *notice_window;

	/* If data units mismatch the given indep/dep switches, we need to know pe- */
	/* riod and HJD0, that's why we declare this variable, but read the values  */
	/* in only in case of a mismatch.                                           */
	PHOEBE_main_parameters main_pars;

	/* Although this isn't really very elegant, somehow we have to know if the  */
	/* user wants the data to be binned; that's why we read in all switches:    */
	PHOEBE_switches        switches = read_in_switches ();

	FILE *data_file;

	/* Initialize everything to 0, so we don't get any accidental appending:    */
	data->ptsno = 0; data->indep = NULL; data->dep = NULL; data->weight = NULL;

	/* Set the columns variable to hold the number and type of columns in a fi- */
	/* le; we do it here and not in the loop so that strcmp gets evaluated only */
	/* now and not for each point in the loop.                                  */
	if (strcmp (PHOEBE_lc_data[curve].column3, "Unavailable") == 0)   col_type = 1;
	if (strcmp (PHOEBE_lc_data[curve].column3, "Weight (int)") == 0)  col_type = 2;
	if (strcmp (PHOEBE_lc_data[curve].column3, "Weight (real)") == 0) col_type = 3;

	/* Do the same for phase and magnitude, just to have everything here:       */
	if (strcmp (PHOEBE_lc_data[curve].column1, "Phase")     == 0) phase = 1;     else phase = 0;
	if (strcmp (PHOEBE_lc_data[curve].column2, "Magnitude") == 0) magnitude = 1; else magnitude = 0;

	if (!file_exists (PHOEBE_lc_data[curve].filename))
		{
		notice_window = create_notice_window ("PHOEBE Notice", "Experimental data filename not found", "PHOEBE cannot find the file containing experimental data.", "Please check your settings in the Data tab.", gtk_widget_destroy);
		data->ptsno = 0;
		return;
		}
		
	data_file = fopen (PHOEBE_lc_data[curve].filename, "r");

	i = 0;
	comment = 0;
	while (feof (data_file) == FALSE)
		{
		if (comment == 0)
			{
			data->ptsno = ++i;
			allocate_memory_for_data (data);
			}

		/* Although not completely and absolutely safe, we presume that no input  */
		/* file contains more than 255 characters. If it does, it will be messy.  */
		/* But come on, who ever saw an input file longer than 255 characters???  */
		fgets (working_str, 255, data_file);

		/* Let's see whether we just read a comment; we did if the line starts    */
		/* with a '#'.                                                            */
		comment = 0;
		if (strchr (working_str, '#') != NULL) comment = 1;

		if ( (comment == 0) && (col_type == 1) )
			{
			err_no = sscanf (working_str, "%lf %lf\n", &data->indep[i-1], &data->dep[i-1]);
			if (err_no != 2)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			data->weight[i-1] = 1.0;
			}
		if ( (comment == 0) && (col_type == 2) )
			{
			err_no = sscanf (working_str, "%lf %lf %d\n",  &data->indep[i-1], &data->dep[i-1], &readout_int);
			if (err_no != 3)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			data->weight[i-1] = (double) readout_int;
			}
		if ( (comment == 0) && (col_type == 3) )
			{
			err_no = sscanf (working_str, "%lf %lf %lf\n", &data->indep[i-1], &data->dep[i-1], &data->weight[i-1]);
			if (err_no != 3)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			}
		}

	fclose (data_file);

	/* Synchronize independent variable to match indep switch:                  */
	if ( (indep == 1) && (phase == 1) )
		{
		main_pars = read_in_main_parameters ();
		transform_phase_to_hjd (data, main_pars.HJD0, main_pars.PERIOD);
		}
	if ( (indep == 2) && (phase == 0) )
		{
		main_pars = read_in_main_parameters ();
		transform_hjd_to_phase (data, main_pars.HJD0, main_pars.PERIOD);
		}

	/* Synchronize dependent variable to match dep switch:                      */
	if ( ( (dep == 5) || (dep == 6) ) && (magnitude == 1) )
		{
		main_pars = read_in_main_parameters ();
		transform_magnitude_to_flux (data, main_pars.MNORM);
		}
	if ( (dep == 8) && (magnitude == 0) )
		{
		main_pars = read_in_main_parameters ();
		transform_flux_to_magnitude (data, main_pars.MNORM);
		}

	/* If the data should be binned, bin it, but only if indep is phase:        */
	if ( (switches.BINNING == 1) && (indep == 2) )
		bin_data (data, switches.BINNO);

	return 0;
	}

int read_in_experimental_rv_data (int curve, new_PHOEBE_data *data, int indep, int dep, double requested_vunit)
	{
	int i;
	int comment;
	int col_type;
	int readout_int;

	int phase, input_vunit;

	int err_no;

	char working_string[255];
	char *working_str = working_string;
	
	GtkWidget *notice_window;

	/* If data units mismatch the given indep/dep switches, we need to know pe- */
	/* riod and HJD0, that's why we declare this variable, but read the values  */
	/* in only in case of a mismatch.                                           */
	PHOEBE_main_parameters main_pars;

	FILE *data_file;

	/* Initialize everything to 0, so we don't get any accidental appending:    */
	data->ptsno = 0; data->indep = NULL; data->dep = NULL; data->weight = NULL;

	/* Set the columns variable to hold the number and type of columns in a fi- */
	/* le; we do it here and not in the loop so that strcmp gets evaluated only */
	/* now and not for each point in the loop.                                  */
	if (strcmp (PHOEBE_rv_data[curve].column3, "Unavailable") == 0)   col_type = 1;
	if (strcmp (PHOEBE_rv_data[curve].column3, "Weight (int)") == 0)  col_type = 2;
	if (strcmp (PHOEBE_rv_data[curve].column3, "Weight (real)") == 0) col_type = 3;

	/* Do the same for phase and magnitude, just to have everything here:       */
	if (strcmp (PHOEBE_rv_data[curve].column1, "Phase")     == 0)  phase = 1; else phase = 0;
	if (strcmp (PHOEBE_rv_data[curve].column2, "RV in km/s") == 0) input_vunit = 1; else input_vunit = 0;

	if (!file_exists (PHOEBE_rv_data[curve].filename))
		{
		notice_window = create_notice_window ("PHOEBE Notice", "Experimental data filename not found", "PHOEBE cannot find the file containing experimental data.", "Please check your settings in the Data tab.", gtk_widget_destroy);
		data->ptsno = 0;
		return;
		}
	data_file = fopen (PHOEBE_rv_data[curve].filename, "r");

	i = 0;
	comment = 0;
	while (feof (data_file) == FALSE)
		{
		if (comment == 0)
			{
			data->ptsno = ++i;
			allocate_memory_for_data (data);
			}

		/* Although not completely and absolutely safe, we presume that no input  */
		/* file contains more than 255 characters. If it does, it will be messy.  */
		/* But come on, who ever saw an input file longer than 255 characters???  */
		fgets (working_str, 255, data_file);

		/* Let's see whether we just read a comment; we did if the line starts    */
		/* with a '#'.                                                            */
		comment = 0;
		if (strchr (working_str, '#') != NULL) comment = 1;

		if ( (comment == 0) && (col_type == 1) )
			{
			err_no = sscanf (working_str, "%lf %lf\n", &data->indep[i-1], &data->dep[i-1]);
			if (err_no != 2)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			data->weight[i-1] = 1.0;
			}
		if ( (comment == 0) && (col_type == 2) )
			{
			err_no = sscanf (working_str, "%lf %lf %d\n",  &data->indep[i-1], &data->dep[i-1], &readout_int);
			if (err_no != 3)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			data->weight[i-1] = (double) readout_int;
			}
		if ( (comment == 0) && (col_type == 3) )
			{
			err_no = sscanf (working_str, "%lf %lf %lf\n", &data->indep[i-1], &data->dep[i-1], &data->weight[i-1]);
			if (err_no != 3)
				{
				notice_window = create_notice_window ("PHOEBE Notice", "Invalid experimental data file format", "Experimental data file doesn't conform to the format specified in the Data tab", "and the output will be suppressed. Please verify your file format specifications!", gtk_widget_destroy);
				data->ptsno = 0;
				return;
				}
			}
		}

	fclose (data_file);

	/* Synchronize independent variable to match indep switch:                  */
	if ( (indep == 1) && (phase == 1) )
		{
		main_pars = read_in_main_parameters ();
		transform_phase_to_hjd (data, main_pars.HJD0, main_pars.PERIOD);
		}
	if ( (indep == 2) && (phase == 0) )
		{
		main_pars = read_in_main_parameters ();
		transform_hjd_to_phase (data, main_pars.HJD0, main_pars.PERIOD);
		}

	/* Synchronize dependent variable to match indep switch:                    */
	if ( (input_vunit == 0) && (requested_vunit == 1.0) )
		transform_100kms_to_kms (data);
	if ( (input_vunit == 1) && (requested_vunit == 100.0) )
		transform_kms_to_100kms (data);

	if ( (dep == 3) || (dep == 4) )
		{
		main_pars = read_in_main_parameters ();
		normalize_rv_to_orbit (data, main_pars.SMA, main_pars.PERIOD);
		}

	return 0;
	}
