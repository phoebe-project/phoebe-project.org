#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <gtk/gtk.h>

#include <sm_declare.h>

#include "phoebe_allocations.h"
#include "phoebe_chi2.h"
#include "phoebe_error_handling.h"
#include "phoebe_fortran_implementations.h"
#include "phoebe_global.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_support.h"
#include "phoebe_transformations.h"

int scan_temporary_directory_for_lci_file_index (char *prefix)
	{
	/* This function accesses the temporary PHOEBE directory and checks all     */
	/* present filenames to extract the latest filename number. We want this to */
	/* avoid overwriting a particular older configuration file with the newer   */
	/* one, because the user might want to keep it.                             */

	char working_string[255];
	char *working_str = working_string;
	int i = 0;

	sprintf (working_str, "%s/%s_%03d.lci", PHOEBE_TEMP_DIR, prefix, i);
	while (file_exists (working_str))
		{
		/* The file for given i exists; therefore we increase the counter to find */
		/* the first i for which there is no file:                                */
		i++;
		sprintf (working_str, "%s/%s_%03d.lci", PHOEBE_TEMP_DIR, prefix, i);
		}
	/* Here we have the first i for which there is no filename.                 */

	return i - 1;
	}

void create_lci_input_file (char *prefix,
                            PHOEBE_main_parameters main,
                            PHOEBE_switches switches,
                            PHOEBE_limb_darkening ld,
														PHOEBE_spots spots,
														PHOEBE_curve_parameters curve,
                            PHOEBE_wl_dependent_parameters mono,
														double SEED, double STDDEV)
	{
	/* This function creates an LCI file, where we want to be careful not to    */
	/* overwrite already existing LCI files, which the user may want to keep:   */

	char working_string[255];
	char *working_str = working_string;

	int i;

	i = scan_temporary_directory_for_lci_file_index (prefix);

	sprintf (working_str, "%s/%s_%03d.lci", PHOEBE_TEMP_DIR, prefix, i+1);
	create_lci_file (working_str, main, switches, ld, spots, curve, mono, SEED, STDDEV);
	}

void create_dci_input_file (double DEL[35], int KEP[35], PHOEBE_main_parameters main, PHOEBE_limb_darkening ld, PHOEBE_spots spots, PHOEBE_switches switches, PHOEBE_mms mms)
	{
	char working_string[255];
	char *working_str = working_string;

/* FIX ME! Use different filenames for consecutive executions */
	sprintf (working_str, "%s/phoebe.dci", PHOEBE_TEMP_DIR);
/* ******* */

	create_dci_file (working_str, DEL, KEP, main, ld, spots, switches, mms);
	}

void calculate_plot_limits (new_PHOEBE_data synthetic_data, new_PHOEBE_data experimental_data, double *xmin, double *ymin, double *xmax, double *ymax, int plot_synthetic, int plot_experimental, double x_offset, double y_offset, double zoom)
	{
	double xmin1, xmax1, ymin1, ymax1;              /* Synthetic data limits    */
	double xmin2, xmax2, ymin2, ymax2;              /* Experimental data limits */

	if (plot_synthetic == 1)    get_plot_limits_of_data (synthetic_data,    &xmin1, &ymin1, &xmax1, &ymax1);
	if (plot_experimental == 1) get_plot_limits_of_data (experimental_data, &xmin2, &ymin2, &xmax2, &ymax2);

	if (plot_synthetic == 1)
		{
		*xmin = xmin1 + x_offset * (xmax1 - xmin1) - (0.1 + zoom) * (xmax1 - xmin1);
		*xmax = xmax1 + x_offset * (xmax1 - xmin1) + (0.1 + zoom) * (xmax1 - xmin1);
		*ymin = ymin1 + y_offset * (ymax1 - ymin1) - (0.1 + zoom) * (ymax1 - ymin1);
		*ymax = ymax1 + y_offset * (ymax1 - ymin1) + (0.1 + zoom) * (ymax1 - ymin1);
		xmin1 = *xmin; xmax1 = *xmax; ymin1 = *ymin; ymax1 = *ymax;
		}

	if (plot_experimental == 1)
		{
		*xmin = xmin2 + x_offset * (xmax2 - xmin2) - (0.1 + zoom) * (xmax2 - xmin2);
		*xmax = xmax2 + x_offset * (xmax2 - xmin2) + (0.1 + zoom) * (xmax2 - xmin2);
		*ymin = ymin2 + y_offset * (ymax2 - ymin2) - (0.1 + zoom) * (ymax2 - ymin2);
		*ymax = ymax2 + y_offset * (ymax2 - ymin2) + (0.1 + zoom) * (ymax2 - ymin2);
		xmin2 = *xmin; xmax2 = *xmax; ymin2 = *ymin; ymax2 = *ymax;
		}

	if ( (plot_synthetic == 1) && (plot_experimental == 1) )
		{
		if (xmin1 < xmin2) *xmin = xmin1; else *xmin = xmin2;
		if (xmax1 > xmax2) *xmax = xmax1; else *xmax = xmax2;
		if (ymin1 < ymin2) *ymin = ymin1; else *ymin = ymin2;
		if (ymax1 > ymax2) *ymax = ymax1; else *ymax = ymax2;
		}
	}

void create_lc_plot_using_sm (PHOEBE_plot_device device, char *filename, new_PHOEBE_data synthetic_data, new_PHOEBE_data experimental_data, int indep, int dep, int grid, int box, double x_offset, double y_offset, double zoom, int plot_synthetic, int plot_experimental)
	{
	char working_string[255];
	char *working_str = working_string;

	int i;

	/* Plot limits; values are assigned in case this function would ever be     */
	/* called with both plot_synthetic and plot_experimental switches off.      */
	double xmin = 0.0, xmax = 0.0, ymin = 0.0, ymax = 0.0;

	/* Point type is assigned to each point individually, thus an array:        */
	double *ptype = NULL;

	FILE *plot_file;

	/* If the output is ascii table, write it out now and exit:                 */
	if (device == ascii)
		{
		plot_file = fopen (filename, "w");
		if (plot_synthetic == 1)
			{
			fprintf (plot_file, "# indep\t# dep\t# weight\n");
			for (i = 0; i < synthetic_data.ptsno; i++)
				fprintf (plot_file, "%lf\t%lf\t%lf\n", synthetic_data.indep[i], synthetic_data.dep[i], synthetic_data.weight[i]);
			}
		if (plot_experimental == 1)
			{
			fprintf (plot_file, "# indep\t\t# dep\t\t# weight\n");
			for (i = 0; i < experimental_data.ptsno; i++)
				fprintf (plot_file, "%lf\t%lf\t%lf\n", experimental_data.indep[i], experimental_data.dep[i], experimental_data.weight[i]);
			}
		fclose (plot_file);
		return;
		}

	/* Set point type for all points to be medium sized filled circles:         */
	if (plot_experimental == 1)
		{
		ptype = phoebe_malloc (experimental_data.ptsno * sizeof (*ptype));
		for (i = 0; i < experimental_data.ptsno; i++) ptype[i] = 103;
		}

	/* Set the terminal to graphical state:                                     */
	sm_graphics ();

	/* Initialize the file into which we are plotting to:                       */
	if (device == x11)
		sprintf (working_str, "aspectxpm %s/phoebe_lc_%03d.xpm", PHOEBE_TEMP_DIR, scan_temporary_directory_for_lci_file_index ("phoebe_lc"));
	if (device == eps)
		sprintf (working_str, "postfile %s", filename);
	if (device == xpm)
		sprintf (working_str, "aspectxpm %s", filename);
	if (device == gif)
		sprintf (working_str, "aspectgif %s", filename);
	if (device == ppm)
		sprintf (working_str, "ppm %s", filename);
	if (device == tinygif)
		sprintf (working_str, "tinygif %s", filename);

	sm_device (working_str);

	/* Set the main plot characteristics:                                       */
	sm_expand (1.0001);
	sm_ptype (ptype, 3);
	sm_defvar("TeX_strings", "1");

	/* Calculate and set plotting limits:                                       */
	calculate_plot_limits (synthetic_data, experimental_data, &xmin, &ymin, &xmax, &ymax, plot_synthetic, plot_experimental, x_offset, y_offset, zoom);
	if (dep == 8) sm_limits (xmin, xmax, ymax, ymin);             /* Magnitudes */
	else          sm_limits (xmin, xmax, ymin, ymax);             /* Fluxes     */

	if (box  == 1) sm_box (1, 2, 4, 4);
	if (box  == 0) sm_box (1, 2, 0, 0);
	if (grid == 1) { sm_ltype (1); sm_grid (0, 0); sm_ltype (0); }
	if (grid == 2) { sm_ltype (1); sm_grid (1, 0); sm_ltype (0); }

	if (plot_experimental == 1)
		{
		sm_ctype ("blue");
		sm_points  (experimental_data.indep, experimental_data.dep, experimental_data.ptsno);
		}

	if (plot_synthetic == 1)
		{
		sm_ctype ("red");
		sm_connect (synthetic_data.indep, synthetic_data.dep, synthetic_data.ptsno);
		}

	sm_ctype ("black");
	if (indep == 1) sm_xlabel ("HJD");
	if (indep == 2) sm_xlabel ("Phase");
	if (  dep == 3) sm_ylabel ("Primary Star Flux");
	if (  dep == 4) sm_ylabel ("Secondary Star Flux");
	if (  dep == 5) sm_ylabel ("Total Flux");
	if (  dep == 6) sm_ylabel ("Normalized Flux");

	/* Flush graphics output to screen:                                         */
	sm_gflush();

	/* Set the terminal back to normal state:                                   */
	sm_hardcopy ();
	sm_alpha ();

	free (ptype);
	}

void create_rv_plot_using_sm (PHOEBE_plot_device device, char *filename, new_PHOEBE_data synthetic_data, new_PHOEBE_data experimental_data, int indep, int dep, int grid, int box, double x_offset, double y_offset, double zoom, int plot_synthetic, int plot_experimental)
	{
	char working_string[255];
	char *working_str = working_string;

	int i;

	/* Plot limits; values are assigned in case this function would ever be     */
	/* called with both plot_synthetic and plot_experimental switches off.      */
	double xmin = 0.0, xmax = 0.0, ymin = 0.0, ymax = 0.0;

	/* Point type is assigned to each point individually, thus an array:        */
	double *ptype = NULL;

	FILE *plot_file;

	/* If the output is ascii table, write it out now and exit:                 */
	if (device == ascii)
		{
		plot_file = fopen (filename, "w");
		if (plot_synthetic == 1)
			{
			fprintf (plot_file, "# indep\t\t# dep\t\t# weight\n");
			for (i = 0; i < synthetic_data.ptsno; i++)
				fprintf (plot_file, "%lf\t%lf\t%lf\n", synthetic_data.indep[i], synthetic_data.dep[i], synthetic_data.weight[i]);
			}
		if (plot_experimental == 1)
			{
			fprintf (plot_file, "# indep\t# dep\t# weight\n");
			for (i = 0; i < experimental_data.ptsno; i++)
				fprintf (plot_file, "%lf\t%lf\t%lf\n", experimental_data.indep[i], experimental_data.dep[i], experimental_data.weight[i]);
			}
		fclose (plot_file);
		return;
		}

	/* Set point type for all points to be medium sized filled circles:         */
	if (plot_experimental == 1)
		{
		ptype = phoebe_malloc (experimental_data.ptsno * sizeof (*ptype));
		for (i = 0; i < experimental_data.ptsno; i++) ptype[i] = 103;
		}

	/* Set the terminal to graphical state:                                     */
	sm_graphics ();

	/* Initialize the file into which we are plotting to:                       */
	if (device == x11)
		sprintf (working_str, "aspectxpm %s/phoebe_rv_%03d.xpm", PHOEBE_TEMP_DIR, scan_temporary_directory_for_lci_file_index ("phoebe_rv"));
	if (device == eps)
		sprintf (working_str, "postfile %s", filename);
	if (device == xpm)
		sprintf (working_str, "aspectxpm %s", filename);
	if (device == gif)
		sprintf (working_str, "aspectgif %s", filename);
	if (device == ppm)
		sprintf (working_str, "ppm %s", filename);
	if (device == tinygif)
		sprintf (working_str, "tinygif %s", filename);

	sm_device (working_str);

	/* Set the main plot characteristics:                                       */
	sm_expand (1.0001);
	sm_ptype (ptype, 3);
	sm_defvar("TeX_strings", "1");

	/* Calculate and set plotting limits:                                       */
	calculate_plot_limits (synthetic_data, experimental_data, &xmin, &ymin, &xmax, &ymax, plot_synthetic, plot_experimental, x_offset, y_offset, zoom);
	sm_limits (xmin, xmax, ymin, ymax);

	if (box  == 1) sm_box (1, 2, 4, 4);
	if (box  == 0) sm_box (1, 2, 0, 0);
	if (grid == 1) { sm_ltype (1); sm_grid (0, 0); sm_ltype (0); }
	if (grid == 2) { sm_ltype (1); sm_grid (1, 0); sm_ltype (0); }

	if (plot_experimental == 1)
		{
		sm_ctype ("blue");
		sm_points  (experimental_data.indep, experimental_data.dep, experimental_data.ptsno);
		}

	if (plot_synthetic == 1)
		{
		sm_ctype ("red");
		sm_connect (synthetic_data.indep, synthetic_data.dep, synthetic_data.ptsno);
		}

	sm_ctype ("black");
	if (indep == 1) sm_xlabel ("HJD");
	if (indep == 2) sm_xlabel ("Phase");
	if (  dep == 3) sm_ylabel ("Normalized Primary Star RV");
	if (  dep == 4) sm_ylabel ("Normalized Secondary Star RV");
	if (  dep == 5) sm_ylabel ("Primary Star Eclipse Corrections");
	if (  dep == 6) sm_ylabel ("Secondary Star Eclipse Corrections");
	if (  dep == 7) sm_ylabel ("Primary Star RV");
	if (  dep == 8) sm_ylabel ("Secondary Star RV");

	/* Flush graphics output to screen:                                         */
	sm_gflush();

	/* Set the terminal back to normal state:                                   */
	sm_hardcopy ();
	sm_alpha ();

	free (ptype);
	}
	
void create_sm_script_for_chi2_plot (int dimx, int dimy)
	{
	char working_string[255];
	char *working_str = working_string;

	char symlink_string[255];
	char *symlink_str = symlink_string;

	FILE *sm_file;

	sprintf (working_str, "%s/phoebe_c2.sm", PHOEBE_TEMP_DIR);
	sm_file = fopen (working_str, "w");

	fprintf (sm_file, "device tinyxpm phoebe_c2.xpm\n");
	fprintf (sm_file, "expand 1.001\n");
	fprintf (sm_file, "data phoebe_c2.data\n");
	fprintf (sm_file, "read {i 1 j 2 chi2 3}\n");
	fprintf (sm_file, "vecminmax i minx maxx\n");
	fprintf (sm_file, "vecminmax j miny maxy\n");
	fprintf (sm_file, "image (%d,%d)\n", dimx, dimy);
	fprintf (sm_file, "do m=0,%d {\n", dimx-1);
	fprintf (sm_file, "  do k=0,%d {\n", dimy-1);
	fprintf (sm_file, "    set image[$m,$k] = chi2[%d*$m+$k]\n", dimy);
	fprintf (sm_file, "  }\n");
	fprintf (sm_file, "}\n");
	fprintf (sm_file, "load surfaces\n");
	fprintf (sm_file, "overload viewpoint 1\n");
	fprintf (sm_file, "overload surface 1\n");
	fprintf (sm_file, "viewpoint 20 45 0\n");
	fprintf (sm_file, "surface\n");
	fprintf (sm_file, "define Lo_x ($minx)\n");
	fprintf (sm_file, "define Lo_y ($miny)\n");
	fprintf (sm_file, "define Hi_x ($maxx)\n");
	fprintf (sm_file, "define Hi_y ($maxy)\n");
	fprintf (sm_file, "box3\n");
	fprintf (sm_file, "#label3 x x\n");
	fprintf (sm_file, "#label3 y y\n");
	fprintf (sm_file, "#label3 z \\chi^2\n");
	fprintf (sm_file, "device nodevice\n");

	fclose (sm_file);

	sprintf (working_str, "%s/phoebe_init.sm", PHOEBE_SHARE_DIR);
	sprintf (symlink_str, "%s/phoebe_init.sm", PHOEBE_TEMP_DIR);
	if (! file_exists (symlink_str)) symlink (working_str, symlink_str);

	sprintf (working_str, "sm -f phoebe_init.sm -S execute phoebe_c2.sm quit > phoebe_c2.sm.log");
	system (working_str);
	}

void create_chi2_plot (char *filter, int plot_type, int x_param, double x_param_min, double x_param_max, int x_param_steps, int y_param, double y_param_min, double y_param_max, int y_param_steps)
	{
	double EPSILON = 1e-3;

	PHOEBE_main_parameters  main     = read_in_main_parameters ();
	PHOEBE_switches         switches = read_in_switches ();
	PHOEBE_limb_darkening   ld       = read_in_ld_coefficients ();
	PHOEBE_spots            spots    = read_in_spots ();
	PHOEBE_curve_parameters curve    = read_in_curve_parameters ();
	PHOEBE_wl_dependent_parameters mono;

	GtkWidget *readout_widget;

	new_PHOEBE_data synthetic_data;
	new_PHOEBE_data experimental_data;

	PHOEBE_calculated_parameters dummy;

	double x, y;
	double *par1, *par2;

	char working_string[255];
	char *working_str = working_string;

	double percentage = 0.0;
	double chi2;

	int i;
	int curve_no;

	FILE *data_file;

	GtkWidget *progress_bar = lookup_widget (PHOEBE, "fitting_chi2_progress_bar");
	GtkWidget *new_image;

	char buffer_string[255];
	char *buffer_str = buffer_string;

	/* Initialize string "buffer" to hold the current working directory; due to */
	/* SuperMongo path-reading problems, we will change to PHOEBE_TEMP_DIR,     */
	/* execute the script and then go back to the previous directory, wherever  */
	/* that was prior to execution:                                             */
	buffer_str = getcwd (NULL, 0);
	chdir (PHOEBE_TEMP_DIR);

	sprintf (working_str, "%s/phoebe_c2.data", PHOEBE_TEMP_DIR);
	data_file = fopen (working_str, "w");

	/* 1. step: let's use pointers *par1 and *par2 to point to corresponding    */
	/* main.PARAM which the user wants to correlate:                            */
	if (x_param == 9)  par1 = &main.SMA;
	if (x_param == 10) par1 = &main.E;
	if (x_param == 11) par1 = &main.PERR0;
	if (x_param == 12) par1 = &main.F1;
	if (x_param == 13) par1 = &main.F2;
	if (x_param == 14) par1 = &main.PSHIFT;
	if (x_param == 15) par1 = &main.VGA;
	if (x_param == 16) par1 = &main.XINCL;
	if (x_param == 17) par1 = &main.GR1;
	if (x_param == 18) par1 = &main.GR2;
	if (x_param == 19) par1 = &main.TAVH;
	if (x_param == 20) par1 = &main.TAVC;
	if (x_param == 21) par1 = &main.ALB1;
	if (x_param == 22) par1 = &main.ALB2;
	if (x_param == 23) par1 = &main.PHSV;
	if (x_param == 24) par1 = &main.PCSV;
	if (x_param == 25) par1 = &main.RM;
	if (x_param == 26) par1 = &main.HJD0;
	if (x_param == 27) par1 = &main.PERIOD;
	if (x_param == 28) par1 = &main.DPDT;
	if (x_param == 29) par1 = &main.DPERDT;

	if (y_param == 9)  par2 = &main.SMA;
	if (y_param == 10) par1 = &main.E;
	if (y_param == 11) par2 = &main.PERR0;
	if (y_param == 12) par2 = &main.F1;
	if (y_param == 13) par2 = &main.F2;
	if (y_param == 14) par2 = &main.PSHIFT;
	if (y_param == 15) par2 = &main.VGA;
	if (y_param == 16) par2 = &main.XINCL;
	if (y_param == 17) par2 = &main.GR1;
	if (y_param == 18) par2 = &main.GR2;
	if (y_param == 19) par2 = &main.TAVH;
	if (y_param == 20) par2 = &main.TAVC;
	if (y_param == 21) par2 = &main.ALB1;
	if (y_param == 22) par2 = &main.ALB2;
	if (y_param == 23) par2 = &main.PHSV;
	if (y_param == 24) par2 = &main.PCSV;
	if (y_param == 25) par2 = &main.RM;
	if (y_param == 26) par2 = &main.HJD0;
	if (y_param == 27) par2 = &main.PERIOD;
	if (y_param == 28) par2 = &main.DPDT;
	if (y_param == 29) par2 = &main.DPERDT;

	/* 2. step: prepare MPAGE and JDPHS for correlation use:                    */
	switches.MPAGE = 1;
	switches.JDPHS = 2;

	/* 3. step: read out wavelength dependent parameters based on the chosen    */
	/* filter and read out experimental data:                                   */
	mono = read_in_wl_dependent_parameters (filter);
	curve_no = 0; while (strcmp (filter, PHOEBE_lc_data[curve_no].filter) != 0) curve_no++;
	read_in_experimental_lc_data (curve_no, &experimental_data, 2, 5);

	/* 4. step: turn off the Calculate button; since we leave PHOEBE at pending,*/
	/* it is very important that this button stays off until the end of the     */
	/* calculation:                                                             */
	gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE, "fitting_chi2_calculate_button")), FALSE);

	/* We have prepared everything, now we go into the calculation loop:        */
	for (x = x_param_min; x <= x_param_max + EPSILON; x += (x_param_max - x_param_min) / (x_param_steps - 1))
		{
		for (y = y_param_min; y <= y_param_max + EPSILON; y += (y_param_max - y_param_min) / (y_param_steps - 1))
			{
			/* Change the two parameters that par1 and par2 point to:               */
			*par1 = x;
			*par2 = y;

			/* Create a LCI input file and call lc program on it:                   */
			create_lci_input_file ("phoebe_lc", main, switches, ld, spots, curve, mono, 100000002., 0.0);

			/* Prepare a system call string and call it:                            */
			i = scan_temporary_directory_for_lci_file_index ("phoebe_lc");
			sprintf (working_str, "%s/lc < %s/phoebe_lc_%03d.lci > %s/phoebe_lc_%03d.lco", PHOEBE_LC_DIR, PHOEBE_TEMP_DIR, i, PHOEBE_TEMP_DIR, i);
			system (working_str);

			/* Get synthetic points from LCO file:                                  */
			sprintf (working_str, "%s/phoebe_lc_%03d.lco", PHOEBE_TEMP_DIR, i);
			read_in_synthetic_lc_data (working_str, &synthetic_data, &dummy, 2, 5);

			/* Calculate chi2 and write it to temporary SuperMongo file:            */
			chi2 = calculate_chi2 (synthetic_data, experimental_data, mono.SIGMA);
			fprintf (data_file, "%lf %lf %lf\n", x, y, chi2);

			/* Free memory for the next iteration:                                  */
			free (synthetic_data.indep);
			free (synthetic_data.dep);
			free (synthetic_data.weight);

			/* Be sure that this calculation doesn't stop PHOEBE from responding:   */
			while (gtk_events_pending()) gtk_main_iteration ();

			/* Increase the progress meter: */
			percentage += 1.0 / x_param_steps / y_param_steps;
			gtk_progress_bar_update (GTK_PROGRESS_BAR (progress_bar), percentage);
			}
		}

	/* We're out of the loop, so let's turn the Calculate button back on:       */
	gtk_widget_set_sensitive (GTK_WIDGET (lookup_widget (PHOEBE, "fitting_chi2_calculate_button")), TRUE);

	/* The chi2 file is ready, let's close it and free exp_data memory:         */
	fclose (data_file);
	free (experimental_data.indep);
	free (experimental_data.dep);
	free (experimental_data.weight);

	/* Create SM script for chi2 plot and call SuperMongo:                      */
	create_sm_script_for_chi2_plot (x_param_steps, y_param_steps);

	/* Erase the old image:                                                     */
	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_image_frame");
	gtk_widget_destroy (GTK_BIN (readout_widget)->child);

	/* Create a new image on the screen:                                        */
	readout_widget = lookup_widget (PHOEBE, "fitting_chi2_image_frame");
	new_image = create_pixmap (PHOEBE, "phoebe_c2.xpm");
	gtk_container_add (GTK_CONTAINER (readout_widget), new_image);
	gtk_widget_show (new_image);

	/* That's it, folks; we go back to main...                                  */
	chdir (buffer_str);
	return;
	}
