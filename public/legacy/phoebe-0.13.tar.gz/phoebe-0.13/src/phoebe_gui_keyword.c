#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "phoebe_global.h"
#include "phoebe_gui_accessories.h"
#include "phoebe_gui_keyword.h"
#include "phoebe_gui_support.h"

void add_to_keyword_file (const char *keyword, enum keyword_type type, GtkWidget *WIDGET, const char *widget_name, FILE *keyword_file)
	{
	GtkWidget *readout_widget;
	int readout_int;
	double readout_double;
	char readout_string[255];
	char *readout_str = readout_string;
	int i, rows;

	readout_widget = lookup_widget (WIDGET, widget_name);
	switch (type)
		{
		case TYPE_INT:
			readout_int = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (readout_widget));
			fprintf (keyword_file, "%-15s%d\n", keyword, readout_int);
		break;
		case TYPE_DBL:
			readout_double = gtk_spin_button_get_value_as_float (GTK_SPIN_BUTTON (readout_widget));
			fprintf (keyword_file, "%-15s%lf\n", keyword, readout_double);
		break;
		case TYPE_STR:
			readout_str = gtk_entry_get_text (GTK_ENTRY (readout_widget));
			fprintf (keyword_file, "%-15s%s\n", keyword, readout_str);
		break;
		case TYPE_BOO:
			if (GTK_TOGGLE_BUTTON (readout_widget)->active)
				fprintf (keyword_file, "%-15s%d\n", keyword, 1);
			else
				fprintf (keyword_file, "%-15s%d\n", keyword, 0);
		break;
		case TYPE_LST:
			rows = (GTK_CLIST (readout_widget))->rows;
			for (i = 0; i < rows; i++)
				{
				if (strcmp (keyword, "LC") == 0)
					{
					fprintf (keyword_file, "%sCOL1%d%-8s%s\n", keyword, i+1, ":", PHOEBE_lc_data[i].column1);
					fprintf (keyword_file, "%sCOL2%d%-8s%s\n", keyword, i+1, ":", PHOEBE_lc_data[i].column2);
					fprintf (keyword_file, "%sCOL3%d%-8s%s\n", keyword, i+1, ":", PHOEBE_lc_data[i].column3);
					fprintf (keyword_file, "%sFN%d%-10s%s\n",  keyword, i+1, ":", PHOEBE_lc_data[i].filename);
					fprintf (keyword_file, "%sSIG%d%-9s%s\n",  keyword, i+1, ":", PHOEBE_lc_data[i].sigma);
					fprintf (keyword_file, "%sFLT%d%-9s%s\n",  keyword, i+1, ":", PHOEBE_lc_data[i].filter);
					}
				if (strcmp (keyword, "RV") == 0)
					{
					fprintf (keyword_file, "%sCOL1%d%-8s%s\n", keyword, i+1, ":", PHOEBE_rv_data[i].column1);
					fprintf (keyword_file, "%sCOL2%d%-8s%s\n", keyword, i+1, ":", PHOEBE_rv_data[i].column2);
					fprintf (keyword_file, "%sCOL3%d%-8s%s\n", keyword, i+1, ":", PHOEBE_rv_data[i].column3);
					fprintf (keyword_file, "%sFN%d%-10s%s\n",  keyword, i+1, ":", PHOEBE_rv_data[i].filename);
					fprintf (keyword_file, "%sSIG%d%-9s%s\n",  keyword, i+1, ":", PHOEBE_rv_data[i].sigma);
					fprintf (keyword_file, "%sFLT%d%-9s%s\n",  keyword, i+1, ":", PHOEBE_rv_data[i].filter);
					}
				if (strcmp (keyword, "LUMLC") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "HLALC%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
					fprintf (keyword_file, "CLALC%d%-9s%s\n", i+1, ":", readout_str);
					}
				if (strcmp (keyword, "LUMRV") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "HLARV%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
					fprintf (keyword_file, "CLARV%d%-9s%s\n", i+1, ":", readout_str);
					}
				if (strcmp (keyword, "EL3") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "EL3%d%-11s%s\n", i+1, ":", readout_str);
					}
				if (strcmp (keyword, "LDLC") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "X1ALC%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
					fprintf (keyword_file, "Y1ALC%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 3, &readout_str);
					fprintf (keyword_file, "X2ALC%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 4, &readout_str);
					fprintf (keyword_file, "Y2ALC%d%-9s%s\n", i+1, ":", readout_str);
					}
				if (strcmp (keyword, "LDRV") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "X1ARV%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 2, &readout_str);
					fprintf (keyword_file, "Y1ARV%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 3, &readout_str);
					fprintf (keyword_file, "X2ARV%d%-9s%s\n", i+1, ":", readout_str);
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 4, &readout_str);
					fprintf (keyword_file, "Y2ARV%d%-9s%s\n", i+1, ":", readout_str);
					}
				if (strcmp (keyword, "WEIGHTS") == 0)
					{
					gtk_clist_get_text (GTK_CLIST (readout_widget), i, 1, &readout_str);
					fprintf (keyword_file, "WEIGHT%d%-8s%s\n", i+1, ":", readout_str);
					}
				}
		break;
		}
	}

void get_from_keyword_file (enum keyword_type type, GtkWidget *parent, const char *widget_name, FILE *keyword_file)
	{
	GtkWidget *readout_widget;
	int        readout_int;
	double     readout_dbl;

	switch (type)
		{
		case TYPE_INT:
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (parent, widget_name);
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
		break;
		case TYPE_DBL:
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (parent, widget_name);
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
		break;
		}
	}

void save_keyword_file ()
	{
	char filename[255];
	char *file_name_ptr = filename;

	FILE *keyword_file;

	file_name_ptr = gtk_file_selection_get_filename (GTK_FILE_SELECTION (PHOEBE_save_keyword_file));

	gtk_widget_hide (PHOEBE_save_keyword_file);

	keyword_file = fopen (file_name_ptr, "wb");

	/* ****************************** DATA TAB ******************************** */

	add_to_keyword_file ("NAME:",       TYPE_STR, PHOEBE, "data_star_name_entry", keyword_file);
	add_to_keyword_file ("MODEL:",      TYPE_STR, PHOEBE, "data_model_list_entry", keyword_file);
	add_to_keyword_file ("LCNO:",       TYPE_INT, PHOEBE, "data_lc_no_value", keyword_file);
	add_to_keyword_file ("RVNO:",       TYPE_INT, PHOEBE, "data_rv_no_value", keyword_file);
	add_to_keyword_file ("MNORM:",      TYPE_DBL, PHOEBE, "data_zero_magnitude_value", keyword_file);
	add_to_keyword_file ("BINNING:",    TYPE_BOO, PHOEBE, "data_binning_switch", keyword_file);
	add_to_keyword_file ("BINVAL:",     TYPE_INT, PHOEBE, "data_binning_value", keyword_file);
	add_to_keyword_file ("LC",          TYPE_LST, PHOEBE, "data_lc_info_list", keyword_file);
	add_to_keyword_file ("RV",          TYPE_LST, PHOEBE, "data_rv_info_list", keyword_file);

	/* ***************************** BASIC TAB ******************************** */

	add_to_keyword_file ("SMA:",        TYPE_DBL, PHOEBE, "basic_sma_value", keyword_file);
	add_to_keyword_file ("SMA_ADJ:",    TYPE_BOO, PHOEBE, "basic_sma_adjust", keyword_file);
	add_to_keyword_file ("SMA_DEL:",    TYPE_DBL, PHOEBE, "basic_sma_del_value", keyword_file);
	add_to_keyword_file ("SMA_MIN:",    TYPE_DBL, PHOEBE, "basic_sma_value_min", keyword_file);
	add_to_keyword_file ("SMA_MAX:",    TYPE_DBL, PHOEBE, "basic_sma_value_max", keyword_file);
	add_to_keyword_file ("RM:",         TYPE_DBL, PHOEBE, "basic_rm_value", keyword_file);
	add_to_keyword_file ("RM_ADJ:",     TYPE_BOO, PHOEBE, "basic_rm_adjust", keyword_file);
	add_to_keyword_file ("RM_DEL:",     TYPE_DBL, PHOEBE, "basic_rm_del_value", keyword_file);
	add_to_keyword_file ("RM_MIN:",     TYPE_DBL, PHOEBE, "basic_rm_value_min", keyword_file);
	add_to_keyword_file ("RM_MAX:",     TYPE_DBL, PHOEBE, "basic_rm_value_max", keyword_file);
	add_to_keyword_file ("PERIOD:",     TYPE_STR, PHOEBE, "basic_period_value", keyword_file);
	add_to_keyword_file ("PERIOD_ADJ:", TYPE_BOO, PHOEBE, "basic_period_adjust", keyword_file);
	add_to_keyword_file ("PERIOD_DEL:", TYPE_DBL, PHOEBE, "basic_period_del_value", keyword_file);
	add_to_keyword_file ("PERIOD_MIN:", TYPE_STR, PHOEBE, "basic_period_value_min", keyword_file);
	add_to_keyword_file ("PERIOD_MAX:", TYPE_STR, PHOEBE, "basic_period_value_max", keyword_file);
	add_to_keyword_file ("HJD0:",       TYPE_STR, PHOEBE, "basic_hjd0_value", keyword_file);
	add_to_keyword_file ("HJD0_ADJ:",   TYPE_BOO, PHOEBE, "basic_hjd0_adjust", keyword_file);
	add_to_keyword_file ("HJD0_DEL:",   TYPE_DBL, PHOEBE, "basic_hjd0_del_value", keyword_file);
	add_to_keyword_file ("HJD0_MIN:",   TYPE_STR, PHOEBE, "basic_hjd0_value_min", keyword_file);
	add_to_keyword_file ("HJD0_MAX:",   TYPE_STR, PHOEBE, "basic_hjd0_value_max", keyword_file);
	add_to_keyword_file ("TAVH:",       TYPE_DBL, PHOEBE, "basic_tavh_value", keyword_file);
	add_to_keyword_file ("TAVH_ADJ:",   TYPE_BOO, PHOEBE, "basic_tavh_adjust", keyword_file);
	add_to_keyword_file ("TAVH_DEL:",   TYPE_DBL, PHOEBE, "basic_tavh_del_value", keyword_file);
	add_to_keyword_file ("TAVH_MIN:",   TYPE_DBL, PHOEBE, "basic_tavh_value_min", keyword_file);
	add_to_keyword_file ("TAVH_MAX:",   TYPE_DBL, PHOEBE, "basic_tavh_value_max", keyword_file);
	add_to_keyword_file ("TAVC:",       TYPE_DBL, PHOEBE, "basic_tavc_value", keyword_file);
	add_to_keyword_file ("TAVC_ADJ:",   TYPE_BOO, PHOEBE, "basic_tavc_adjust", keyword_file);
	add_to_keyword_file ("TAVC_DEL:",   TYPE_DBL, PHOEBE, "basic_tavc_del_value", keyword_file);
	add_to_keyword_file ("TAVC_MIN:",   TYPE_DBL, PHOEBE, "basic_tavc_value_min", keyword_file);
	add_to_keyword_file ("TAVC_MAX:",   TYPE_DBL, PHOEBE, "basic_tavc_value_max", keyword_file);
	add_to_keyword_file ("XINCL:",      TYPE_DBL, PHOEBE, "basic_xincl_value", keyword_file);
	add_to_keyword_file ("XINCL_ADJ:",  TYPE_BOO, PHOEBE, "basic_xincl_adjust", keyword_file);
	add_to_keyword_file ("XINCL_DEL:",  TYPE_DBL, PHOEBE, "basic_xincl_del_value", keyword_file);
	add_to_keyword_file ("XINCL_MIN:",  TYPE_DBL, PHOEBE, "basic_xincl_value_min", keyword_file);
	add_to_keyword_file ("XINCL_MAX:",  TYPE_DBL, PHOEBE, "basic_xincl_value_max", keyword_file);
	add_to_keyword_file ("VGA:",        TYPE_DBL, PHOEBE, "basic_vga_value", keyword_file);
	add_to_keyword_file ("VGA_ADJ:",    TYPE_BOO, PHOEBE, "basic_vga_adjust", keyword_file);
	add_to_keyword_file ("VGA_DEL:",    TYPE_DBL, PHOEBE, "basic_vga_del_value", keyword_file);
	add_to_keyword_file ("VGA_MIN:",    TYPE_DBL, PHOEBE, "basic_vga_value_min", keyword_file);
	add_to_keyword_file ("VGA_MAX:",    TYPE_DBL, PHOEBE, "basic_vga_value_max", keyword_file);

	/* **************************** ADVANCED TAB ****************************** */

	add_to_keyword_file ("PHSV:",       TYPE_DBL, PHOEBE, "advanced_phsv_value", keyword_file);
	add_to_keyword_file ("PHSV_ADJ:",   TYPE_BOO, PHOEBE, "advanced_phsv_adjust", keyword_file);
	add_to_keyword_file ("PHSV_DEL:",   TYPE_DBL, PHOEBE, "advanced_phsv_del_value", keyword_file);
	add_to_keyword_file ("PHSV_MIN:",   TYPE_DBL, PHOEBE, "advanced_phsv_value_min", keyword_file);
	add_to_keyword_file ("PHSV_MAX:",   TYPE_DBL, PHOEBE, "advanced_phsv_value_max", keyword_file);
	add_to_keyword_file ("PCSV:",       TYPE_DBL, PHOEBE, "advanced_pcsv_value", keyword_file);
	add_to_keyword_file ("PCSV_ADJ:",   TYPE_BOO, PHOEBE, "advanced_pcsv_adjust", keyword_file);
	add_to_keyword_file ("PCSV_DEL:",   TYPE_DBL, PHOEBE, "advanced_pcsv_del_value", keyword_file);
	add_to_keyword_file ("PCSV_MIN:",   TYPE_DBL, PHOEBE, "advanced_pcsv_value_min", keyword_file);
	add_to_keyword_file ("PCSV_MAX:",   TYPE_DBL, PHOEBE, "advanced_pcsv_value_max", keyword_file);
	add_to_keyword_file ("GR1:",        TYPE_DBL, PHOEBE, "advanced_gr1_value", keyword_file);
	add_to_keyword_file ("GR1_ADJ:",    TYPE_BOO, PHOEBE, "advanced_gr1_adjust", keyword_file);
	add_to_keyword_file ("GR1_DEL:",    TYPE_DBL, PHOEBE, "advanced_gr1_del_value", keyword_file);
	add_to_keyword_file ("GR1_MIN:",    TYPE_DBL, PHOEBE, "advanced_gr1_value_min", keyword_file);
	add_to_keyword_file ("GR1_MAX:",    TYPE_DBL, PHOEBE, "advanced_gr1_value_max", keyword_file);
	add_to_keyword_file ("GR2:",        TYPE_DBL, PHOEBE, "advanced_gr2_value", keyword_file);
	add_to_keyword_file ("GR2_ADJ:",    TYPE_BOO, PHOEBE, "advanced_gr2_adjust", keyword_file);
	add_to_keyword_file ("GR2_DEL:",    TYPE_DBL, PHOEBE, "advanced_gr2_del_value", keyword_file);
	add_to_keyword_file ("GR2_MIN:",    TYPE_DBL, PHOEBE, "advanced_gr2_value_min", keyword_file);
	add_to_keyword_file ("GR2_MAX:",    TYPE_DBL, PHOEBE, "advanced_gr2_value_max", keyword_file);
	add_to_keyword_file ("ALB1:",       TYPE_DBL, PHOEBE, "advanced_alb1_value", keyword_file);
	add_to_keyword_file ("ALB1_ADJ:",   TYPE_BOO, PHOEBE, "advanced_alb1_adjust", keyword_file);
	add_to_keyword_file ("ALB1_DEL:",   TYPE_DBL, PHOEBE, "advanced_alb1_del_value", keyword_file);
	add_to_keyword_file ("ALB1_MIN:",   TYPE_DBL, PHOEBE, "advanced_alb1_value_min", keyword_file);
	add_to_keyword_file ("ALB1_MAX:",   TYPE_DBL, PHOEBE, "advanced_alb1_value_max", keyword_file);
	add_to_keyword_file ("ALB2:",       TYPE_DBL, PHOEBE, "advanced_alb2_value", keyword_file);
	add_to_keyword_file ("ALB2_ADJ:",   TYPE_BOO, PHOEBE, "advanced_alb2_adjust", keyword_file);
	add_to_keyword_file ("ALB2_DEL:",   TYPE_DBL, PHOEBE, "advanced_alb2_del_value", keyword_file);
	add_to_keyword_file ("ALB2_MIN:",   TYPE_DBL, PHOEBE, "advanced_alb2_value_min", keyword_file);
	add_to_keyword_file ("ALB2_MAX:",   TYPE_DBL, PHOEBE, "advanced_alb2_value_max", keyword_file);
	add_to_keyword_file ("F1:",         TYPE_DBL, PHOEBE, "advanced_f1_value", keyword_file);
	add_to_keyword_file ("F1_ADJ:",     TYPE_BOO, PHOEBE, "advanced_f1_adjust", keyword_file);
	add_to_keyword_file ("F1_DEL:",     TYPE_DBL, PHOEBE, "advanced_f1_del_value", keyword_file);
	add_to_keyword_file ("F1_MIN:",     TYPE_DBL, PHOEBE, "advanced_f1_value_min", keyword_file);
	add_to_keyword_file ("F1_MAX:",     TYPE_DBL, PHOEBE, "advanced_f1_value_max", keyword_file);
	add_to_keyword_file ("F2:",         TYPE_DBL, PHOEBE, "advanced_f2_value", keyword_file);
	add_to_keyword_file ("F2_ADJ:",     TYPE_BOO, PHOEBE, "advanced_f2_adjust", keyword_file);
	add_to_keyword_file ("F2_DEL:",     TYPE_DBL, PHOEBE, "advanced_f2_del_value", keyword_file);
	add_to_keyword_file ("F2_MIN:",     TYPE_DBL, PHOEBE, "advanced_f2_value_min", keyword_file);
	add_to_keyword_file ("F2_MAX:",     TYPE_DBL, PHOEBE, "advanced_f2_value_max", keyword_file);

	/* ***************************** ORBIT TAB ******************************** */

	add_to_keyword_file ("E:",          TYPE_DBL, PHOEBE, "orbit_e_value", keyword_file);
	add_to_keyword_file ("E_ADJ:",      TYPE_BOO, PHOEBE, "orbit_e_adjust", keyword_file);
	add_to_keyword_file ("E_DEL:",      TYPE_DBL, PHOEBE, "orbit_e_del_value", keyword_file);
	add_to_keyword_file ("E_MIN:",      TYPE_DBL, PHOEBE, "orbit_e_value_min", keyword_file);
	add_to_keyword_file ("E_MAX:",      TYPE_DBL, PHOEBE, "orbit_e_value_max", keyword_file);
	add_to_keyword_file ("PERR0:",      TYPE_DBL, PHOEBE, "orbit_perr0_value", keyword_file);
	add_to_keyword_file ("PERR0_ADJ:",  TYPE_BOO, PHOEBE, "orbit_perr0_adjust", keyword_file);
	add_to_keyword_file ("PERR0_DEL:",  TYPE_DBL, PHOEBE, "orbit_perr0_del_value", keyword_file);
	add_to_keyword_file ("PERR0_MIN:",  TYPE_DBL, PHOEBE, "orbit_perr0_value_min", keyword_file);
	add_to_keyword_file ("PERR0_MAX:",  TYPE_DBL, PHOEBE, "orbit_perr0_value_max", keyword_file);
	add_to_keyword_file ("DPERDT:",     TYPE_DBL, PHOEBE, "orbit_dperdt_value", keyword_file);
	add_to_keyword_file ("DPERDT_ADJ:", TYPE_BOO, PHOEBE, "orbit_dperdt_adjust", keyword_file);
	add_to_keyword_file ("DPERDT_DEL:", TYPE_DBL, PHOEBE, "orbit_dperdt_del_value", keyword_file);
	add_to_keyword_file ("DPERDT_MIN:", TYPE_DBL, PHOEBE, "orbit_dperdt_value_min", keyword_file);
	add_to_keyword_file ("DPERDT_MAX:", TYPE_DBL, PHOEBE, "orbit_dperdt_value_max", keyword_file);
	add_to_keyword_file ("DPDT:",       TYPE_DBL, PHOEBE, "orbit_dpdt_value", keyword_file);
	add_to_keyword_file ("DPDT_ADJ:",   TYPE_BOO, PHOEBE, "orbit_dpdt_adjust", keyword_file);
	add_to_keyword_file ("DPDT_DEL:",   TYPE_DBL, PHOEBE, "orbit_dpdt_del_value", keyword_file);
	add_to_keyword_file ("DPDT_MIN:",   TYPE_DBL, PHOEBE, "orbit_dpdt_value_min", keyword_file);
	add_to_keyword_file ("DPDT_MAX:",   TYPE_DBL, PHOEBE, "orbit_dpdt_value_max", keyword_file);
	add_to_keyword_file ("PSHIFT:",     TYPE_DBL, PHOEBE, "orbit_pshift_value", keyword_file);
	add_to_keyword_file ("PSHIFT_ADJ:", TYPE_BOO, PHOEBE, "orbit_pshift_adjust", keyword_file);
	add_to_keyword_file ("PSHIFT_DEL:", TYPE_DBL, PHOEBE, "orbit_pshift_del_value", keyword_file);
	add_to_keyword_file ("PSHIFT_MIN:", TYPE_DBL, PHOEBE, "orbit_pshift_value_min", keyword_file);
	add_to_keyword_file ("PSHIFT_MAX:", TYPE_DBL, PHOEBE, "orbit_pshift_value_max", keyword_file);

	/* ************************** LUMINOSITIES TAB **************************** */

	add_to_keyword_file ("LUMLC",       TYPE_LST, PHOEBE, "luminosities_lc_info_list", keyword_file);
	add_to_keyword_file ("LUMRV",       TYPE_LST, PHOEBE, "luminosities_rv_info_list", keyword_file);
	add_to_keyword_file ("EL3",         TYPE_LST, PHOEBE, "luminosities_el3_info_list", keyword_file);
	add_to_keyword_file ("WEIGHTS",     TYPE_LST, PHOEBE, "luminosities_weighting_info_list", keyword_file);
	add_to_keyword_file ("HLA_ADJ:",    TYPE_BOO, PHOEBE, "luminosities_hla_adjust", keyword_file);
	add_to_keyword_file ("HLA_DEL:",    TYPE_DBL, PHOEBE, "luminosities_hla_del_value", keyword_file);
	add_to_keyword_file ("CLA_DEL:",    TYPE_DBL, PHOEBE, "luminosities_cla_del_value", keyword_file);
	add_to_keyword_file ("EL3_ADJ:",    TYPE_BOO, PHOEBE, "luminosities_el3_adjust", keyword_file);
	add_to_keyword_file ("IPB_ON:",     TYPE_BOO, PHOEBE, "luminosities_ipb_switch", keyword_file);
	add_to_keyword_file ("NREF_ON:",    TYPE_BOO, PHOEBE, "luminosities_nref_switch", keyword_file);
	add_to_keyword_file ("NREF_VAL:",   TYPE_INT, PHOEBE, "luminosities_nref_value", keyword_file);
	add_to_keyword_file ("IFAT1_ON:",   TYPE_BOO, PHOEBE, "luminosities_ifat1_switch", keyword_file);
	add_to_keyword_file ("IFAT2_ON:",   TYPE_BOO, PHOEBE, "luminosities_ifat2_switch", keyword_file);
	add_to_keyword_file ("NOISE_ON:",   TYPE_BOO, PHOEBE, "luminosities_stdev_switch", keyword_file);
	add_to_keyword_file ("STDEV_VAL:",  TYPE_DBL, PHOEBE, "luminosities_stdev_value", keyword_file);
	add_to_keyword_file ("SEED_VAL:",   TYPE_INT, PHOEBE, "luminosities_seed_value", keyword_file);

	/* **************************** SWITCHES TAB ****************************** */

	add_to_keyword_file ("PHNORM_VAL:", TYPE_DBL, PHOEBE_plot_lc, "plot_lc_phnorm_value", keyword_file);
	add_to_keyword_file ("FACTOR_VAL:", TYPE_DBL, PHOEBE_plot_lc, "plot_lc_factor_value", keyword_file);
	add_to_keyword_file ("MZERO_VAL:",  TYPE_DBL, PHOEBE_plot_lc, "plot_lc_mzero_value", keyword_file);
	add_to_keyword_file ("VUNIT_VAL:",  TYPE_DBL, PHOEBE_plot_rv, "plot_rv_vunit_value", keyword_file);
	add_to_keyword_file ("ICOR1_ON:",   TYPE_BOO, PHOEBE, "luminosities_icor1_switch", keyword_file);
	add_to_keyword_file ("ICOR2_ON:",   TYPE_BOO, PHOEBE, "luminosities_icor2_switch", keyword_file);
	add_to_keyword_file ("THE_VAL:",    TYPE_DBL, PHOEBE, "data_the_value", keyword_file);

	/* ******************************* LD TAB ********************************* */

	add_to_keyword_file ("LD:",         TYPE_STR, PHOEBE, "ld_ld_law_combo_box_entry", keyword_file);
	add_to_keyword_file ("XBOL1:",      TYPE_DBL, PHOEBE, "ld_xbol1_value", keyword_file);
	add_to_keyword_file ("XBOL2:",      TYPE_DBL, PHOEBE, "ld_xbol2_value", keyword_file);
	add_to_keyword_file ("YBOL1:",      TYPE_DBL, PHOEBE, "ld_ybol1_value", keyword_file);
	add_to_keyword_file ("YBOL2:",      TYPE_DBL, PHOEBE, "ld_ybol2_value", keyword_file);
	add_to_keyword_file ("LDLC",        TYPE_LST, PHOEBE, "ld_monochromatic_lc_info_list", keyword_file);
	add_to_keyword_file ("LDRV",        TYPE_LST, PHOEBE, "ld_monochromatic_rv_info_list", keyword_file);
	add_to_keyword_file ("X1A_DEL:",    TYPE_DBL, PHOEBE, "ld_x1a_del_value", keyword_file);
	add_to_keyword_file ("X2A_DEL:",    TYPE_DBL, PHOEBE, "ld_x2a_del_value", keyword_file);
	add_to_keyword_file ("X1A_ADJ:",    TYPE_BOO, PHOEBE, "ld_x1a_adjust", keyword_file);
	add_to_keyword_file ("X2A_ADJ:",    TYPE_BOO, PHOEBE, "ld_x2a_adjust", keyword_file);
	add_to_keyword_file ("LOGG1:",      TYPE_DBL, PHOEBE_ld_interpolation, "ld_interpolation_primary_logg_value", keyword_file);
	add_to_keyword_file ("LOGG2:",      TYPE_DBL, PHOEBE_ld_interpolation, "ld_interpolation_secondary_logg_value", keyword_file);
	add_to_keyword_file ("METAL1:",     TYPE_DBL, PHOEBE_ld_interpolation, "ld_interpolation_primary_metallicity_value", keyword_file);
	add_to_keyword_file ("METAL2:",     TYPE_DBL, PHOEBE_ld_interpolation, "ld_interpolation_secondary_metallicity_value", keyword_file);

	/* **************************** FITTING TAB ******************************* */

	add_to_keyword_file ("N1_VAL:",     TYPE_INT, PHOEBE, "fitting_n1_value", keyword_file);
	add_to_keyword_file ("N2_VAL:",     TYPE_INT, PHOEBE, "fitting_n2_value", keyword_file);
	add_to_keyword_file ("N1L_VAL:",    TYPE_INT, PHOEBE, "fitting_n1l_value", keyword_file);
	add_to_keyword_file ("N2L_VAL:",    TYPE_INT, PHOEBE, "fitting_n2l_value", keyword_file);
	add_to_keyword_file ("XLAMDA_VAL:", TYPE_DBL, PHOEBE, "fitting_xlamda_value", keyword_file);
	add_to_keyword_file ("ISYM_ON:",    TYPE_BOO, PHOEBE, "fitting_isym_switch", keyword_file);

	/* ***************************** SPOTS TAB ******************************** */
	/* ******************************* DC TAB ********************************* */
	/* **************************** UTILITIES TAB ***************************** */

	fclose (keyword_file);
	}
	
void open_keyword_file (const char *filename)
	{
	char keyword_string[16];
	char *keyword_str = keyword_string;

	GtkWidget *readout_widget;

	int    readout_int;
	double readout_dbl;

	char working_string[255];
	char *working_str = working_string;

	int i;

	FILE *keyword_file;

	keyword_file = fopen (filename, "r");

	do
		{
		fscanf (keyword_file, "%15s", keyword_str);

		/* ***************************** DATA TAB ******************************* */

		if (strcmp (keyword_str, "NAME:") == 0)
			{
			for (i = 1; i <= 10; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			readout_widget = lookup_widget (PHOEBE, "data_star_name_entry");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "MODEL:") == 0)
			{
			for (i = 1; i <= 9; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			readout_widget = lookup_widget (PHOEBE, "data_model_list_entry");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "LCNO:" ) == 0) get_from_keyword_file (TYPE_INT, PHOEBE, "data_lc_no_value", keyword_file);
		if (strcmp (keyword_str, "RVNO:" ) == 0) get_from_keyword_file (TYPE_INT, PHOEBE, "data_rv_no_value", keyword_file);
		if (strcmp (keyword_str, "MNORM:") == 0) get_from_keyword_file (TYPE_DBL, PHOEBE, "data_zero_magnitude_value", keyword_file);

		if (strncmp (keyword_str, "LCCOL1", 6) == 0)
			{
			sscanf (keyword_str, "LCCOL1%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].column1, "%s", working_str);
			}

		if (strncmp (keyword_str, "LCCOL2", 6) == 0)
			{
			sscanf (keyword_str, "LCCOL2%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].column2, "%s", working_str);
			}

		if (strncmp (keyword_str, "LCCOL3", 6) == 0)
			{
			/* This entry may contain spaces and that's why we have to be careful:  */
			sscanf (keyword_str, "LCCOL3%d", &readout_int);
			for (i = 1; i <= 7; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].column3, "%s", working_str);
			}

		if (strncmp (keyword_str, "LCFN", 4) == 0)
			{
			sscanf (keyword_str, "LCFN%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].filename, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "LCSIG", 5) == 0)
			{
			sscanf (keyword_str, "LCSIG%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].sigma, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), readout_int-1, 2, working_str);
			}

		if (strncmp (keyword_str, "LCFLT", 5) == 0)
			{
			/* This entry may contain spaces and that's why we have to be careful:  */
			sscanf (keyword_str, "LCFLT%d", &readout_int);
			for (i = 1; i <= 8; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			sprintf (PHOEBE_lc_data[readout_int-1].filter, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_lc_info_list")), readout_int-1, 3, working_str);
			}

		if (strncmp (keyword_str, "RVCOL1", 6) == 0)
			{
			sscanf (keyword_str, "RVCOL1%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].column1, "%s", working_str);
			}

		if (strncmp (keyword_str, "RVCOL2", 6) == 0)
			{
			/* This entry may contain spaces and that's why we have to be careful:  */
			sscanf (keyword_str, "RVCOL2%d", &readout_int);
			for (i = 1; i <= 7; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].column2, "%s", working_str);
			}

		if (strncmp (keyword_str, "RVCOL3", 6) == 0)
			{
			sscanf (keyword_str, "RVCOL3%d", &readout_int);
			for (i = 1; i <= 7; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].column3, "%s", working_str);
			}

		if (strncmp (keyword_str, "RVFN", 4) == 0)
			{
			sscanf (keyword_str, "RVFN%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].filename, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "RVSIG", 5) == 0)
			{
			sscanf (keyword_str, "RVSIG%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].sigma, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), readout_int-1, 2, working_str);
			}

		if (strncmp (keyword_str, "RVFLT", 5) == 0)
			{
			sscanf (keyword_str, "RVFLT%d", &readout_int);
			for (i = 1; i <= 8; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			sprintf (PHOEBE_rv_data[readout_int-1].filter, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "data_rv_info_list")), readout_int-1, 3, working_str);
			}

		if (strcmp (keyword_str, "BINNING:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "data_binning_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "BINVAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "data_binning_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		/* **************************** BASIC TAB ******************************* */

		if (strcmp (keyword_str, "SMA:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_sma_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "SMA_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_sma_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "SMA_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_sma_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "SMA_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_sma_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "SMA_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_sma_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "RM:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_rm_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "RM_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_rm_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "RM_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_rm_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "RM_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_rm_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "RM_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_rm_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERIOD:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_period_value");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "PERIOD_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_period_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "PERIOD_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_period_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERIOD_MIN:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_period_value_min");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "PERIOD_MAX:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_period_value_max");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "HJD0:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_hjd0_value");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "HJD0_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_hjd0_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "HJD0_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_hjd0_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "HJD0_MIN:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_hjd0_value_min");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "HJD0_MAX:") == 0)
			{
			fscanf (keyword_file, "%s", working_str);
			readout_widget = lookup_widget (PHOEBE, "basic_hjd0_value_max");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "TAVH:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavh_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVH_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_tavh_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "TAVH_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavh_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVH_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavh_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVH_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavh_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVC:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavc_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVC_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_tavc_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "TAVC_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavc_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVC_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavc_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "TAVC_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_tavc_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "XINCL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_xincl_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "XINCL_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_xincl_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "XINCL_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_xincl_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "XINCL_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_xincl_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "XINCL_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_xincl_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "VGA:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_vga_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "VGA_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "basic_vga_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "VGA_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_vga_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "VGA_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_vga_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "VGA_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "basic_vga_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		/* *************************** ADVANCED TAB ***************************** */

		if (strcmp (keyword_str, "PHSV:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_phsv_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PHSV_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_phsv_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "PHSV_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_phsv_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PHSV_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_phsv_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PHSV_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_phsv_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PCSV:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_pcsv_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PCSV_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_pcsv_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "PCSV_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_pcsv_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PCSV_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_pcsv_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PCSV_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_pcsv_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR1_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr1_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "GR1_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr1_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR1_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr1_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR1_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr1_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR2_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr2_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "GR2_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr2_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR2_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr2_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "GR2_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_gr2_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB1_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb1_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "ALB1_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb1_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB1_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb1_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB1_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb1_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB2_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb2_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "ALB2_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb2_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB2_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb2_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ALB2_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_alb2_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F1_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_f1_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "F1_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f1_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F1_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f1_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F1_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f1_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F2_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "advanced_f2_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "F2_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f2_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F2_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f2_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "F2_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "advanced_f2_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		/* **************************** ORBIT TAB ******************************* */

		if (strcmp (keyword_str, "E:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_e_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "E_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "orbit_e_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "E_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_e_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "E_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_e_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "E_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_e_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERR0:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_perr0_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERR0_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "orbit_perr0_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "PERR0_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_perr0_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERR0_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_perr0_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PERR0_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_perr0_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPERDT:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dperdt_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPERDT_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "orbit_dperdt_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "DPERDT_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dperdt_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPERDT_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dperdt_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPERDT_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dperdt_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPDT:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dpdt_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPDT_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "orbit_dpdt_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "DPDT_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dpdt_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPDT_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dpdt_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "DPDT_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_dpdt_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PSHIFT:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_pshift_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PSHIFT_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "orbit_pshift_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "PSHIFT_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_pshift_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PSHIFT_MIN:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_pshift_value_min");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "PSHIFT_MAX:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "orbit_pshift_value_max");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		/* ************************* LUMINOSITIES TAB *************************** */

		if (strncmp (keyword_str, "HLALC", 5) == 0)
			{
			sscanf (keyword_str, "HLALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "CLALC", 5) == 0)
			{
			sscanf (keyword_str, "CLALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_lc_info_list")), readout_int-1, 2, working_str);
			}

		if (strncmp (keyword_str, "HLARV", 5) == 0)
			{
			sscanf (keyword_str, "HLARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "CLARV", 5) == 0)
			{
			sscanf (keyword_str, "CLARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_rv_info_list")), readout_int-1, 2, working_str);
			}

		if ( (strncmp (keyword_str, "EL3", 3) == 0) && (strcmp (keyword_str, "EL3_ADJ:") != 0) )
			{
			sscanf (keyword_str, "EL3%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_el3_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "WEIGHT", 5) == 0)
			{
			for (i = 1; i <= 7; i++) fgetc (keyword_file);
			sscanf (keyword_str, "WEIGHT%d", &readout_int);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "luminosities_weighting_info_list")), readout_int-1, 1, working_str);
			}

		if (strcmp (keyword_str, "HLA_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_hla_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "HLA_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "luminosities_hla_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "CLA_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "luminosities_cla_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "EL3_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_el3_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "IPB_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_ipb_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "IFAT1_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_ifat1_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "IFAT2_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_ifat2_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "NOISE_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "STDEV_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "luminosities_stdev_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "SEED_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_seed_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		/* *************************** SWITCHES TAB ***************************** */

		if (strcmp (keyword_str, "NREF_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_nref_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "NREF_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_nref_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		if (strcmp (keyword_str, "PHNORM_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_phnorm_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "THE_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "data_the_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "FACTOR_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_factor_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "MZERO_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_plot_lc, "plot_lc_mzero_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "VUNIT_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_plot_rv, "plot_rv_vunit_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ICOR1_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_icor1_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "ICOR2_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "luminosities_icor2_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		/* ****************************** LD TAB ******************************** */

		if (strcmp (keyword_str, "LD:") == 0)
			{
			for (i = 1; i <= 12; i++) fgetc (keyword_file);
			fgets (working_str, 255, keyword_file);
			strip_string_tail (working_str);
			readout_widget = lookup_widget (PHOEBE, "ld_ld_law_combo_box_entry");
			gtk_entry_set_text (GTK_ENTRY (readout_widget), working_str);
			}

		if (strcmp (keyword_str, "XBOL1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_xbol1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "YBOL1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_ybol1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "XBOL2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_xbol2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "YBOL2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_ybol2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "X1A_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "ld_x1a_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strcmp (keyword_str, "X2A_ADJ:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "ld_x2a_adjust");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}

		if (strncmp (keyword_str, "X1ALC", 5) == 0)
			{
			sscanf (keyword_str, "X1ALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "Y1ALC", 5) == 0)
			{
			sscanf (keyword_str, "Y1ALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), readout_int-1, 2, working_str);
			}

		if (strncmp (keyword_str, "X2ALC", 5) == 0)
			{
			sscanf (keyword_str, "X2ALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), readout_int-1, 3, working_str);
			}

		if (strncmp (keyword_str, "Y2ALC", 5) == 0)
			{
			sscanf (keyword_str, "Y2ALC%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_lc_info_list")), readout_int-1, 4, working_str);
			}

		if (strncmp (keyword_str, "X1ARV", 5) == 0)
			{
			sscanf (keyword_str, "X1ARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), readout_int-1, 1, working_str);
			}

		if (strncmp (keyword_str, "Y1ARV", 5) == 0)
			{
			sscanf (keyword_str, "Y1ARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), readout_int-1, 2, working_str);
			}

		if (strncmp (keyword_str, "X2ARV", 5) == 0)
			{
			sscanf (keyword_str, "X2ARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), readout_int-1, 3, working_str);
			}

		if (strncmp (keyword_str, "Y2ARV", 5) == 0)
			{
			sscanf (keyword_str, "Y2ARV%d", &readout_int);
			fscanf (keyword_file, "%s", working_str);
			gtk_clist_set_text (GTK_CLIST (lookup_widget (PHOEBE, "ld_monochromatic_rv_info_list")), readout_int-1, 4, working_str);
			}

		if (strcmp (keyword_str, "X1A_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_x1a_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "X2A_DEL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "ld_x2a_del_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "LOGG1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_primary_logg_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "LOGG2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_secondary_logg_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "METAL1:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_primary_metallicity_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "METAL2:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE_ld_interpolation, "ld_interpolation_primary_metallicity_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		/* *************************** FITTING TAB ****************************** */

		if (strcmp (keyword_str, "N1_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "fitting_n1_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		if (strcmp (keyword_str, "N2_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "fitting_n2_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		if (strcmp (keyword_str, "N1L_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "fitting_n1l_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		if (strcmp (keyword_str, "N2L_VAL:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "fitting_n2l_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_int);
			}

		if (strcmp (keyword_str, "XLAMDA_VAL:") == 0)
			{
			fscanf (keyword_file, "%lf", &readout_dbl);
			readout_widget = lookup_widget (PHOEBE, "fitting_xlamda_value");
			gtk_spin_button_set_value (GTK_SPIN_BUTTON (readout_widget), readout_dbl);
			}

		if (strcmp (keyword_str, "ISYM_ON:") == 0)
			{
			fscanf (keyword_file, "%d", &readout_int);
			readout_widget = lookup_widget (PHOEBE, "fitting_isym_switch");
			if (readout_int == 0) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), FALSE);
			if (readout_int == 1) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (readout_widget), TRUE);
			}
		}
	while (feof (keyword_file) == 0);

	fclose (keyword_file);
	}
