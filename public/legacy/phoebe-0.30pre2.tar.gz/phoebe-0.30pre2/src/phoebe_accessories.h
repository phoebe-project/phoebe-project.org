#ifndef PHOEBE_ACCESSORIES_H
	#define PHOEBE_ACCESSORIES_H 1

int   filename_exists                  (char *filename);
int   filename_has_write_permissions   (char *filename);
int   filename_has_read_permissions    (char *filename);
int   filename_has_execute_permissions (char *filename);
int   filename_has_full_permissions    (char *filename);
int   filename_is_directory            (char *filename);
int   filename_is_regular_file         (char *filename);
char *get_current_working_directory    ();
char *resolve_relative_filename        (char *filename);
int   list_directory_contents          (char *dir);
char *concatenate_strings              (const char *str, ...);

#endif
