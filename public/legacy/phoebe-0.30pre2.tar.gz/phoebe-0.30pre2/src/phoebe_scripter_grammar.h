#ifndef PHOEBE_SCRIPTER_CORE_H
	#define PHOEBE_SCRIPTER_CORE_H 1

#include "phoebe_global.h"

#endif
