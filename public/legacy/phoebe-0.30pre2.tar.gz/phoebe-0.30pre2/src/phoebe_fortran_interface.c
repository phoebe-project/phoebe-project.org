#include <stdlib.h>
#include <stdio.h>

#include "phoebe_global.h"

#include "phoebe_build_config.h"
#include "../include/cfortran.h"

#define OPENSTREAM(FN)                                          CCALLSFSUB1(OPENSTREAM,openstream,STRING,FN)
#define CLOSESTREAM()                                           CCALLSFSUB0(CLOSESTREAM,closestream)

#define CREATELCILINE1(a1,a2,a3,a4,a5,a6,a7,a8)                 CCALLSFSUB8(CREATELCILINE1,createlciline1,INT,INT,INT,INT,INT,INT,INT,INT,a1,a2,a3,a4,a5,a6,a7,a8)
#define CREATELCILINE2(b1,b2,b3,b4,b5,b6,b7,b8)                 CCALLSFSUB8(CREATELCILINE2,createlciline2,INT,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,INT,DOUBLE,b1,b2,b3,b4,b5,b6,b7,b8)
#define CREATELCILINE3(c1,c2,c3,c4,c5,c6,c7)                    CCALLSFSUB7(CREATELCILINE3,createlciline3,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,c1,c2,c3,c4,c5,c6,c7)
#define CREATELCILINE4(d1,d2,d3,d4,d5,d6,d7,d8,d9,d10)          CCALLSFSUB10(CREATELCILINE4,createlciline4,INT,INT,INT,INT,INT,INT,DOUBLE,DOUBLE,DOUBLE,DOUBLE,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10)
#define CREATELCILINE5(e1,e2,e3,e4,e5,e6,e7,e8,e9)              CCALLSFSUB9(CREATELCILINE5,createlciline5,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,e1,e2,e3,e4,e5,e6,e7,e8,e9)
#define CREATELCILINE6(f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11)      CCALLSFSUB11(CREATELCILINE6,createlciline6,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11)
#define CREATELCILINE7(g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12)  CCALLSFSUB12(CREATELCILINE7,createlciline7,INT,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,DOUBLE,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12)
#define CREATELCILINE8(h1,h2,h3,h4)                             CCALLSFSUB4(CREATELCILINE8,createlciline8,DOUBLE,DOUBLE,DOUBLE,DOUBLE,h1,h2,h3,h4)
#define CREATELCILINE10(j1,j2,j3,j4)                            CCALLSFSUB4(CREATELCILINE10,createlciline10,DOUBLE,DOUBLE,DOUBLE,DOUBLE,j1,j2,j3,j4)
#define CREATELCIENDLINE()                                      CCALLSFSUB0(CREATELCIENDLINE,createlciendline)

#define CREATESPOTSSTOPLINE()                                   CCALLSFSUB0(CREATESPOTSSTOPLINE,createspotsstopline)
#define CREATECLOUDSSTOPLINE()                                  CCALLSFSUB0(CREATECLOUDSSTOPLINE,createcloudsstopline)

int create_lci_file (char filename[], WD_LCI_parameters param)
	{
	int i;

	OPENSTREAM (filename);
	CREATELCILINE1  (param.MPAGE, param.NREF, param.MREF, param.IFSMV1, param.IFSMV2, param.ICOR1, param.ICOR2, param.LD);
	CREATELCILINE2  (param.JDPHS, param.HJD0, param.PERIOD, param.DPDT, param.PSHIFT, param.SIGMA, param.WEIGHTING, param.SEED);
	CREATELCILINE3  (param.HJDST, param.HJDSP, param.HJDIN, param.PHSTRT, param.PHSTOP, param.PHIN, param.PHNORM);
	CREATELCILINE4  (param.MODE, param.IPB, param.IFAT1, param.IFAT2, param.N1, param.N2, param.PERR0, param.DPERDT, param.THE, 100.0);
	CREATELCILINE5  (param.E, param.SMA, param.F1, param.F2, param.VGA/100., param.INCL, param.GR1, param.GR2, param.MET1);
	CREATELCILINE6  (param.TAVH/10000., param.TAVC/10000., param.ALB1, param.ALB2, param.PHSV, param.PCSV, param.RM, param.XBOL1, param.XBOL2, param.YBOL1, param.YBOL2);
	CREATELCILINE7  (param.IBAND, param.HLA, param.CLA, param.X1A, param.X2A, param.Y1A, param.Y2A, param.EL3, param.OPSF, 0.0, param.FACTOR, param.WLA/1000.);
	if (param.SPRIM != 0)
		for (i = 0; i < param.SPRIM; i++)
			CREATELCILINE8  (param.XLAT1[i], param.XLONG1[i], param.RADSP1[i], param.TEMSP1[i]);
	CREATESPOTSSTOPLINE ();
	if (param.SSEC != 0)
		for (i = 0; i < param.SSEC; i++)
			CREATELCILINE10 (param.XLAT2[i], param.XLONG2[i], param.RADSP2[i], param.TEMSP2[i]);
	CREATESPOTSSTOPLINE ();
	CREATECLOUDSSTOPLINE ();
	CREATELCIENDLINE ();
	CLOSESTREAM ();

	return 0;
	}
