#include <dirent.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

#include "phoebe_build_config.h"
#include "phoebe_error_handling.h"

int filename_exists (char *filename)
	{
	/* This function checks whether a file exists.                              */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0) return 1;
	else
		if (errno == ENOENT) return 0;
			else return -1;
	}

int filename_has_write_permissions (char *filename)
	{
	/* This function checks whether the supplied filename has write permissions */
	/* for the effective user ID.                                               */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if ( ( (log.st_uid == geteuid ()) && (log.st_mode & S_IWUSR) ) ||
			   ( (log.st_gid == getegid ()) && (log.st_mode & S_IWGRP) ) ||
			   ( (log.st_mode & S_IWOTH) ) )
			return 1; else return 0;
		}
	else return -1;
	}

int filename_has_read_permissions (char *filename)
	{
	/* This function checks whether the supplied filename has read permissions  */
	/* for the effective user ID.                                               */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if ( ( (log.st_uid == geteuid ()) && (log.st_mode & S_IRUSR) ) ||
			   ( (log.st_gid == getegid ()) && (log.st_mode & S_IRGRP) ) ||
			   ( (log.st_mode & S_IROTH) ) )
			return 1; else return 0;
		}
	else return -1;
	}

int filename_has_execute_permissions (char *filename)
	{
	/* This function checks whether the supplied filename has execute permissi- */
	/* ons for the effective user ID.                                           */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if ( ( (log.st_uid == geteuid ()) && (log.st_mode & S_IXUSR) ) ||
			   ( (log.st_gid == getegid ()) && (log.st_mode & S_IXGRP) ) ||
			   ( (log.st_mode & S_IXOTH) ) )
			return 1; else return 0;
		}
	else return -1;
	}

int filename_has_full_permissions (char *filename)
	{
	/* This function checks whether the supplied filename has full permissions  */
	/* for the effective user ID.                                               */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if ( ( (log.st_uid == geteuid ()) && (log.st_mode & S_IRUSR) && (log.st_mode & S_IWUSR) && (log.st_mode & S_IXUSR) ) ||
			   ( (log.st_gid == getegid ()) && (log.st_mode & S_IRGRP) && (log.st_mode & S_IWGRP) && (log.st_mode & S_IXGRP) ) ||
			   ( (log.st_mode & S_IROTH) && (log.st_mode & S_IWOTH) && (log.st_mode & S_IXOTH) ) )
			return 1; else return 0;
		}
	else return -1;
	}

int filename_is_directory (char *filename)
	{
	/* This function checks whether the supplied filename is a directory.       */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if (S_ISDIR (log.st_mode)) return 1; else return 0;
		}
	else return -1;
	}

int filename_is_regular_file (char *filename)
	{
	/* This function checks whether the supplied filename is a regular file.    */

	struct stat log;
	int check;

	if (filename == NULL) return -1;

	check = stat (filename, &log);
	if (check == 0)
		{
		if (S_ISREG (log.st_mode)) return 1; else return 0;
		}
	else return -1;
	}

char *get_current_working_directory ()
	{
	/* This function gets the current working directory that is used to resolve */
	/* relative filenames. It allocates space itself, the user has to free it.  */

	size_t size = 100;

	while (1)
		{
		char *buffer = phoebe_malloc (size);
		if (getcwd (buffer, size) == buffer)
			return buffer;
		free (buffer);
		if (errno != ERANGE)
			return 0;
		size *= 2;
		}
	}

char *resolve_relative_filename (char *filename)
	{
	/* This function takes a relative filename and resolves it to absolute; it  */
	/* allocates the memory for the string itself, the user has to free it.     */

	char *cwd;
	char *abs;

	/* Is the filename already absolute?                                        */
	if (filename[0] == '/') return filename;

	cwd = get_current_working_directory ();
	abs = phoebe_malloc (strlen (cwd) + strlen (filename) + 2); /* for / and \0 */
	sprintf (abs, "%s/%s", cwd, filename);
	free (cwd);

	return abs;
	}

int list_directory_contents (char *dir)
	{
	DIR *directory;
	struct dirent *direntry;
	
	directory = opendir (dir);
	if (directory != NULL)
		{
		while (direntry = readdir (directory))
			puts (direntry->d_name);
		closedir (directory);
		}
	else
		printf ("Error reading current directory contents.\n");
	}

char *concatenate_strings (const char *str, ...)
	{
	va_list args;
	char *out = malloc (strlen(str)+1);
	char *s;
	char *change;

	strcpy (out, str);

	va_start (args, str);
	while ( (s = va_arg (args, char *)) != NULL )
		{
		out = phoebe_realloc (out, strlen (out) + strlen (s) + 1);
		change = &out[strlen(out)];
		strcpy (change, s);
		}

	va_end (args);
	return out;
	}
