#ifndef BISON_PHOEBE_SCRIPTER_GRAMMAR_TAB_H
# define BISON_PHOEBE_SCRIPTER_GRAMMAR_TAB_H

#ifndef YYSTYPE
typedef union
  {
  bool                      swc;	/* Switch                                 */
  int                       idx;	/* Index                                  */
  double                    val;	/* Double-precision value                 */
  char                     *str;	/* String (literal or a variable)         */
  struct scripter_ast      *ast;	/* Abstract Syntax Tree leaf              */
  struct scripter_ast_list *lst;	/* AST arguments list                     */
  } yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	INTEGER	257
# define	BOOLEAN	258
# define	VALUE	259
# define	IDENT	260
# define	LITERAL	261
# define	FUNCTION	262
# define	SYSTEM_CALL	263
# define	COMMAND	264
# define	HELP	265
# define	CALC	266
# define	SET	267
# define	DEFINE	268
# define	IF	269
# define	ELSE	270
# define	PRINT	271
# define	QUIT	272
# define	WHILE	273
# define	FOR	274
# define	START_BLOCK	275
# define	END_BLOCK	276
# define	OPEN_KEYWORD_FILE	277
# define	SAVE_KEYWORD_FILE	278
# define	SET_PARAMETER_VALUE	279
# define	GET_PARAMETER_VALUE	280
# define	COMPUTE_LC	281
# define	COMPUTE_RV	282
# define	CREATE_WD_LCI_FILE	283
# define	MINIMIZE_USING_SIMPLEX	284
# define	EQ	285
# define	NEQ	286
# define	LEQ	287
# define	LE	288
# define	GEQ	289
# define	GR	290
# define	INC	291
# define	DEC	292
# define	INCBY	293
# define	DECBY	294
# define	MULTBY	295
# define	DIVBY	296
# define	AND	297
# define	OR	298
# define	NEG	299


extern YYSTYPE yylval;

#endif /* not BISON_PHOEBE_SCRIPTER_GRAMMAR_TAB_H */
