#ifndef PHOEBE_CONNECTIVITY_H
	#define PHOEBE_CONNECTIVITY_H 1

void emit_parameter_changed_signal_for_plugins (char *qualifier, int index);

#endif
