#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <math.h>

#include "phoebe_build_config.h"

#include "phoebe_accessories.h"
#include "phoebe_allocations.h"
#include "phoebe_base.h"
#include "phoebe_calculations.h"
#include "phoebe_error_handling.h"
#include "phoebe_fortran_interface.h"
#include "phoebe_global.h"
#include "phoebe_keywords.h"

int initialize_memory_for_data (PHOEBE_data *data)
	{
	/* This function sets all data pointers of the data to NULL so that the     */
	/* following allocation function may safely call realloc for these pointers.*/

	data->indep  = NULL;
	data->dep    = NULL;
	data->weight = NULL;
	data->ptsno  = 0;
	
	return 0;
	}

int allocate_memory_for_data (PHOEBE_data *data, int records_no)
	{
	/* This function allocates memory to all three entries of the PHOEBE_data   */
	/* structure: indep, dep and weight. It reads the number of points from the */
	/* given variable records_no. By calling this function with records_no = 0, */
	/* the pointers of the data container will not be modified.                 */

	if (records_no == 0)
		{
		phoebe_warning ("allocate_memory_from_data () called with 0 points!\n");
		return -1;
		}

	data->indep  = realloc (data->indep,  records_no * sizeof (*data->indep));
	data->dep    = realloc (data->dep,    records_no * sizeof (*data->dep));
	data->weight = realloc (data->weight, records_no * sizeof (*data->weight));
	data->ptsno  = records_no;

	return 0;
	}

int free_allocated_memory_for_data (PHOEBE_data *data)
	{
	/* This function frees the memory allocated by allocate_memory_for_data ()  */
	/* and sets all pointers to NULL.                                           */

	if (data->indep != NULL)  free (data->indep);
	if (data->dep != NULL)    free (data->dep);
	if (data->weight != NULL) free (data->weight);

	data->indep = NULL; data->dep = NULL; data->weight = NULL;

	return 0;
	}

int read_in_synthetic_data (PHOEBE_data *data, int curve, int indep, int dep, int weight, double phstrt, double phend, int vertices)
	{
	/* This function forms the WD input file 'lcin.active' and calls LC to cal- */
	/* culate the data. What is being calculated is determined by indep and     */
	/* dep switches.                                                            */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the requested curve isn't initialized                          */
	/*    0  ..  everything ok, readin successful                               */

	int i;
	int mpage, jdphs;
	int errno;

	char *filename = resolve_relative_filename ("lcin.active");
	WD_LCI_parameters params;

	allocate_memory_for_data (data, vertices);
	
	if ( indep == OUTPUT_HJD          ) jdphs = 1; else jdphs = 2;
	if (   dep == OUTPUT_TOTAL_FLUX   ) mpage = 1;
	if (   dep == OUTPUT_MAGNITUDE    ) mpage = 1;
	if (   dep == OUTPUT_PRIMARY_RV   ) mpage = 2;
	if (   dep == OUTPUT_SECONDARY_RV ) mpage = 2;

	errno = read_in_wd_lci_parameters (&params, mpage, jdphs, curve);
	if (errno == -2) return -2;

	create_lci_file (filename, params);

	switch (dep)
		{
		case OUTPUT_MAGNITUDE:
			call_wd_to_get_fluxes (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		case OUTPUT_PRIMARY_FLUX:
			call_wd_to_get_fluxes (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		case OUTPUT_SECONDARY_FLUX:
			call_wd_to_get_fluxes (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		case OUTPUT_TOTAL_FLUX:
			call_wd_to_get_fluxes (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		case OUTPUT_PRIMARY_RV:
			call_wd_to_get_rv1    (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		case OUTPUT_SECONDARY_RV:
			call_wd_to_get_rv2    (phstrt, phend, (phend-phstrt)/vertices, data);
		break;
		}

	remove (filename);
	free (filename);

	for (i = 0; i < vertices; i++)
		{
		data->indep[i] = phstrt + i * (phend - phstrt) / vertices;
		data->weight[i] = 0.0;
		}

	if ( dep == OUTPUT_MAGNITUDE )
		{
		double mnorm;
		phoebe_get_parameter_value ("phoebe_mnorm_value", &mnorm);
		transform_flux_to_magnitude (data, mnorm);
		}

	if ( dep == OUTPUT_PRIMARY_RV || dep == OUTPUT_SECONDARY_RV )
		{
		for (i = 0; i < vertices; i++)
			data->dep[i] *= 100.0;
		}

	return data->ptsno;
	}

char *parse_data_line (char *in)
	{
	/* This function takes a string, parses it (cleans it of all comment deli-  */
	/* meters, spaces, tabs and newlines), copies the contents to the newly al- */
	/* located string. The original string isn't modified (passed by value!).   */

	char *value = NULL;

	/* If the line contains the comment delimeter '#', discard everything that  */
	/* follows it (strip the input line):                                       */
	if (strchr (in, '#') != NULL)
		in[strlen(in)-strlen(strchr(in,'#'))] = '\0';

	/* If we have spaces, tabs or newlines in front of the first character in   */
	/* line, remove them by incrementing the pointer by 1:                      */
	while ( (*in ==  ' ') || (*in == '\t') || (*in == '\n') )
		if (strlen (in) != 1) in++;
			else { *in = '\0'; break; }

	/* Let's do the same for the tail of the string:                            */
	while ( (in[strlen(in)-1] ==  ' ') || (in[strlen(in)-1] == '\t') || (in[strlen(in)-1] == '\n') ) in[strlen(in)-1] = '\0';

	if (strlen (in) != 0) value = strdup (in);

	/* If we removed everything, the line is empty and we return NULL.          */
	return value;
	}

int read_in_experimental_data (char *filename, PHOEBE_data *data, int indep, int outindep, int dep, int outdep, int weight, int outweight)
	{
	/* This function should be called *EXCLUSIVELY* by PHOEBE_INPUT_* and       */
	/* PHOEBE_OUTPUT_* enumerate types. "int" in the prototype is used to allow */
	/* certain calls to pass -1 rather than the enumerate type, which means     */
	/* that no potential conversion should be made to that variable. A typical  */
	/* example is updating the statistics window. This function should only     */
	/* read out the values and it shouldn't make any conversions to the data.   */

	FILE *file;
	int i = 0;

	char temp_string[255];
	char *temp_str = temp_string;

	char *in;

	int no_of_columns;

	double hjd0, period, dpdt, pshift;

	/* First step: check whether the user wants to plot something that doesn't  */
	/* make sense:                                                              */
	if ( (dep == INPUT_MAGNITUDE) && (outdep == OUTPUT_PRIMARY_FLUX) )
		{
		phoebe_warning ("read_in_experimental_data () called with OUTPUT_PRIMARY_FLUX.\n\tIt is not possible to extract primary flux contributions from data!\n");
		return 1;
		}

	if ( (dep == INPUT_MAGNITUDE) && (outdep == OUTPUT_SECONDARY_FLUX) )
		{
		phoebe_warning ("read_in_experimental_data () called with OUTPUT_SECONDARY_FLUX.\n\tIt is not possible to extract secondary flux contributions from data!\n");
		return 1;
		}

	if ( (indep == INPUT_PHASE) && (outindep == OUTPUT_HJD) )
		phoebe_warning ("read_in_experimental_data () called with PHASE -> HJD transformation\n\trequest. This isn't possible, leaving data intact.");

	/* Check for the filename validity:                                         */

	if ( (!filename_exists (filename)) || 
			 (!filename_is_regular_file (filename)) )
		{
		phoebe_warning ("read_in_experimental_data () notice: filename not valid!\n");
		return -1;
		}

	/* Just to be sure, we check the fopen statement against NULL:              */
	if ( (file = fopen (filename, "r")) == NULL )
		{
		phoebe_warning ("read_in_experimental_data () notice: file opening failed!");
		return -1;
		}

	while (!feof (file))
		{
		fgets (temp_str, 255, file);

		/* If the line is commented or empty, skip it:                            */
		if ( (in = parse_data_line (temp_str)) == NULL ) continue;

		/* Check how many columns are expected in the input file:                 */
		if (weight == INPUT_UNAVAILABLE) no_of_columns = 2; else no_of_columns = 3;

		allocate_memory_for_data (data, i+1);

		if (no_of_columns == 2)
			{
			if (sscanf (in, "%lf %lf", &data->indep[i], &data->dep[i]) != 2)
				phoebe_warning ("read_in_experimental_data () notice: line discarded!\n");
			data->weight[i] = 1.0;
			}

		if (no_of_columns == 3)
			if (sscanf (in, "%lf %lf %lf", &data->indep[i], &data->dep[i], &data->weight[i]) != 3)
				phoebe_warning ("read_in_experimental_data () notice: line discarded!\n");
		
		i++;
		}
	fclose (file);
	data->ptsno = i-1;

	/* Now we do all the necessary transformations:                             */

	if ( (indep == INPUT_HJD) && (outindep == OUTPUT_PHASE) )
		{
		read_in_ephemeris_parameters (&hjd0, &period, &dpdt, &pshift);
		transform_hjd_to_phase (data, hjd0, period, dpdt, pshift);
		}

	if ( (dep == INPUT_MAGNITUDE) && (outdep == OUTPUT_TOTAL_FLUX) )
		transform_magnitude_to_flux (data, phoebe_get_value_double ("phoebe_mnorm_value"));

	if ( (dep == INPUT_FLUX) && (outdep == OUTPUT_MAGNITUDE) )
		transform_flux_to_magnitude (data, phoebe_get_value_double ("phoebe_mnorm_value"));

	return data->ptsno;
	}

int read_in_wd_lci_parameters (WD_LCI_parameters *params, int MPAGE, int JDPHS, int curve)
	{
	/* This function reads out all variables that build up the LCI file.        */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the passed curve number refers to non-existent curve           */
	/*    0  ..  everything ok                                                  */
	/*    1  ..  the passed mpage isn't (yet) supported                         */

	int lcno = phoebe_get_value_int ("phoebe_lcno_value");
	int rvno = phoebe_get_value_int ("phoebe_rvno_value");

	char *filter = NULL;

	/* This switch determines which operation should the program do and it is   */
	/* set from the passed value:                                               */
	params->MPAGE = MPAGE;

	/* First let's check whether we have out-of-bounds situation:               */
	if (MPAGE == 1)
		if (curve < 0 || curve > lcno-1) return -2;
	if (MPAGE == 2)
		if (curve < 0 || curve > rvno-1) return -2;
	if (MPAGE != 1 && MPAGE != 2) return 1;

	if (phoebe_get_value_bool ("phoebe_reflection_switch") == YES) params->MREF = 2; else params->MREF = 1;
	params->NREF = phoebe_get_value_int ("phoebe_reflection_value");

	if (phoebe_get_value_bool ("phoebe_ifsmv1_switch") == YES) params->IFSMV1 = 1; else params->IFSMV1 = 0;
	if (phoebe_get_value_bool ("phoebe_ifsmv2_switch") == YES) params->IFSMV2 = 1; else params->IFSMV2 = 0;
	if (phoebe_get_value_bool ("phoebe_rv1proximity_switch") == YES) params->ICOR1  = 1; else params->ICOR1  = 0;
	if (phoebe_get_value_bool ("phoebe_rv2proximity_switch") == YES) params->ICOR2  = 1; else params->ICOR2  = 0;

	if (strcmp (phoebe_get_value_string ("phoebe_ldmodel_value"), "Linear cosine law") == 0) params->LD = 1;
	if (strcmp (phoebe_get_value_string ("phoebe_ldmodel_value"), "Logarithmic law")   == 0) params->LD = 2;
	if (strcmp (phoebe_get_value_string ("phoebe_ldmodel_value"), "Square root law")   == 0) params->LD = 3;

	/* This switch determines if the independent variable is phase or HJD; it   */
	/* must be passed, since we don't know which is the calling function.       */
	params->JDPHS = JDPHS;

	params->HJD0   = phoebe_get_value_double ("phoebe_hjd0_value");
	params->PERIOD = phoebe_get_value_double ("phoebe_period_value");
	params->DPDT   = phoebe_get_value_double ("phoebe_dpdt_value");
	params->PSHIFT = phoebe_get_value_double ("phoebe_pshift_value");

	/* If the user wants to add synthetic Gaussian noise, the following values  */
	/* should be different from 0:                                              */
	if (phoebe_get_value_bool ("phoebe_scatter_switch") == YES)
		{
		params->SIGMA  = phoebe_get_value_double ("phoebe_scatter_sigma");
		if (strcmp (phoebe_get_value_string ("phoebe_scatter_weighting"), "No level-dependent weighting") == 0) params->WEIGHTING = 0;
		if (strcmp (phoebe_get_value_string ("phoebe_scatter_weighting"), "Poissonian scatter")           == 0) params->WEIGHTING = 1;
		if (strcmp (phoebe_get_value_string ("phoebe_scatter_weighting"), "Low light scatter")            == 0) params->WEIGHTING = 2;
		params->SEED   = phoebe_get_value_double ("phoebe_scatter_seed");
		}
	else
		{
		params->SIGMA = 0.0; params->WEIGHTING = 0; params->SEED = 0.0;
		}

	/* The following parameters are dummies, since PHOEBE calls WD algorithm    */
	/* for each phase individually:                                             */
	params->HJDST  = 0.0;
	params->HJDSP  = 1.0;
	params->HJDIN  = 0.1;
	params->PHSTRT = 0.0;
	params->PHSTOP = 1.0;
	params->PHIN   = 0.1;

	/* Normalizing magnitude (PHNORM) tells WD at what phase the normalized     */
	/* flux should be 1. Usually this is 0.25, but could in general be at some  */
	/* other phase. Since there is no support for that in PHOEBE yet, it is     */
	/* hardcoded to 0.25, but it should be changed.                             */
	params->PHNORM = 0.25;

	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "X-ray binary"                                         ) == 0) params->MODE = -1;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "General binary system (no constraints)"               ) == 0) params->MODE =  0;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Overcontact binary of the W UMa type"                 ) == 0) params->MODE =  1;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Detached binary"                                      ) == 0) params->MODE =  2;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Overcontact binary not in thermal contact"            ) == 0) params->MODE =  3;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Semi-detached binary, primary star fills Roche lobe"  ) == 0) params->MODE =  4;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Semi-detached binary, secondary star fills Roche lobe") == 0) params->MODE =  5;
	if (strcmp (phoebe_get_value_string ("phoebe_model_value"), "Double contact binary"                                ) == 0) params->MODE =  6;

	if (phoebe_get_value_bool ("phoebe_decouplecla_switch") == YES) params->IPB  = 1; else params->IPB  = 0;
	if (phoebe_get_value_bool ("phoebe_atm1_switch")        == YES) params->IFAT1 = 1; else params->IFAT1 = 0;
	if (phoebe_get_value_bool ("phoebe_atm2_switch")        == YES) params->IFAT2 = 1; else params->IFAT2 = 0;

	params->N1 = phoebe_get_value_int ("phoebe_n1f_value");
	params->N2 = phoebe_get_value_int ("phoebe_n2f_value");

	params->PERR0  = phoebe_get_value_double ("phoebe_perr0_value");
	params->DPERDT = phoebe_get_value_double ("phoebe_dperdt_value");

	/* THE applies only to X-ray binaries, but it isn't supported yet.          */
	params->THE    = 0.0;

	/* VUNIT is the internal radial velocity unit. This should be calculated    */
	/* rather than determined by the user, however it isn't written yet. It is  */
	/* thus hardcoded to the most obvious number, that is 100 km/s.             */
	params->VUNIT  = 100.0;

	params->E      = phoebe_get_value_double ("phoebe_ecc_value");
	params->SMA    = phoebe_get_value_double ("phoebe_sma_value");
	params->F1     = phoebe_get_value_double ("phoebe_f1_value");
	params->F2     = phoebe_get_value_double ("phoebe_f2_value");
	params->VGA    = phoebe_get_value_double ("phoebe_vga_value");
	params->INCL   = phoebe_get_value_double ("phoebe_incl_value");
	params->GR1    = phoebe_get_value_double ("phoebe_gr1_value");
	params->GR2    = phoebe_get_value_double ("phoebe_gr2_value");
	params->LOGG1  = phoebe_get_value_double ("phoebe_logg1_value");
	params->LOGG2  = phoebe_get_value_double ("phoebe_logg2_value");
	params->MET1   = phoebe_get_value_double ("phoebe_met1_value");
	params->MET2   = phoebe_get_value_double ("phoebe_met2_value");
	params->TAVH   = phoebe_get_value_double ("phoebe_tavh_value");
	params->TAVC   = phoebe_get_value_double ("phoebe_tavc_value");
	params->ALB1   = phoebe_get_value_double ("phoebe_alb1_value");
	params->ALB2   = phoebe_get_value_double ("phoebe_alb2_value");
	params->PHSV   = phoebe_get_value_double ("phoebe_phsv_value");
	params->PCSV   = phoebe_get_value_double ("phoebe_pcsv_value");
	params->RM     = phoebe_get_value_double ("phoebe_rm_value");
	params->XBOL1  = phoebe_get_value_double ("phoebe_xbol1_value");
	params->XBOL2  = phoebe_get_value_double ("phoebe_xbol2_value");
	params->YBOL1  = phoebe_get_value_double ("phoebe_ybol1_value");
	params->YBOL2  = phoebe_get_value_double ("phoebe_ybol2_value");

	if (MPAGE == 2)
		filter = strdup (phoebe_get_value_list_string ("phoebe_rv_filter", curve));
	else
		filter = strdup (phoebe_get_value_list_string ("phoebe_lc_filter", curve));

	params->IBAND = 0;
	if (strncmp (filter, "350nm (u)", 9) == 0)    params->IBAND = 1;
	if (strncmp (filter, "411nm (v)", 9) == 0)    params->IBAND = 2;
	if (strncmp (filter, "467nm (b)", 9) == 0)    params->IBAND = 3;
	if (strncmp (filter, "547nm (y)", 9) == 0)    params->IBAND = 4;
	if (strncmp (filter, "360nm (U)", 9) == 0)    params->IBAND = 5;
	if (strncmp (filter, "440nm (B)", 9) == 0)    params->IBAND = 6;
	if (strncmp (filter, "550nm (V)", 9) == 0)    params->IBAND = 7;
	if (strncmp (filter, "700nm (R)", 9) == 0)    params->IBAND = 8;
	if (strncmp (filter, "900nm (I)", 9) == 0)    params->IBAND = 9;
	if (strncmp (filter, "1250nm (J)", 10) == 0)  params->IBAND = 10;
	if (strncmp (filter, "2200nm (K)", 10) == 0)  params->IBAND = 11;
	if (strncmp (filter, "3400nm (L)", 10) == 0)  params->IBAND = 12;
	if (strncmp (filter, "5000nm (M)", 10) == 0)  params->IBAND = 13;
	if (strncmp (filter, "10200nm (N)", 11) == 0) params->IBAND = 14;
	if (strncmp (filter, "647nm (Rc)", 10) == 0)  params->IBAND = 15;
	if (strncmp (filter, "786nm (Ic)", 10) == 0)  params->IBAND = 16;
	if (strncmp (filter, "419nm (Bt)", 10) == 0)  params->IBAND = 23;
	if (strncmp (filter, "523nm (Vt)", 10) == 0)  params->IBAND = 24;
	if (strncmp (filter, "505nm (Hp)", 10) == 0)  params->IBAND = 25;
	if (strncmp (filter, "861nm (RVIJ)", 12) == 0)
		{
		phoebe_warning ("861nm filter not supported by WD2003, Johnson I adopted.\n");
		params->IBAND = 9;
		}
	if (params->IBAND == 0)
		{
		phoebe_warning ("IBAND assignment failed. Johnson V filter (550nm) assumed.\n");
		params->IBAND = 7;
		}

	params->HLA = phoebe_get_value_list_double ("phoebe_hla_value", curve);
	params->CLA = phoebe_get_value_list_double ("phoebe_cla_value", curve);

	if (MPAGE == 2)
		{
		filter = strdup (phoebe_get_value_list_string ("phoebe_rv_filter", curve));
		params->X1A   = phoebe_get_value_list_double ("phoebe_rvx1_value", curve);
		params->X2A   = phoebe_get_value_list_double ("phoebe_rvx2_value", curve);
		params->Y1A   = phoebe_get_value_list_double ("phoebe_rvy1_value", curve);
		params->Y2A   = phoebe_get_value_list_double ("phoebe_rvy2_value", curve);
		}
	else
		{
		filter = strdup (phoebe_get_value_list_string ("phoebe_lc_filter", curve));
		params->X1A   = phoebe_get_value_list_double ("phoebe_lcx1_value", curve);
		params->X2A   = phoebe_get_value_list_double ("phoebe_lcx2_value", curve);
		params->Y1A   = phoebe_get_value_list_double ("phoebe_lcy1_value", curve);
		params->Y2A   = phoebe_get_value_list_double ("phoebe_lcy2_value", curve);
		}

	params->EL3   = phoebe_get_value_list_double ("phoebe_el3_value", curve);
	params->OPSF  = phoebe_get_value_list_double ("phoebe_opsf_value", curve);

	/* MZERO and FACTOR variables set offsets in synthetic light curves. PHOEBE */
	/* controls this by its own variables, so we hardcode these to 0 and 1.     */
	params->MZERO  = 0.0;
	params->FACTOR = 1.0;
	sscanf (filter, "%lf%*s", &(params->WLA));

	/* Spots are not supported yet:                                             */
	params->SPRIM = 0;
	params->SSEC  = 0;
	params->XLAT1  = &(params->THE);
	params->XLONG1 = &(params->THE);
	params->RADSP1 = &(params->THE);
	params->TEMSP1 = &(params->THE);
	params->XLAT2  = &(params->THE);
	params->XLONG2 = &(params->THE);
	params->RADSP2 = &(params->THE);
	params->TEMSP2 = &(params->THE);

	return 0;
	}

int read_in_ephemeris_parameters (double *hjd0, double *period, double *dpdt, double *pshift)
	{
	/* This function speeds up the ephemeris readout:                           */

	*hjd0   = phoebe_get_value_double ("phoebe_hjd0_value");
	*period = phoebe_get_value_double ("phoebe_period_value");
	*dpdt   = phoebe_get_value_double ("phoebe_dpdt_value");
	*pshift = phoebe_get_value_double ("phoebe_pshift_value");

	return 0;
	}

int read_in_lc_plot_parameters (PHOEBE_lc_plot_parameters *params)
	{
	/* This function reads in LC plot parameters:                               */
	/*                                                                          */
	/*   1) .alias         ...    is data aliased outside [-0.5, 0.5] interval  */
	/*   2) .bin           ...    is data binned                                */
	/*   3) .deredden      ...    should data be dereddened                     */
	/*   4) .synthderedden ...    should synthetic LC data be dereddened        */
	/*   5) .residuals     ...    are residuals plotted instead of overplots    */
	/*   6) .*synthetic    ...    on/off switches for synthetic curves (array)  */
	/*   7) .*experimental ...    on/off switches for experimental curves (ar.) */
	/*   8) .*shift        ...    relative LC plot shifts (array of doubles)    */
	/*   9) .*filter       ...    LC filters (array of doubles)                 */
	/*  10) .indep         ...    requested independent plot variable           */
	/*  11) .dep           ...    requested dependent plot variable             */
	/*  12) .weight        ...    requested error-bar handling (not implement.) */
	/*  13) .phstrt        ...    phase start                                   */
	/*  14) .phend         ...    phase end                                     */
	/*  15) .vertices      ...    number of synthetic LC plot vertices          */

	int i;
	int lcno = phoebe_get_value_int ("phoebe_lcno_value");
	char *filter = NULL;

	params->indep          = get_output_independent_variable ((char *) phoebe_get_value_string ("phoebe_lc_indep_variable"));
	params->dep            = get_output_dependent_variable   ((char *) phoebe_get_value_string ("phoebe_lc_dep_variable"));
	params->weight         = OUTPUT_UNAVAILABLE;
	params->phstart        = phoebe_get_value_double ("phoebe_lc_phase_start");
	params->phend          = phoebe_get_value_double ("phoebe_lc_phase_end");
	params->vertices       = phoebe_get_value_int ("phoebe_lc_vertices_value");
	params->alias          = phoebe_get_value_bool ("phoebe_lc_alias_switch");
	params->residuals      = phoebe_get_value_bool ("phoebe_lc_residuals_switch");
	params->bin            = phoebe_get_value_bool ("phoebe_binning_switch");
	params->deredden       = phoebe_get_value_bool ("phoebe_reddening_switch");
	params->synthderedden  = phoebe_get_value_bool ("phoebe_synthred_switch");
	params->synthetic      = phoebe_malloc (lcno * sizeof (bool));
	for (i = 0; i < lcno; i++)
		params->synthetic[i] = phoebe_get_value_list_bool ("phoebe_plot_lc_column_2", i);
	params->experimental   = phoebe_malloc (lcno * sizeof (bool));
	for (i = 0; i < lcno; i++)
		params->experimental[i] = phoebe_get_value_list_bool ("phoebe_plot_lc_column_3", i);
	params->shift          = phoebe_malloc (lcno * sizeof (double));
	for (i = 0; i < lcno; i++)
		params->shift[i]     = phoebe_get_value_list_double ("phoebe_plot_lc_shift", i);
	params->filter         = phoebe_malloc (lcno * sizeof (double));
	for (i = 0; i < lcno; i++)
		{
		phoebe_get_parameter_value ("phoebe_lc_filter", i, &filter);
		sscanf (filter, "%lf%*s", &(params->filter[i]));
		phoebe_debug ("lambda reported by read_in_lc_plot_parameters: %lf\n", params->filter[i]);
		}
	}

int read_in_adjustable_parameters (bool **switches, double **steps, double **values, int **indices, int *to_be_adjusted)
	{
	/* This function cross-checks the global parameter table for all adjustable */
	/* parameters, queries the adjustment switch state, step size and the ini-  */
	/* tial parameter value; it then fills in the values to the list variable.  */
	/* The memory is allocated in this call and it is up to the user to free it */
	/* after using it. It returns the number of adjustable parameters.          */
	
	int i, j, k;
	int lcno = phoebe_get_value_int ("phoebe_lcno_value");

	/* Internal prefix variable to help access same-wise parameter elements:    */
	char prefix_string[255];
	char *prefix = prefix_string;
	char qualifier_string[255];
	char *qualifier = qualifier_string;

	int multi;

	*switches = NULL;
	*steps = NULL;
	*values = NULL;
	*indices = NULL;
	*to_be_adjusted = 0;

	j = 0;
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if (strstr (PHOEBE_parameters[i].qualifier, "_adjust") != NULL)
			{
			prefix = strncpy (prefix, PHOEBE_parameters[i].qualifier, strlen (PHOEBE_parameters[i].qualifier) - strlen ("_adjust"));
			prefix[strlen (PHOEBE_parameters[i].qualifier) - strlen ("_adjust")] = '\0';

			/* First we have to see whether it's a system parameter (one for all    */
			/* light curves) or is it a filter-dependent parameter (one for each    */
			/* light curve):                                                        */
			sprintf (qualifier, "%s_value", prefix);
			if (phoebe_type_from_qualifier (qualifier) == TYPE_DOUBLE)
				{
				j++;
				multi = 0;
				}
			if (phoebe_type_from_qualifier (qualifier) == TYPE_DOUBLE_ARRAY)
				{
				j += lcno;
				multi = 1;
				}

			/* Next, we (re)allocate memory:                                        */
			*switches = phoebe_realloc (*switches, j * sizeof (**switches));
			*steps    = phoebe_realloc (*steps,    j * sizeof (**steps));
			*values   = phoebe_realloc (*values,   j * sizeof (**values));
			*indices  = phoebe_realloc (*indices,  j * sizeof (**indices));

			/* Finally, we fill in all values: if multi = 0, then only (j-1). field */
			/* is updated, otherwise all filter-dependent fields are updated:       */
			for (k = j - (multi * (lcno-1)) - 1; k < j; k++)
				{
				(*indices)[k] = i;
				phoebe_get_parameter_value (PHOEBE_parameters[i].qualifier, &(*switches)[k]);
				if ((*switches)[k] == YES) (*to_be_adjusted)++;

				sprintf (qualifier, "%s_step", prefix);
				(*steps)[k] = phoebe_get_value_double (qualifier);

				sprintf (qualifier, "%s_value", prefix);
				if (phoebe_type_from_qualifier (qualifier) == TYPE_DOUBLE)
					(*values)[k] = phoebe_get_value_double (qualifier);
				if (phoebe_type_from_qualifier (qualifier) == TYPE_DOUBLE_ARRAY)
					(*values)[k] = phoebe_get_value_list_double (qualifier, k - (j - (multi * (lcno-1)) - 1));
				}
			}

	return j;
	}
