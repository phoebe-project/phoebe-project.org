/* This is PHOEBE scripter's Abstract Syntax Tree (AST) implementation.       */

#include "phoebe_build_config.h"

#include <stdlib.h>
#include <string.h>

#include <math.h>

#include "phoebe_scripter_ast.h"
#include "phoebe_scripter_commands.h"
#include "phoebe_scripter_grammar.h"

#include "phoebe_accessories.h"
#include "phoebe_allocations.h"
#include "phoebe_error_handling.h"
#include "phoebe_fortran_interface.h"
#include "phoebe_global.h"

scripter_ast *scripter_ast_add_int (const int val)
	{
	scripter_ast *out  = malloc (sizeof (*out));
	out->type          = ast_int;
	out->value.integer = val;
	return out;
	}

scripter_ast *scripter_ast_add_double (const double val)
	{
	scripter_ast *out = malloc (sizeof (*out));
	out->type         = ast_double;
	out->value.real   = val;
	return out;
	}

scripter_ast *scripter_ast_add_bool (const bool val)
	{
	scripter_ast *out  = malloc (sizeof (*out));
	out->type          = ast_bool;
	out->value.boolean = val;
	return out;
	}

scripter_ast *scripter_ast_add_string (const char *val)
	{
	scripter_ast *out = malloc (sizeof (*out));
	out->type         = ast_string;
	out->value.string = strdup (val);
	return out;
	}

scripter_ast *scripter_ast_add_variable (const char *val)
	{
	scripter_ast *out   = malloc (sizeof (*out));
	out->type           = ast_variable;
	out->value.variable = strdup (val);
	return out;
	}

scripter_ast *scripter_ast_add_function (const char *val)
	{
	scripter_ast *out   = malloc (sizeof (*out));
	out->type           = ast_function;
	out->value.variable = strdup (val);
	return out;
	}

scripter_ast *scripter_ast_add_node (const scripter_ast_kind kind, scripter_ast_list *args)
	{
	scripter_ast *out    = malloc (sizeof (*out));
	out->type            = ast_node;
	out->value.node.kind = kind;
	out->value.node.args = args;
	return out;
	}

scripter_ast_list *scripter_ast_construct_list (scripter_ast *ast, scripter_ast_list *list)
	{
	scripter_ast_list *out = malloc (sizeof (*out));
	out->elem = ast;
	out->next = list;
	return out;
	}

scripter_ast_list *scripter_ast_reverse_list (scripter_ast_list *r, scripter_ast_list *s)
	{
	/* When defining a function, the list is filled from the last element to    */
	/* the first, e.g. f(x,y,z) would create z->y->x parentage. This isn't what */
	/* we want and the following function reverses this order through recursion */
	/* by calling itself. The result after that is x->y->z, as it should be.    */

	if (r == 0) return s;
	return scripter_ast_reverse_list (r->next, scripter_ast_construct_list (r->elem, s));
	}

int scripter_ast_list_length (scripter_ast_list *in)
	{
	int i = 0;
	for (; in != 0; in = in->next) i++;
	return i;
	}

void scripter_ast_print_list (scripter_ast_list *in)
	{
	if (in == 0) return;
	printf ("\t");
	scripter_ast_print (in->elem);
	scripter_ast_print_list (in->next);
	};

void scripter_ast_print (scripter_ast *in)
	{
	switch (in->type)
		{
		case ast_double:
			printf ("%lf", in->value.real);
		break;
		case ast_variable:
			printf ("%s", in->value.variable);
		break;
		case ast_string:
			printf ("%s", in->value.string);
		break;
		case ast_node:
			scripter_ast_print_list (in->value.node.args);
		break;
		}
	}

scripter_ast_value scripter_ast_evaluate (scripter_ast *in)
	{
	/* This is the most important function of the AST implementation. Based on  */
	/* the AST leaf type, it decides what to do and how to do it. It returns    */
	/* any type (the union) and the function must decide which union field to   */
	/* use based on the AST type.                                               */

	scripter_ast_value out;

	switch (in->type)
		{
		case ast_int:
			{
			/* It is an unsigned integer value. Return it.                          */
			out.type    = type_int;
			out.value.i = in->value.integer;
			return out;
			}
		case ast_double:
			{
			/* It is a numeric value. Return it without any complications.          */
			out.type    = type_double;
			out.value.d = in->value.real;
			return out;
			}
		case ast_bool:
			{
			/* It's a boolean (switched) value, which may be TRUE or FALSE.         */
			out.type    = type_bool;
			out.value.b = in->value.boolean;
			return out;
			}
		case ast_string:
			{
			out.type      = type_string;
			out.value.str = strdup (in->value.string);
			return out;
			}
		case ast_variable:
			{
			/* It is a variable.                                                    */
			scripter_symbol *s = scripter_st_identifier_lookup (in->value.variable);
			if (s == 0)
				{
				phoebe_scripter_output ("variable '%s' is not initialized.\n", in->value.variable);
				out.type = type_void; return out;
				}
			if (s->link->type == ast_string)
				{
				out.type      = type_string;
				out.value.str = s->link->value.string;
				}
			else if (s->link->type == ast_int)
				{
				out.type      = type_int;
				out.value.i   = s->link->value.integer;
				}
			else if (s->link->type == ast_double)
				{
				out.type      = type_double;
				out.value.d   = s->link->value.real;
				}
			else if (s->link->type == ast_bool)
				{
				out.type      = type_bool;
				out.value.b   = s->link->value.boolean;
				}
			else
				{
				phoebe_scripter_output ("variable '%s' doesn't hold a numeric or string value.\n", in->value.variable);
				out.type      = type_void;
				}

			return out;
			}
		case ast_node:
			if (in->value.node.kind == kind_block)
				{
				/* This means that the user passed the whole block of statements en-  */
				/* closed in curly braces. The result is always void.                 */
				scripter_ast_list *s = in->value.node.args;
				out.type = type_void;

				if (s == 0)
					{
					phoebe_scripter_output ("temporary info: no statements enclosed.\n");
					return out;
					}
				while (s != 0)
					{
					scripter_ast_evaluate (s->elem);
					s = s->next;
					}
				return out;
				}
			if (in->value.node.kind == kind_system_call)
				{
				/* This means the user used the '!' delimeter to execute a system     */
				/* command. The return value is always void.                          */

				char *syscommand = in->value.node.args->elem->value.string;
				system (syscommand);
				out.type = type_void; return out;
				}
			if (in->value.node.kind == kind_while)
				{
				/* This is the 'while' loop. The return type is always void.          */

				scripter_ast_value condition = scripter_ast_evaluate (in->value.node.args->elem);
				out.type = type_void;

				if (condition.type != type_bool)
					{
					phoebe_scripter_output ("the 'while' loop condition is not boolean.\n");
					return out;
					}

				while (condition.value.b == TRUE)
					{
					scripter_ast_evaluate (in->value.node.args->next->elem);
					condition = scripter_ast_evaluate (in->value.node.args->elem);
					}
				return out;
				}
			if (in->value.node.kind == kind_for)
				{
				/* This is the 'for' loop. It always returns void.                    */

				/* The following line will always evaluate successfully because of    */
				/* the grammar rules:                                                 */
				char  *ident = in->value.node.args->elem->value.variable;
				scripter_ast_value value = scripter_ast_evaluate (in->value.node.args->next->elem);
				scripter_ast_value cond;

				scripter_ast *action = in->value.node.args->next->next->next->elem;
				scripter_ast *block  = in->value.node.args->next->next->next->next->elem;

				out.type = type_void;

				/* Check whether a value is a numeric value:                          */
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("the initial value is not a numeric value, aborting.\n");
					return out;
					}

				/* Create a symbol for iteration and initialize it:                   */
				if (value.type == type_int)
					scripter_st_identifier_insert (ident, scripter_ast_add_int (value.value.i));
				if (value.type == type_double)
					scripter_st_identifier_insert (ident, scripter_ast_add_double (value.value.d));

				/* Evaluate a condition:                                              */
				cond = scripter_ast_evaluate (in->value.node.args->next->next->elem);
				if (cond.type != type_bool)
					{
					phoebe_scripter_output ("the condition is not boolean, so it cannot be evaluated.\n");
					return out;
					}

				/* Enter the loop:                                                    */
				while (cond.value.b == TRUE)
					{
					scripter_ast_evaluate (block);
					scripter_ast_evaluate (action);
					cond = scripter_ast_evaluate (in->value.node.args->next->next->elem);
					}

				/* Wrap it up and exit:                                               */
				return out;
				}

			if (in->value.node.kind == kind_unaryp)
				{
				/* This means that we have a unary '+'.                               */
				scripter_ast_value val = scripter_ast_evaluate (in->value.node.args->elem);

				if (val.type == type_double || val.type == type_int)
					return val;

				phoebe_scripter_output ("unary '+' operator operates only on numeric types.\n");
				val.type = type_void;
				return val;
				}
			if (in->value.node.kind == kind_unarym)
				{
				/* This means that we have a unary '-'.                               */
				scripter_ast_value val = scripter_ast_evaluate (in->value.node.args->elem);

				if (val.type == type_double || val.type == type_int)
					{
					if (val.type == type_int)    val.value.i = -val.value.i;
					if (val.type == type_double) val.value.d = -val.value.d;
					return val;
					}

				phoebe_scripter_output ("unary '-' operator operates only on numeric types.\n");
				val.type = type_void;
				return val;
				}

			if (in->value.node.kind == kind_not)
				{
				/* This means that we have a logical NOT.                             */

				scripter_ast_value val = scripter_ast_evaluate (in->value.node.args->elem);

				if (val.type != type_bool)
					{
					printf ("the unary '!' operates only on boolean expressions, aborting.\n");
					out.type = type_void;
					return out;
					}

				if ( val.value.b == TRUE ) out.value.b = FALSE;
					else out.value.b = TRUE;
				out.type = type_bool;

				return out;
				}

			if (in->value.node.kind == kind_inc)
				{
				/* This means that we have the increment operator on the variable.    */
				/* Because of loops, it is important that this function updates the   */
				/* symbol table itself. The return value is always void.              */

				char              *ident = in->value.node.args->elem->value.variable;
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}

				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i = value.value.i + 1;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i = value.value.d + 1.0;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}
			if (in->value.node.kind == kind_dec)
				{
				/* This means that we have the decrement operator on the variable.    */
				/* Because of loops, it is important that this function updates the   */
				/* symbol table itself. The return value is always void.              */

				char              *ident = in->value.node.args->elem->value.variable;
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}

				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i = value.value.i - 1;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i = value.value.d - 1.0;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}
			if (in->value.node.kind == kind_incby)
				{
				/* This means that we have the increment-by operator on the variable. */

				char   *ident         = in->value.node.args->elem->value.variable;
				scripter_ast_value by = scripter_ast_evaluate (in->value.node.args->next->elem);
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}
				if (by.type != type_int && by.type != type_double)
					{
					phoebe_scripter_output ("increment doesn't hold a numeric value.\n", ident);
					return out;
					}
				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i;
					if (by.type == type_double)
						{
						int val = (int) by.value.d; by.type = type_int; by.value.i = val;
						}
					i = value.value.i + by.value.i;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i;
					if (by.type == type_int)
						{
						double val = (double) by.value.i; by.type = type_double; by.value.d = val;
						}
					i = value.value.d + by.value.d;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}
			if (in->value.node.kind == kind_decby)
				{
				/* This means that we have the decrement-by operator on the variable. */

				char   *ident         = in->value.node.args->elem->value.variable;
				scripter_ast_value by = scripter_ast_evaluate (in->value.node.args->next->elem);
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}
				if (by.type != type_int && by.type != type_double)
					{
					phoebe_scripter_output ("increment doesn't hold a numeric value.\n", ident);
					return out;
					}
				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i;
					if (by.type == type_double)
						{
						int val = (int) by.value.d; by.type = type_int; by.value.i = val;
						}
					i = value.value.i - by.value.i;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i;
					if (by.type == type_int)
						{
						double val = (double) by.value.i; by.type = type_double; by.value.d = val;
						}
					i = value.value.d - by.value.d;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}
			if (in->value.node.kind == kind_multby)
				{
				/* This means that we have the multiply-by operator on the variable.  */

				char   *ident         = in->value.node.args->elem->value.variable;
				scripter_ast_value by = scripter_ast_evaluate (in->value.node.args->next->elem);
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}
				if (by.type != type_int && by.type != type_double)
					{
					phoebe_scripter_output ("increment doesn't hold a numeric value.\n", ident);
					return out;
					}
				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i;
					if (by.type == type_double)
						{
						int val = (int) by.value.d; by.type = type_int; by.value.i = val;
						}
					i = value.value.i * by.value.i;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i;
					if (by.type == type_int)
						{
						double val = (double) by.value.i; by.type = type_double; by.value.d = val;
						}
					i = value.value.d * by.value.d;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}
			if (in->value.node.kind == kind_divby)
				{
				/* This means that we have the divide-by operator on the variable.    */

				char   *ident         = in->value.node.args->elem->value.variable;
				scripter_ast_value by = scripter_ast_evaluate (in->value.node.args->next->elem);
				scripter_ast_value value;

				out.type = type_void;
				if (scripter_st_identifier_lookup (ident) == 0)
					{
					phoebe_scripter_output ("identifier '%s' not initialized, aborting.\n", ident);
					return out;
					}
				if (by.type != type_int && by.type != type_double)
					{
					phoebe_scripter_output ("increment doesn't hold a numeric value.\n", ident);
					return out;
					}
				value = scripter_ast_evaluate ((scripter_st_identifier_lookup (ident))->link);
				if (value.type != type_int && value.type != type_double)
					{
					phoebe_scripter_output ("identifier '%s' doesn't hold a numeric value.\n", ident);
					return out;
					}

				if (value.type == type_int)
					{
					int i;
					if (by.type == type_double)
						{
						int val = (int) by.value.d; by.type = type_int; by.value.i = val;
						}
					i = value.value.i / by.value.i;
					scripter_st_identifier_insert (ident, scripter_ast_add_int (i));
					}
				if (value.type == type_double)
					{
					double i;
					if (by.type == type_int)
						{
						double val = (double) by.value.i; by.type = type_double; by.value.d = val;
						}
					i = value.value.d / by.value.d;
					scripter_st_identifier_insert (ident, scripter_ast_add_double (i));
					}

				return out;
				}

			if (in->value.node.kind == kind_set)
				{
				/* This is a set statement which assigns a value to the variable.     */
				/* There are two modes of this directive operation: one is direct,    */
				/* i.e. set i=1, and the other mode is by using a variable operator,  */
				/* i.e. set i++. The return value is always void.                     */

				scripter_ast_value value;
				out.type = type_void;

				/* First the direct method; it means it has more than 1 argument.     */
				if (in->value.node.args->next != 0)
					{
					/* The following line always evaluates because of the grammar:      */
					char *ident = in->value.node.args->elem->value.variable;
					value = scripter_ast_evaluate (in->value.node.args->next->elem);

					if (value.type == type_string)
						{
						/* We have a single string or string concatenation:               */

						char *concatstr = strdup ("");
						scripter_ast_list *s = in->value.node.args->next;

						while (s != 0)
							{
							scripter_ast_value val = scripter_ast_evaluate (s->elem);
							switch (val.type)
								{
								case (type_int):
									{
									char valstr[50];
									sprintf (valstr, "%d", (val.value.i));
									concatstr = concatenate_strings (concatstr, valstr, NULL);
									}
								break;
								case (type_bool):
									if (val.value.b == TRUE)
										concatstr = concatenate_strings (concatstr, "TRUE", NULL);
									else
										concatstr = concatenate_strings (concatstr, "FALSE", NULL);
								break;
								case (type_double):
									{
									char valstr[50];
									sprintf (valstr, "%lf", val.value.d);
									concatstr = concatenate_strings (concatstr, valstr, NULL);
									}
								break;
								case (type_string):
									concatstr = concatenate_strings (concatstr, val.value.str, NULL);
								break;
								}
							s = s->next;
							}

						/* Finally, we put it to the symbol table; the newly created AST  */
						/* leaf makes a copy of the string, so we may free memory here:   */
						scripter_st_identifier_insert (ident, scripter_ast_add_string (concatstr));
						free (concatstr);

						return out;
						}

					if (value.type == type_int)
						{
						scripter_st_identifier_insert (ident, scripter_ast_add_int (value.value.i));
						return out;
						}
					if (value.type == type_bool)
						{
						scripter_st_identifier_insert (ident, scripter_ast_add_bool (value.value.b));
						return out;
						}
					if (value.type == type_double)
						{
						scripter_st_identifier_insert (ident, scripter_ast_add_double (value.value.d));
						return out;
						}
					if (value.type == type_void)
						{
						phoebe_scripter_output ("assignment failed.\n");
						return out;
						}
					}

				/* And now the second method; individual symbol table updates are     */
				/* called in dedicated functions (for ++, --, ...).                   */
				if (in->value.node.args->next == 0)
					value = scripter_ast_evaluate (in->value.node.args->elem);

				return out;
				}

			if (in->value.node.kind == kind_builtin)
				{
				/* This means we have a built-in mathematical function. The returned  */
				/* value is double if everything is ok and void if an error occured.  */

				/* This is uniquely determined, so the assignment cannot fail:        */
				char *func  = in->value.node.args->elem->value.function;
				scripter_ast_value value = scripter_ast_evaluate (in->value.node.args->next->elem);

				if (value.type != type_double && value.type != type_int)
					{
					phoebe_scripter_output ("built-in function called with non-numeric argument, aborting.\n");
					out.type = type_void; return out;
					}

				if (value.type == type_int)
					{
					/* We must propagate an integer value to double:                    */
					int val = value.value.i;
					value.type = type_double;
					value.value.d = (double) val;
					}

				if (strcmp (func,  "sin") == 0) out.value.d = sin   (value.value.d);
				if (strcmp (func,  "cos") == 0) out.value.d = cos   (value.value.d);
				if (strcmp (func,  "tan") == 0) out.value.d = tan   (value.value.d);
				if (strcmp (func, "asin") == 0) out.value.d = asin  (value.value.d);
				if (strcmp (func, "acos") == 0) out.value.d = acos  (value.value.d);
				if (strcmp (func, "atan") == 0) out.value.d = atan  (value.value.d);
				if (strcmp (func,  "exp") == 0) out.value.d = exp   (value.value.d);
				if (strcmp (func,   "ln") == 0) out.value.d = log   (value.value.d);
				if (strcmp (func,  "log") == 0) out.value.d = log10 (value.value.d);
				if (strcmp (func, "sqrt") == 0) out.value.d = sqrt  (value.value.d);
				out.type = type_double;

				return out;
				}

			if (in->value.node.kind == kind_command)
				{
				/* This is PHOEBE scripter command.                                   */
				char *command = in->value.node.args->elem->value.string;

				if (strcmp (command, "open_keyword_file") == 0)
					scripter_open_keyword_file (in->value.node.args);

				if (strcmp (command, "save_keyword_file") == 0)
					scripter_save_keyword_file (in->value.node.args);

				if (strcmp (command, "set_parameter_value") == 0)
					scripter_set_parameter_value (in->value.node.args);

				if (strcmp (command, "get_parameter_value") == 0)
					scripter_get_parameter_value (in->value.node.args);

				if (strcmp (command, "create_wd_lci_file") == 0)
					scripter_create_wd_lci_file (in->value.node.args);

				if (strcmp (command, "compute_lc") == 0)
					scripter_compute_lc (in->value.node.args);

				if (strcmp (command, "compute_rv") == 0)
					scripter_compute_rv (in->value.node.args);

				if (strcmp (command, "minimize_using_simplex") == 0)
					scripter_minimize_using_simplex (in->value.node.args);

				out.type = type_void; return out;
				}

			if (in->value.node.kind == kind_define)
				{
				/* The following line will always evaluate because of grammar rules.  */
				char *id = in->value.node.args->elem->value.variable;
				scripter_st_user_function_insert (id, in);
				out.type = type_void; return out;
				}

			if (in->value.node.kind == kind_func)
				{
				/* This is a user-defined function (defined with 'define' directive). */
				/* These functions are always numeric and they return the value; if   */
				/* the error occured, void is returned.                               */

				double result;

				scripter_ast_list *arguments = NULL;
				scripter_ast_list *params;
				scripter_ast      *body;
				scripter_ast_list *list;

				scripter_symbol *id = scripter_st_identifier_lookup (in->value.node.args->elem->value.variable);

				if (id == 0)
					{
					phoebe_scripter_output ("function '%s' not defined.\n", in->value.node.args->elem->value.variable);
					out.type = type_void; return out;
					}
				if ( (id->link->type != ast_node) || ( id->link->value.node.kind != kind_define ) )
					{
					phoebe_scripter_output ("identifier '%s' is not a function.\n", in->value.node.args->elem->value.variable);
					out.type = type_void; return out;
					}

				body   = id->link->value.node.args->next->elem;
				params = id->link->value.node.args->next->next;

				/* Now we have to evaluate the function arguments:                    */
				for (list = in->value.node.args->next; list != 0; list = list->next)
					{
					scripter_ast_value val = scripter_ast_evaluate (list->elem);
					if (val.type != type_double && val.type != type_int)
						{
						phoebe_scripter_output ("non-numerical argument in definition call, aborting.\n");
						out.type = type_void; return out;
						}
					if (val.type == type_int)
						{
						/* Integer -> real type propagation:                              */
						double new = (double) val.value.i; val.type = type_double; val.value.d = new;
						}
					arguments = scripter_ast_construct_list (scripter_ast_add_double (val.value.d), arguments);
					}
				arguments = scripter_ast_reverse_list (arguments, NULL);

				if (scripter_ast_list_length (params) != scripter_ast_list_length (arguments))
					{
					phoebe_scripter_output ("function '%s' called with wrong number of parameters.\n", in->value.node.args->elem->value.variable);
					out.type = type_void; return out;
					}

				/* Start a new environment where the function will be evaluated:      */
				scripter_ast_flow_begin_scope ();
				for (list = params; list != 0; list = list->next, arguments = arguments->next)
					scripter_st_identifier_insert (list->elem->value.variable, arguments->elem);
				result = (scripter_ast_evaluate (body)).value.d;
				scripter_ast_flow_end_scope ();

				out.type = type_double;
				out.value.d = result; return out;
				}

			if (in->value.node.kind == kind_calc)
				{
				/* This is the calculation directive, where a single argument - an    */
				/* expression - is passed. This directive returns void in all cases.  */

				scripter_ast_value value = scripter_ast_evaluate (in->value.node.args->elem);
				out.type = type_void;

				if (value.type == type_string)
					{
					phoebe_scripter_output ("cannot calculate with strings. Use 'print' to print them.\n");
					return out;
					}
				if (value.type == type_void)
					{
					phoebe_scripter_output ("calculation failed.\n");
					return out;
					}
				if (scripter_scope_level != 0)
					/* The statement is in a block; don't print it out until the block  */
					/* is finished.                                                     */
					return out;

				if (value.type == type_int)
					printf ("\t%d\n", value.value.i);
				if (value.type == type_double)
					printf ("\t%g\n", value.value.d);
				if (value.type == type_bool)
					if (value.value.b == TRUE)
						printf ("\tTRUE\n");
					else
						printf ("\tFALSE\n");

				return value;
				}

			if (in->value.node.kind == kind_print)
				{
				/* The 'print' directive prints out an arbitrary number of arguments, */
				/* which may be any of PHOEBE's supported types: int, bool, double or */
				/* string. The return value is always void.                           */

				scripter_ast_list *s = in->value.node.args;
				out.type = type_void;

				printf ("\t");
				while (s != 0)
					{
					scripter_ast_value in = scripter_ast_evaluate (s->elem);
					switch (in.type)
						{
						case (type_int):
							printf ("%d", in.value.i);
						break;
						case (type_double):
							printf ("%lf", in.value.d);
						break;
						case (type_bool):
							if (in.value.b == TRUE)
								printf ("TRUE");
							else printf ("FALSE");
						break;
						case (type_string):
							printf ("%s", in.value.str);
						break;
						}
					s = s->next;
					}

				printf ("\n");
				return out;
				}

			if (in->value.node.kind == kind_if)
				{
				/* This means that we have an IF conditional without the ELSE part.   */
				/* The return value is always void.                                   */

				scripter_ast_value condition  = scripter_ast_evaluate (in->value.node.args->elem);
				scripter_ast *block = in->value.node.args->next->elem;
				out.type = type_void;

				if (condition.type != type_bool)
					{
					phoebe_scripter_output ("the condition is not boolean, so it cannot be evaluated.\n");
					return out;
					}

				if (condition.value.b == TRUE)
					scripter_ast_evaluate (block);

				return out;
				}

			if (in->value.node.kind == kind_ifelse)
				{
				/* This means that we have an IF conditional with the ELSE part. The  */
				/* return value is always void.                                       */

				scripter_ast_value condition  = scripter_ast_evaluate (in->value.node.args->elem);
				scripter_ast *block1 = in->value.node.args->next->elem;
				scripter_ast *block2 = in->value.node.args->next->next->elem;
				out.type = type_void;

				if (condition.type != type_bool)
					{
					phoebe_scripter_output ("the condition is not boolean, so it cannot be evaluated.\n");
					return out;
					}

				if (condition.value.b == TRUE)
					scripter_ast_evaluate (block1);
				else
					scripter_ast_evaluate (block2);

				return out;
				}

			if (scripter_ast_list_length (in->value.node.args) == 2)
				{
				/* This means we have a binary arithmetic or a boolean operation:     */

				scripter_ast_value val1 = scripter_ast_evaluate (in->value.node.args->elem);
				scripter_ast_value val2 = scripter_ast_evaluate (in->value.node.args->next->elem);
				double first, second;

				if (val1.type == type_string || val1.type == type_void ||
				    val2.type == type_string || val2.type == type_void )
					{
					phoebe_scripter_output ("binary operators cannot operate on non-numerical arguments.\n");
					out.type = type_void;
					return out;
					}

				if (val1.type == type_int)
					{
					/* Propagate type int to type double:                               */
					int val = val1.value.i; val1.type = type_double; val1.value.d = (double) val;
					}
				if (val2.type == type_int)
					{
					/* Propagate type int to type double:                               */
					int val = val2.value.i; val2.type = type_double; val2.value.d = (double) val;
					}
				if (val1.type == type_bool)
					{
					/* Propagate type bool to type double:                              */
					bool val = val1.value.b; val1.type = type_double; val1.value.d = (double) val;
					}
				if (val2.type == type_bool)
					{
					/* Propagate type bool to type double:                              */
					bool val = val2.value.b; val2.type = type_double; val2.value.d = (double) val;
					}

				first  = val1.value.d;
				second = val2.value.d;

				switch (in->value.node.kind)
					{
					case kind_add:
						out.value.d = first + second;
						out.type    = type_double;
					break;
					case kind_sub:
						out.value.d = first - second;
						out.type    = type_double;
					break;
					case kind_mul:
						out.value.d = first * second;
						out.type    = type_double;
					break;
					case kind_div:
						out.value.d = first / second;
						out.type    = type_double;
					break;
					case kind_pot:
						out.value.d = pow (first, second);
						out.type    = type_double;
					break;
					case kind_equal:
						out.value.b = first == second;
						out.type    = type_bool;
					break;
					case kind_nequal:
						out.value.b = first != second;
						out.type    = type_bool;
					break;
					case kind_lequal:
						out.value.b = first <= second;
						out.type    = type_bool;
					break;
					case kind_gequal:
						out.value.b = first >= second;
						out.type    = type_bool;
					break;
					case kind_less:
						out.value.b = first <  second;
						out.type    = type_bool;
					break;
					case kind_greater:
						out.value.b = first >  second;
						out.type    = type_bool;
					break;
					case kind_and:
						out.value.b = first && second;
						out.type    = type_bool;
					break;
					case kind_or:
						out.value.b = first || second;
						out.type    = type_bool;
					break;
					}
				return out;
				}
 		}
	}

void scripter_ast_flow_begin_scope ()
	{
	scripter_stack[scripter_stack_size++] = -1;
	if (scripter_stack_size >= scripter_stack_length)
		phoebe_fatal ("scripter's stack memory exhausted, halting.\n");
	};

void scripter_ast_flow_end_scope ()
	{
	int i = scripter_stack_size - 1;
	for ( ; scripter_stack[i] >= 0; i--)
		{
		int pos = scripter_stack[i];
		scripter_st[pos] = scripter_st[pos]->next;
		};
	scripter_stack_size = i-1;
	};

/* ************************************************************************** */
/*             This part of the code describes the Symbol Table:              */
/* ************************************************************************** */

long scripter_st_identifier_hash (const char *id)
	{
	/* This function takes a string and transforms it into a unique hashed num- */
	/* ber, which we then use as a symbol table identifier. The 'out << 3' part */
	/* means that we bitwise-shift out for three bits to the left, because      */
	/* strings have bit 7 always 0, bit 6 always 1 and bit 5 always 0 for small */
	/* letters and 1 for capital letters. Thus we don't have much entropy in    */
	/* them and we shift the string. The next part with XOR operator ('^') is,  */
	/* well, pure magic beyond my comprehension... O:-)                         */

	long out = 0;
	int i = strlen (id) - 1;
	for ( ; i >= 0; i--)
		out = (out << 3) ^ (id[i]);
  return out;
	}

void scripter_st_initialize ()
	{
	int i;
	for (i = 0; i < scripter_symbol_table_size; i++) scripter_st[i] = 0;
	scripter_stack_size = 0;
	}

void scripter_st_identifier_assign (const char *id, const double value)
	{
	scripter_st_identifier_insert (id, scripter_ast_add_double (value));
	}

void scripter_st_identifier_insert (const char *id, scripter_ast *ast)
	{
	int pos = scripter_st_identifier_hash (id) % scripter_symbol_table_size;
	scripter_symbol *s = malloc (sizeof (*s));

	s->name = strdup (id);
	s->link = ast;
	s->next = scripter_st[pos];
	scripter_st[pos] = s;
	scripter_stack[scripter_stack_size++] = pos;
	if (scripter_stack_size >= scripter_stack_length)
		phoebe_fatal ("scripter stack memory exhausted, halting.\n");
	}

scripter_symbol *scripter_st_identifier_lookup (const char *id)
	{
	int pos = scripter_st_identifier_hash (id) % scripter_symbol_table_size;
	scripter_symbol *s = scripter_st[pos];
	for ( ; s != 0; s = s->next)
		if (strcmp (s->name, id) == 0) return s;
	return 0;
	}

void scripter_st_user_function_insert (const char *id, scripter_ast *ast)
	{
	scripter_st_identifier_insert (id, ast);
	}
