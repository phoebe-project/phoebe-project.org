#ifndef PHOEBE_ALLOCATIONS_H
	#define PHOEBE_ALLOCATIONS_H

#include "phoebe_global.h"

int initialize_memory_for_data (PHOEBE_data *data);
int allocate_memory_for_data (PHOEBE_data *data, int records_no);
int free_allocated_memory_for_data (PHOEBE_data *data);

char *parse_data_line               (char *in);
int   read_in_synthetic_data        (PHOEBE_data *data, int curve, int indep, int dep, int weight, double phstrt, double phend, int vertices);
int   read_in_experimental_data     (char *filename, PHOEBE_data *data, int indep, int outindep, int dep, int outdep, int weight, int outweight);
int   read_in_wd_lci_parameters     (WD_LCI_parameters *params, int MPAGE, int JDPHS, int curve);
int   read_in_lc_plot_parameters    (PHOEBE_lc_plot_parameters *params);
int   read_in_ephemeris_parameters  (double *hjd0, double *period, double *dpdt, double *pshift);
int   read_in_adjustable_parameters (bool **switches, double **steps, double **values, int **indices, int *to_be_adjusted);

#endif
