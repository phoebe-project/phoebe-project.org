#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "phoebe_build_config.h"

#include "phoebe_allocations.h"
#include "phoebe_error_handling.h"
#include "phoebe_fitting.h"
#include "phoebe_fortran_interface.h"
#include "phoebe_keywords.h"

#include "phoebe_scripter_ast.h"
#include "phoebe_global.h"

int scripter_compute_lc (scripter_ast_list *args)
	{
	/* Format: create_lc ("filename", curve, start, end, vertices)              */

	char  *file  = args->next->elem->value.string;
	scripter_ast_value curve, start, end, vert;
	int    i, errno;

	PHOEBE_data data;
	FILE *fout;

	curve = scripter_ast_evaluate (args->next->next->elem);
	if (curve.type != type_int)
		{
		phoebe_scripter_output ("curve index called with non-integer value, aborting.\n");
		return -1;
		}
	start = scripter_ast_evaluate (args->next->next->next->elem);
	if (start.type != type_double)
		{
		phoebe_scripter_output ("phase start called with non-real value, aborting.\n");
		return -1;
		}
	end = scripter_ast_evaluate (args->next->next->next->next->elem);
	if (end.type != type_double)
		{
		phoebe_scripter_output ("phase end called with non-real value, aborting.\n");
		return -1;
		}
	vert = scripter_ast_evaluate (args->next->next->next->next->next->elem);
	if (vert.type != type_int)
		{
		phoebe_scripter_output ("vertices passed by non-integer value, aborting.\n");
		return -1;
		}

	/* Fix the OB1 error:                                               */
	curve.value.i -= 1;

	initialize_memory_for_data (&data);
	errno = read_in_synthetic_data (&data, curve.value.i, OUTPUT_PHASE, OUTPUT_TOTAL_FLUX, OUTPUT_UNAVAILABLE, start.value.d, end.value.d, vert.value.i);

	switch (errno)
		{
		case -2:
			phoebe_scripter_output ("curve %d is not initialized.\n", curve.value.i + 1);
			return -2;
		break;
		case -1:
			phoebe_scripter_output ("synthetic data calculation failed.\n");
			return -1;
		break;
		}

	fout = fopen (file, "w");
	if (fout == NULL)
		{
		phoebe_scripter_output ("file creation failed.\n");
		return -3;
		}
	fprintf (fout, "#        PHASE            FLUX\n");
	for (i = 0; i < data.ptsno; i++)
		fprintf (fout, "%15.6lf\t%15.6lf\n", data.indep[i], data.dep[i]);
	fclose (fout);

	phoebe_scripter_output ("file '%s' created.\n", file);
	return 0;
	}

int scripter_compute_rv (scripter_ast_list *args)
	{
	/* Format: create_rv ("filename", curve, start, end, vertices);             */

	char  *file  = args->next->elem->value.string;
	scripter_ast_value curve, start, end, vert;
	int    i, errno;

	PHOEBE_data rv;
	FILE *fout;

	curve = scripter_ast_evaluate (args->next->next->elem);
	if (curve.type != type_int)
		{
		phoebe_scripter_output ("curve index called with non-integer value, aborting.\n");
		return -1;
		}
	start = scripter_ast_evaluate (args->next->next->next->elem);
	if (start.type != type_double)
		{
		phoebe_scripter_output ("phase start called with non-real value, aborting.\n");
		return -1;
		}
	end = scripter_ast_evaluate (args->next->next->next->next->elem);
	if (end.type != type_double)
		{
		phoebe_scripter_output ("phase end called with non-real value, aborting.\n");
		return -1;
		}
	vert = scripter_ast_evaluate (args->next->next->next->next->next->elem);
	if (vert.type != type_int)
		{
		phoebe_scripter_output ("vertices passed by non-integer value, aborting.\n");
		return -1;
		}

	/* Fix the OB1 error:                                                       */
	curve.value.i -= 1;

	initialize_memory_for_data (&rv);

	if (curve.value.i == 0)
		errno = read_in_synthetic_data (&rv, curve.value.i, OUTPUT_PHASE, OUTPUT_PRIMARY_RV, OUTPUT_UNAVAILABLE, start.value.d, end.value.d, vert.value.i);
	if (curve.value.i == 1)
		errno = read_in_synthetic_data (&rv, curve.value.i, OUTPUT_PHASE, OUTPUT_SECONDARY_RV, OUTPUT_UNAVAILABLE, start.value.d, end.value.d, vert.value.i);
	switch (errno)
		{
		case -2:
			phoebe_scripter_output ("curve %d is not initialized.\n", curve.value.i + 1);
			free_allocated_memory_for_data (&rv);
			return -2;
		break;
		case -1:
			phoebe_scripter_output ("synthetic data calculation failed.\n");
			free_allocated_memory_for_data (&rv);
			return -1;
		break;
		}
	fout = fopen (file, "w");
	if (fout == NULL)
		{
		phoebe_scripter_output ("file creation failed.\n");
		return -3;
		}
	fprintf (fout, "#        PHASE            RV%d\n", curve.value.i+1);
	for (i = 0; i < rv.ptsno; i++)
		fprintf (fout, "%15.6lf\t%15.6lf\n", rv.indep[i], rv.dep[i]);
	fclose (fout);

	free_allocated_memory_for_data (&rv);
	phoebe_scripter_output ("file '%s' created.\n", file);
	return 0;
	}

int scripter_open_keyword_file (scripter_ast_list *args)
	{
	scripter_ast_value file = scripter_ast_evaluate (args->next->elem);
	int errcode;

	if (file.type != type_string)
		{
		phoebe_scripter_output ("please pass a literal name or a string identifier.\n");
		return -1;
		}
	errcode = open_keyword_file (file.value.str);

	if (errcode == -3) phoebe_scripter_output ("keyword file '%s' not a regular file.\n", file.value.str);
	if (errcode == -2) phoebe_scripter_output ("keyword file '%s' has no read permissions.\n", file.value.str);
	if (errcode == -1) phoebe_scripter_output ("keyword file '%s' doesn't exist.\n", file.value.str);
	if (errcode ==  0) phoebe_scripter_output ("keyword file '%s' opened.\n", file.value.str);
	if (errcode ==  1) phoebe_scripter_output ("'%s' is a legacy keyword file.\n", file.value.str);
	return 0;
	}

int scripter_save_keyword_file (scripter_ast_list *args)
	{
	scripter_ast_value file = scripter_ast_evaluate (args->next->elem);
	int errcode;

	if (file.type != type_string)
		{
		phoebe_scripter_output ("please pass a literal name or a string identifier.\n");
		return -1;
		}

	errcode = save_keyword_file (file.value.str);
	if (errcode == -3) phoebe_scripter_output ("keyword file '%s' not a regular file.\n", file.value.str);
	if (errcode == -2) phoebe_scripter_output ("keyword file '%s' has no write permissions.\n", file.value.str);
	if (errcode ==  0) phoebe_scripter_output ("keyword file '%s' saved.\n", file.value.str);
	return 0;
	}

int scripter_set_parameter_value (scripter_ast_list *args)
	{
	char       *qualifier    = args->next->elem->value.variable;
	PHOEBE_type type         = phoebe_type_from_qualifier (qualifier);
	scripter_ast_value value;
	int         index        = -1;
	int         errno;

	if (type == -1)
		{
		phoebe_scripter_output ("qualifier '%s' doesn't exist.\n", qualifier);
		return -1;
		}

	/* Do the parameter type vs. input type check:                              */
	value = scripter_ast_evaluate (args->next->next->elem);
	if ( (type == TYPE_INT || type == TYPE_INT_ARRAY) && value.type != type_int )
		{
		phoebe_scripter_output ("qualifier '%s' expects an integer value.\n", qualifier);
		return -1;
		}
	if ( (type == TYPE_DOUBLE || type == TYPE_DOUBLE_ARRAY) && (value.type != type_int && value.type != type_double) )
		{
		phoebe_scripter_output ("qualifier '%s' expects a real value.\n", qualifier);
		return -1;
		}
	if ( (type == TYPE_BOOL || type == TYPE_BOOL_ARRAY) && (value.type != type_int && value.type != type_bool) )
		{
		/* It is common to pass 0 or 1 instead of FALSE and TRUE, so we shall     */
		/* propagate these values to boolean type.                                */
		phoebe_scripter_output ("qualifier '%s' expects a boolean value.\n", qualifier);
		return -1;
		}
	if ( (type == TYPE_STRING || type == TYPE_STRING_ARRAY) && value.type != type_string )
		{
		phoebe_scripter_output ("qualifier '%s' expects a string value.\n", qualifier);
		return -1;
		}

	/* Do the type propagation if necessary:                                    */
	if ( (type == TYPE_DOUBLE || type == TYPE_DOUBLE_ARRAY) && value.type == type_int)
		{
		double val;
		
		val = (double) value.value.i; value.type = type_double; value.value.d = val;
		}
	if ( (type == TYPE_BOOL || type == TYPE_BOOL_ARRAY) && value.type == type_int)
		{
		bool val;
		if (value.value.i == 1) val = TRUE;
		else if (value.value.i == 0) val = FALSE;
		else
			{
			phoebe_scripter_output ("qualifier '%s' expects a boolean value.\n", qualifier);
			return -1;
			}
		value.type = type_bool; value.value.b = val;
		}

	/* Do the array check:                                                      */
	if (args->next->next->next != 0)
		{
		/* This means that the parameter is an array. We subtract 1 from the in-  */
		/* dex because of OB1 user<->machine conflict.                            */
		scripter_ast_value idx = scripter_ast_evaluate (args->next->next->next->elem);
		if (idx.type != type_int)
			{
			phoebe_scripter_output ("curve index expects an integer value.\n");
			return -1;
			}
		index = idx.value.i;
		index--;
		}

	switch (type)
		{
		case TYPE_INT:
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, (int) value.value.i);
		break;
		case TYPE_INT_ARRAY:
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, index, value.value.i);
			if (errno == -2) phoebe_scripter_output ("array index [%d] out of bounds, aborting.\n", index+1);
		break;
		case TYPE_BOOL:
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, value.value.b);
		break;
		case TYPE_BOOL_ARRAY:
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, index, value.value.b);
			if (errno == -2) phoebe_scripter_output ("array index [%d] out of bounds, aborting.\n", index+1);
		break;
		case TYPE_DOUBLE:
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, value.value.d);
		break;
		case TYPE_DOUBLE_ARRAY:
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector value, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, index, value.value.d);
			if (errno == -2) phoebe_scripter_output ("array index [%d] out of bounds, aborting.\n", index+1);
		break;
		case TYPE_STRING:
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a string, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, value.value.str);
		break;
		case TYPE_STRING_ARRAY:
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a string array, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_set_parameter_value (qualifier, index, value.value.str);
			if (errno == -2) phoebe_scripter_output ("array index [%d] out of bounds, aborting.\n", index+1);
		break;
		}

	return 0;
	}

int scripter_create_wd_lci_file (scripter_ast_list *args)
	{
	/* This part allows the user to create WD2003 lci input file to use it di-  */
	/* rectly with WD.                                                          */
	
	scripter_ast_value file = scripter_ast_evaluate (args->next->elem);
	int  mpage = (int) (scripter_ast_evaluate (args->next->next->elem)).value.d;
	int  curve = (int) (scripter_ast_evaluate (args->next->next->next->elem)).value.d - 1;
	int  jdphs;
	int  errno;
	WD_LCI_parameters params;

	if (file.type != type_string)
		{
		phoebe_scripter_output ("identifier '%s' is not a string, aborting.\n", args->next->elem->value.variable);
		return -1;
		}

	if (phoebe_get_value_bool ("phoebe_time_switch") == TRUE) jdphs = 1; else jdphs = 2;
	errno = read_in_wd_lci_parameters (&params, mpage, jdphs, curve);
	if (errno == -2)
		phoebe_scripter_output ("curve %d is not defined, aborting.\n", curve+1);
	if (errno == 1)
		phoebe_scripter_output ("the passed MPAGE isn't (yet) supported.\n");
	if (errno == 0)
		{
		create_lci_file (file.value.str, params);
		phoebe_scripter_output ("WD lci file '%s' created.\n", file.value.str);
		}

	return 0;
	}

int scripter_get_parameter_value (scripter_ast_list *args)
	{
	/* The following assignments cannot fail because of grammar rules.          */
	char *identifier = args->next->elem->value.variable;
	char *qualifier  = args->next->next->elem->value.variable;
	PHOEBE_type type = phoebe_type_from_qualifier (qualifier);
	int index = -1;

	if (type == -1)
		{
		phoebe_scripter_output ("passed qualifier '%s' doesn't exist.\n", qualifier);
		return -1;
		}

	if (args->next->next->next != 0)
		{
		/* This means that the parameter is an array. We subtract 1 from the in-  */
		/* dex because of OB1 user<->machine conflict.                            */
		scripter_ast_value idx = scripter_ast_evaluate (args->next->next->next->elem);
		if (idx.type != type_int)
			{
			phoebe_scripter_output ("curve index expects an integer value.\n");
			return -1;
			}
		index = idx.value.i;
		index--;
		}

	switch (type)
		{
		case (TYPE_INT):
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_int (phoebe_get_value_int (qualifier)));
		break;
		case (TYPE_BOOL):
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_bool (phoebe_get_value_bool (qualifier)));
		break;
		case (TYPE_DOUBLE):
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a scalar value, aborting.\n", qualifier);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_double (phoebe_get_value_double (qualifier)));
		break;
		case (TYPE_STRING):
			if (index != -1)
				{
				phoebe_scripter_output ("qualifier '%s' is a single string, aborting.\n", qualifier);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_string ((char *) phoebe_get_value_string (qualifier)));
		break;
		case (TYPE_INT_ARRAY):
			{
			int val;
			int errno;
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_get_parameter_value (qualifier, index, &val);
			if (errno == -2)
				{
				phoebe_scripter_output ("array index [%d] out of range.\n", index+1);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_int (val));
			}
		break;
		case (TYPE_BOOL_ARRAY):
			{
			bool val;
			int errno;
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_get_parameter_value (qualifier, index, &val);
			if (errno == -2)
				{
				phoebe_scripter_output ("array index [%d] out of range.\n", index+1);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_bool (val));
			}
		break;
		case (TYPE_DOUBLE_ARRAY):
			{
			double val;
			int errno;
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_get_parameter_value (qualifier, index, &val);
			if (errno == -2)
				{
				phoebe_scripter_output ("array index [%d] out of range.\n", index+1);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_double (val));
			}
		break;
		case (TYPE_STRING_ARRAY):
			{
			char *val;
			int errno;
			if (index < 0)
				{
				phoebe_scripter_output ("qualifier '%s' is a vector, aborting.\n", qualifier);
				return -1;
				}
			errno = phoebe_get_parameter_value (qualifier, index, &val);
			if (errno == -2)
				{
				phoebe_scripter_output ("array index [%d] out of range.\n", index+1);
				return -1;
				}
			scripter_st_identifier_insert (identifier, scripter_ast_add_string (val));
			}
		break;
		}
	}

int scripter_minimize_using_simplex (scripter_ast_list *args)
	{
	/* This function calls the Nelder & Mead simplex minimizer.                 */

	scripter_ast_value tol      = scripter_ast_evaluate (args->next->elem);
	scripter_ast_value max_iter = scripter_ast_evaluate (args->next->next->elem);
	int    result;

	if (tol.type != type_double)
		{
		phoebe_scripter_output ("the passed tolerance is not a real value, aborting.\n");
		return -1;
		}
	if (max_iter.type != type_int)
		{
		phoebe_scripter_output ("the passed number of iterations is not an integer value, aborting.\n");
		return -1;
		}

	if (max_iter.value.i < 0)
		{
		phoebe_scripter_output ("negative maximum number of iterations, aborting.\n");
		return -1;
		}
	if (max_iter.value.i == 0)
		{
		phoebe_scripter_output ("downhill simplex: tol = %2.2e, unlimited iterations:\n", tol.value.d);
		max_iter.value.i = 1e8;
		}
	else
		phoebe_scripter_output ("downhill simplex: tol = %2.2e, max %d iterations:\n", tol.value.d, max_iter.value.i);

	/* Call the downhill simplex minimizer:                                     */
	result = find_minimum_with_simplex (tol.value.d, max_iter.value.i, FALSE);

	/* Test for exceptions:                                                     */
	if (result == -9)
		phoebe_scripter_output ("independent variable enumeration readout failed.\n");
	if (result == -8)
		phoebe_scripter_output ("dependent variable enumeration readout failed.\n");
	if (result == -7)
		phoebe_scripter_output ("weighting variable enumeration readout failed.\n");
	if (result == -2)
		phoebe_scripter_output ("experimental data failure - an error occured during the readout.\n");
	if (result ==  1)
		phoebe_scripter_output ("no curves selected for adjustment, nothing to be done.\n");
	if (result ==  2)
		phoebe_scripter_output ("no parameters selected for adjustment, nothing to be done.\n");

	/* Say goodbye:                                                             */
	phoebe_scripter_output ("simplex minimization done.\n");
	return 0;
	}
