#ifndef PHOEBE_FITTING_H
	#define PHOEBE_FITTING_H

int find_minimum_with_simplex (double accuracy, int iter_no, bool update);
int find_minimum_with_siman ();

#endif
