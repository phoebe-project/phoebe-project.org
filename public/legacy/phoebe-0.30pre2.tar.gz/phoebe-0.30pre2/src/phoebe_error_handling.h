#ifndef PHOEBE_ERROR_HANDLING_H
	#define PHOEBE_ERROR_HANDLING_H 1

#include <gtk/gtk.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int phoebe_notice          (const char *fmt, ...);
int phoebe_warning         (const char *fmt, ...);
int phoebe_debug           (const char *fmt, ...);
int phoebe_fatal           (const char *fmt, ...);
int phoebe_scripter_output (const char *fmt, ...);

void *phoebe_malloc (size_t size);
void *phoebe_realloc (void *ptr, size_t size);

GtkWidget* create_warning_window (char *title, char *main_label, char *description1, char *description2, GCallback ok_function, GCallback cancel_function);
GtkWidget* create_notice_window  (char *title, char *main_label, char *description1, char *description2, GCallback Function);

#endif
