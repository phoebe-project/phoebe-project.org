#ifndef PHOEBE_SCRIPTER_DIRECTIVES_H
	#define PHOEBE_SCRIPTER_DIRECTIVES_H 1

int scripter_directive_help (char *command);
int scripter_directive_quit ();
int scripter_execute_directive (char *directive, char *argument);

#endif
