#include "phoebe_build_config.h"
#include <stdio.h>
#include <string.h>

#include "phoebe_allocations.h"
#include "phoebe_calculations.h"
#include "phoebe_error_handling.h"
#include "phoebe_fortran_interface.h"
#include "phoebe_global.h"
#include "phoebe_keywords.h"

/* At this point we should check whether GSL is available; if it isn't, then  */
/* we don't have much to compile here.                                        */

#ifdef HAVE_LIBGSL
#ifndef PHOEBE_GSL_DISABLED

#include <gsl/gsl_multimin.h>
#include <gsl/gsl_siman.h>

/* Simulated annealing parameters: these should be moved to PHOEBE keywords   */
/* as soon as possible:                                                       */

/* how many points do we try before stepping */
#define N_TRIES 200             
/* how many iterations for each T? */
#define ITERS_FIXED_T 10        
/* max step size in random walk */
#define STEP_SIZE 0.2
/* Boltzmann constant */
#define K 1.0                   
/* initial temperature */
#define T_INITIAL 10
/* damping factor for temperature */
#define MU_T 1.001
#define T_MIN 2.0e-6

static PHOEBE_data *exp_data;

double calculate_chi2 (PHOEBE_data synthetic_data, PHOEBE_data experimental_data, double sigma, int type)
	{
	/* This function interpolates synthetic curve and experimental data points  */
	/* and calculates standard deviation depending on the type integer:         */
  /*                                                                          */
	/*   type = 0   ...   standard deviation with no weighting applied          */
	/*   type = 1   ...   standard deviation with weighting applied             */
	/*   type = 2   ...   chi2 with no weighting applied                        */
	/*   type = 3   ...   chi2 with weighting applied                           */
  /*                                                                          */
	/* If the function returns a negative value, it means something went wrong. */

	int i, j;
	int breaked;
	double interpolated_y;

	double chi2 = 0.0;
	double weight_sum = 0.0;

	/* First let's do some error checking:                                      */
	if ( (synthetic_data.ptsno <= 1) || (experimental_data.ptsno <= 1) )
		{
		phoebe_warning ("calculate_chi2 routine called with vectors that have dimension <= 1.");
		return -1.0;
		}

	for (i = 0; i < experimental_data.ptsno; i++)
		{
		breaked = 0;
		for (j = 1; j < synthetic_data.ptsno; j++)
			if (synthetic_data.indep[j] > experimental_data.indep[i])
				{
				breaked = 1;
				break;
				}
		if (breaked == 1)
			{
			interpolated_y = synthetic_data.dep[j-1] + (experimental_data.indep[i] - 
			                 synthetic_data.indep[j-1]) / (synthetic_data.indep[j] - 
			                 synthetic_data.indep[j-1]) * (synthetic_data.dep[j] -
			                 synthetic_data.dep[j-1]);

			if ( (type == 0) || (type == 2) ) chi2 += pow (interpolated_y - experimental_data.dep[i], 2);
			if ( (type == 1) || (type == 3) ) chi2 += experimental_data.weight[i] * pow (interpolated_y - experimental_data.dep[i], 2);
			}
		}

	if (type == 0)
		return sqrt (chi2 / (experimental_data.ptsno - 1));
	if (type == 1)
		{
		for (i = 0; i < experimental_data.ptsno; i++)
			weight_sum += experimental_data.weight[i];
		return sqrt (chi2 / (weight_sum - weight_sum / experimental_data.ptsno));
		}
	if (type == 2)
		return chi2 / 2.0 / sigma / sigma;
	if (type == 3)
		{
		for (i = 0; i < experimental_data.ptsno; i++)
			weight_sum += experimental_data.weight[i];
		return chi2 / 2.0 / sigma / sigma / weight_sum;
		}

	return -1.0;
	}

double chi2_cost_function (const gsl_vector *adjpars, void *pars)
	{
	/* This function evaluates chi2 of the O-C difference and returns its value */
	/* to the minimizer. The first passed argument is a simple vector of all    */
	/* parameters that are set for adjustment. The second parameter is the cast */
	/* passed_parameters struct defined below. *pars points to the address of   */
	/* the WD_LCI_parameters struct defined in the main minimizer function,     */
	/* **pointers is an array of pointers to double that point to those ele-    */
	/* ments of *pars which are set for adjustment.                             */

	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;

	int vertices = 100;
	int i, curve;
	PHOEBE_data syn_data;

	double chi2 = 0.0;
	int lcno = (*(passed_parameters *) pars).lcno;
	int rvno = (*(passed_parameters *) pars).rvno;
	double sigma;

	for (curve = 0; curve < lcno + rvno; curve++)
		{
		initialize_memory_for_data (&syn_data);
		allocate_memory_for_data (&syn_data, vertices);

	/* Ready for the mind-boggling line? Here it goes: we cycle the dummy int i */
	/* over all parameters set for adjustment. In every cycle we query the pas- */
	/* sed pointers[] variable, which is an array of pointers to WD_LCI_parame- */
	/* ters variables and assign the value that gsl_vector holds. Basically we  */
	/* overwrite the passed value with the one that the downhill simplex provi- */
	/* des for us. That's all there's to it, but the line looks really messy.   */

		for (i = 0; i < (*(passed_parameters *) pars).to_be_adjusted; i++)
			*(*(passed_parameters *) pars).pointers[curve][i] = gsl_vector_get (adjpars, i);
		create_lci_file ("lcin.active", (*(*(passed_parameters *) pars).pars)[curve]);

		/* Here we differentiate between LC curves and RV curves:                 */
		if (((*(*(passed_parameters *) pars).pars)[curve]).MPAGE == 1)
			call_wd_to_get_fluxes (-0.5, 0.5, (0.5-(-0.5))/vertices, &syn_data);
		if (((*(*(passed_parameters *) pars).pars)[curve]).MPAGE == 2)
			{
			int k;

			if (curve == lcno)
				call_wd_to_get_rv1 (-0.5, 0.5, (0.5-(-0.5))/vertices, &syn_data);
			if (curve == lcno + 1)
				call_wd_to_get_rv2 (-0.5, 0.5, (0.5-(-0.5))/vertices, &syn_data);
			for (k = 0; k < vertices; k++)
				syn_data.dep[k] *= 100.0;
			}

		for (i = 0; i < vertices; i++)
			{
			syn_data.indep[i] = -0.5 + i * (0.5 - (-0.5)) / vertices;
			syn_data.weight[i] = 1.0;
			}

		if (curve < lcno)
			phoebe_get_parameter_value ("phoebe_lc_sigma", curve, &sigma);
		else
			phoebe_get_parameter_value ("phoebe_rv_sigma", curve-lcno, &sigma);

		chi2 += calculate_chi2 (syn_data, exp_data[curve], sigma, 2);

		free_allocated_memory_for_data (&syn_data);
		}

	return chi2;
	}

double siman_chi2_cost_function (void *pars)
	{
	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		double *values;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;

	int vertices = 100;
	int i, curve;
	PHOEBE_data syn_data;

	double chi2 = 0.0;

	for (curve = 0; curve < (*(passed_parameters *) pars).lcno; curve++)
		{
		initialize_memory_for_data (&syn_data);
		allocate_memory_for_data (&syn_data, vertices);

		for (i = 0; i < (*(passed_parameters *) pars).to_be_adjusted; i++)
			*(*(passed_parameters *) pars).pointers[curve][i] = (*(passed_parameters *) pars).values[i];

		create_lci_file ("lcin.active", (*(*(passed_parameters *) pars).pars)[curve]);
		call_wd_to_get_fluxes (-0.5, 0.5, (0.5-(-0.5))/vertices, &syn_data);
		for (i = 0; i < vertices; i++)
			{
			syn_data.indep[i] = -0.5 + i * (0.5 - (-0.5)) / vertices;
			syn_data.weight[i] = 0.0;
			}

		chi2 += calculate_chi2 (syn_data, exp_data[curve], 1.0, 2);
		free_allocated_memory_for_data (&syn_data);
		}

	return chi2;
	}

void siman_step_function (const gsl_rng *r, void *old, double step_size)
	{
	int i;

	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		double *values;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;

  double u;

	for (i = 0; i < (*(passed_parameters *) old).to_be_adjusted; i++)
		{
		u = gsl_rng_uniform (r);
	  (*(passed_parameters *) old).values[i] = u * 2 * step_size - step_size + (*(passed_parameters *) old).values[i];
		}
	}

double siman_metric_function (void *old, void *new)
	{
	int i;

	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		double *values;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;

	double metric = 0.0;

	for (i = 0; i < (*(passed_parameters *) new).to_be_adjusted; i++)
		metric += pow ((*(passed_parameters *) new).values[i] - (*(passed_parameters *) old).values[i], 2);

	metric = sqrt (metric);
	return metric;
	}

void siman_print_function (void *new)
	{
	int i;

	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		double *values;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;

	printf (" (%lf, ", (*(passed_parameters *) new).values[0]);
	for (i = 1; i < (*(passed_parameters *) new).to_be_adjusted - 1; i++)
		printf ("%lf, ", (*(passed_parameters *) new).values[i]);
	printf ("%lf) ", (*(passed_parameters *) new).values[(*(passed_parameters *) new).to_be_adjusted - 1]);
	}

int find_minimum_with_simplex (double accuracy, int iter_no, bool update)
	{
	/****************************************************************************/
	/* This is a GSL simplex function that we use for multi-D minimization. All */
	/* parameters are passed through an array of structs.                       */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*  -9 .. independent variable enumeration readout failed.                  */
	/*  -8 .. dependent variable enumeration readout failed.                    */
	/*  -7 .. weighting variable enumeration readout failed.                    */
	/*  -2 .. experimental data cannot be read in, abort the execution.         */
	/*  -1 .. passed values are invalid, abort the execution.                   */
	/*   0 .. everything ok, simplex converged.                                 */
	/*   1 .. no curves selected for adjustment, nothing to be done.            */
	/*   2 .. no parameters selected for adjustment, nothing to be done.        */
	/*   3 .. simplex reached maximum number of iterations without convergence. */
	/****************************************************************************/

	bool   *switch_states;      /* An array of adjustment switch states.        */
	double *steps;              /* An array of step sizes.                      */
	double *initvals;           /* An array of initial parameter values.        */
	int    *indices;            /* An array of global table reference indices   */
	int     cno, lcno, rvno;    /* Curves (both LC and RV) number.              */
	int     total_adjustables;  /* The number of all adjustables.               */
	int     to_be_adjusted;     /* The number of adjustables to be adjusted.    */
	double ***pointers;         /* Array of pointers to the WD_LCI_parameters   */

	int     curve;

  const gsl_multimin_fminimizer_type *T = gsl_multimin_fminimizer_nmsimplex;
  gsl_multimin_fminimizer *s = NULL;
  gsl_vector *step_size, *adjpars;
  gsl_multimin_function cost_function;

  size_t iter = 0;
	size_t i, j, k;
  int status;
  double size;

	struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		WD_LCI_parameters **pars;
		double ***pointers;
		};
	struct passed_parameters passed_pars;

	WD_LCI_parameters *params;

	phoebe_debug ("entering downhill simplex minimizer.\n");

	/* Count the available curves:                                              */
	lcno = phoebe_get_value_int ("phoebe_lcno_value");
	rvno = phoebe_get_value_int ("phoebe_rvno_value");
	 cno = lcno + rvno;
	phoebe_debug ("total number of curves (both LC and RV): %d\n", lcno + rvno);

	if (cno == 0) return 1;

	/* The following block reads out parameters marked for adjustment:          */
	total_adjustables = read_in_adjustable_parameters (&switch_states, &steps, &initvals, &indices, &to_be_adjusted);
	phoebe_debug ("total number of adjustable parameters: %d\n", total_adjustables);
	phoebe_debug ("total number of parameters to be adjusted: %d\n", to_be_adjusted);
	if (to_be_adjusted == 0) return 2;

	adjpars   = gsl_vector_alloc (to_be_adjusted);
	step_size = gsl_vector_alloc (to_be_adjusted);

	pointers  = phoebe_malloc (cno * sizeof (*pointers));
	for (i = 0; i < cno; i++)
		pointers[i]    = phoebe_malloc (to_be_adjusted * sizeof (**pointers));

	passed_pars.pars = phoebe_malloc (cno * sizeof (*(passed_pars.pars)));
	params           = phoebe_malloc (cno * sizeof (*params));
	exp_data         = phoebe_malloc (cno * sizeof (*exp_data));

	/* First we must read in all data, so that the following segment may se-    */
	/* quentially assign pointers to it:                                        */

	for (curve = 0; curve < lcno; curve++)
		read_in_wd_lci_parameters (&params[curve], /*MPAGE=*/1, /*JDPHS=*/2, curve);
	for (curve = lcno; curve < cno; curve++)
		read_in_wd_lci_parameters (&params[curve], /*MPAGE=*/2, /*JDPHS=*/2, curve-lcno);

	/* Now comes the pointing part:                                             */

	for (curve = 0; curve < cno; curve++)
		{
		j = 0; k = 0;
		for (i = 0; i < total_adjustables; i++)
			if (switch_states[i] == YES)
				{
				gsl_vector_set (adjpars, j, initvals[i]);
				gsl_vector_set (step_size, j, steps[i]);

				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_hjd0_adjust")   == 0) pointers[curve][j] = &(params[curve].HJD0);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_period_adjust") == 0) pointers[curve][j] = &(params[curve].PERIOD);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_dpdt_adjust")   == 0) pointers[curve][j] = &(params[curve].DPDT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_pshift_adjust") == 0) pointers[curve][j] = &(params[curve].PSHIFT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_sma_adjust")    == 0) pointers[curve][j] = &(params[curve].SMA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_rm_adjust")     == 0) pointers[curve][j] = &(params[curve].RM);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_incl_adjust")   == 0) pointers[curve][j] = &(params[curve].INCL);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_vga_adjust")    == 0) pointers[curve][j] = &(params[curve].VGA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_tavh_adjust")   == 0) pointers[curve][j] = &(params[curve].TAVH);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_tavc_adjust")   == 0) pointers[curve][j] = &(params[curve].TAVC);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_phsv_adjust")   == 0) pointers[curve][j] = &(params[curve].PHSV);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_pcsv_adjust")   == 0) pointers[curve][j] = &(params[curve].PCSV);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_logg1_adjust")  == 0) pointers[curve][j] = &(params[curve].LOGG1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_logg2_adjust")  == 0) pointers[curve][j] = &(params[curve].LOGG2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_met1_adjust")   == 0) pointers[curve][j] = &(params[curve].MET1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_met2_adjust")   == 0) pointers[curve][j] = &(params[curve].MET2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_ecc_adjust")    == 0) pointers[curve][j] = &(params[curve].E);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_perr0_adjust")  == 0) pointers[curve][j] = &(params[curve].PERR0);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_dperdt_adjust") == 0) pointers[curve][j] = &(params[curve].DPERDT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_f1_adjust")     == 0) pointers[curve][j] = &(params[curve].F1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_f2_adjust")     == 0) pointers[curve][j] = &(params[curve].F2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_alb1_adjust")   == 0) pointers[curve][j] = &(params[curve].ALB1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_alb2_adjust")   == 0) pointers[curve][j] = &(params[curve].ALB2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_gr1_adjust")    == 0) pointers[curve][j] = &(params[curve].GR1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_gr2_adjust")    == 0) pointers[curve][j] = &(params[curve].GR2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_hla_adjust")    == 0) pointers[curve][j] = &(params[k++].HLA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_cla_adjust")    == 0) pointers[curve][j] = &(params[k++].CLA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_el3_adjust")    == 0) pointers[curve][j] = &(params[k++].EL3);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_opsf_adjust")   == 0) pointers[curve][j] = &(params[k++].OPSF);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_lcx1_adjust")   == 0) pointers[curve][j] = &(params[k++].X1A);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_lcx2_adjust")   == 0) pointers[curve][j] = &(params[k++].X2A);

				j++;
				if (k == lcno) k = 0;
				}

		passed_pars.pars[curve] = &params[curve];

		/* Initialize static experimental data:                                   */
		initialize_memory_for_data (&exp_data[curve]);

		/* Read the data in and do all exception checking rigorously:             */
		if (curve < lcno)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_lc_filename", curve);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_lc_column1", curve));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_lc_column2", curve));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_lc_column3", curve));

			if ( indep == -1) return -9;
			if (   dep == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_TOTAL_FLUX, weight, OUTPUT_UNAVAILABLE);
			}
		if (curve == lcno)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_rv_filename", curve-lcno);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_rv_column1", curve-lcno));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_rv_column2", curve-lcno));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_rv_column3", curve-lcno));

			if (indep  == -1) return -9;
			if (  dep  == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_PRIMARY_RV, weight, OUTPUT_UNAVAILABLE);
			}
		if (curve == lcno+1)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_rv_filename", curve-lcno);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_rv_column1", curve-lcno));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_rv_column2", curve-lcno));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_rv_column3", curve-lcno));

			if (indep  == -1) return -9;
			if (  dep  == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_SECONDARY_RV, weight, OUTPUT_UNAVAILABLE);
			}

		if (status == -1) return -2;
		}

	passed_pars.to_be_adjusted = to_be_adjusted;
	passed_pars.lcno           = lcno;
	passed_pars.rvno           = rvno;
	passed_pars.pointers       = pointers;

  /* Initialize method and iterate */
	cost_function.f      = &chi2_cost_function;
	cost_function.n      = to_be_adjusted;
	cost_function.params = (void *) &passed_pars;

	s = gsl_multimin_fminimizer_alloc (T, to_be_adjusted);
	gsl_multimin_fminimizer_set (s, &cost_function, adjpars, step_size);

	do
		{
		iter++;
		status = gsl_multimin_fminimizer_iterate (s);
      
		if (status) break;

		size = gsl_multimin_fminimizer_size (s);
		status = gsl_multimin_test_size (size, accuracy);

		if (status == GSL_SUCCESS)
			printf ("converged to minimum at\n");
			printf ("%5d ", iter);
			for (i = 0; i < to_be_adjusted; i++)
				printf ("%10.3lf ", gsl_vector_get (s->x, i));
			printf (" chi2 = %7.3f  step = %.3f\n", s->fval, size);
		}
	while (status == GSL_CONTINUE && iter < iter_no);

	/* If the convergence wasn't reached in iter_no steps, gsl minimizer re-    */
	/* turns -2, which conflicts with PHOEBE's way of enumerating exceptions    */
	/* (positive values for non-critical exceptions and negative for fatal      */
	/* ones). Thus we change the exit status to the predefined value 3:         */
	if (status != GSL_CONTINUE && iter == iter_no)
		status = 3;

	gsl_multimin_fminimizer_free (s);

	gsl_vector_free (adjpars);
	gsl_vector_free (step_size);

	for (i = 0; i < cno; i++)
		{
		free (pointers[i]);
		free_allocated_memory_for_data (&exp_data[i]);
		}

	free (switch_states);
	free (steps);
	free (initvals);
	free (indices);

	free (pointers);
	free (params);
	free (exp_data);

	phoebe_debug ("leaving downhill simplex minimizer.\n");

  return status;
	}

int find_minimum_with_siman ()
	{
	/****************************************************************************/
	/* This is a GSL simulated annealing function that we use for multi-D mini- */
	/* mization. All parameters are passed through an array of structs.         */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*   1 .. no curves selected for adjustment, nothing to be done.            */
	/*   2 .. no parameters selected for adjustment, nothing to be done.        */
	/****************************************************************************/

	bool   *switch_states;      /* An array of adjustment switch states.        */
	double *steps;              /* An array of step sizes.                      */
	double *initvals;           /* An array of initial parameter values.        */
	int    *indices;            /* An array of global table reference indices   */
	int     lcno, rvno;         /* The number of curves (both LC and RV)        */
	int     total_adjustables;  /* The number of all adjustables.               */
	int     to_be_adjusted;     /* The number of adjustables to be adjusted.    */
	double ***pointers;         /* Array of pointers to the WD_LCI_parameters   */

	int     curve;
  int status;

	WD_LCI_parameters *params;
	size_t i, j, k;

  const gsl_rng_type *T = gsl_rng_default;
  gsl_rng *r = gsl_rng_alloc (T);

	gsl_siman_params_t siman_params = {N_TRIES, ITERS_FIXED_T, STEP_SIZE, K, T_INITIAL, MU_T, T_MIN};

	typedef struct passed_parameters
		{
		int to_be_adjusted;
		int lcno;
		int rvno;
		double *values;
		WD_LCI_parameters **pars;
		double ***pointers;
		} passed_parameters;
	struct passed_parameters passed_pars;

	phoebe_debug ("entering simulated annealing minimizer.\n");

	/* Count the available curves:                                              */
	lcno = phoebe_get_value_int ("phoebe_lcno_value");
	rvno = phoebe_get_value_int ("phoebe_rvno_value");
	phoebe_debug ("total number of curves (both LC and RV): %d\n", lcno + rvno);

	if (lcno == 0) return 1;

	/* The following block reads out parameters marked for adjustment:          */
	total_adjustables = read_in_adjustable_parameters (&switch_states, &steps, &initvals, &indices, &to_be_adjusted);
	phoebe_debug ("total number of adjustable parameters: %d\n", total_adjustables);
	phoebe_debug ("total number of parameters to be adjusted: %d\n", to_be_adjusted);
	if (to_be_adjusted == 0) return 2;

	pointers  = phoebe_malloc (lcno * sizeof (*pointers));
	for (i = 0; i < lcno; i++)
		pointers[i]    = phoebe_malloc (to_be_adjusted * sizeof (**pointers));

	passed_pars.pars   = phoebe_malloc (lcno * sizeof (*(passed_pars.pars)));
	params             = phoebe_malloc (lcno * sizeof (*params));
	exp_data           = phoebe_malloc (lcno * sizeof (*exp_data));

	passed_pars.values = phoebe_malloc (to_be_adjusted * sizeof (*(passed_pars.values)));

	/* First we must read in all data, so that the following segment may se-    */
	/* quentially assign pointers to it:                                        */

	for (curve = 0; curve < lcno; curve++)
		read_in_wd_lci_parameters (&params[curve], /*MPAGE=*/1, /*JDPHS=*/2, curve);

	/* Now comes the pointing part:                                             */

	for (curve = 0; curve < lcno; curve++)
		{
		j = 0; k = 0;
		for (i = 0; i < total_adjustables; i++)
			if (switch_states[i] == YES)
				{
				passed_pars.values[j] = initvals[i];

				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_hjd0_adjust")   == 0) pointers[curve][j] = &(params[curve].HJD0);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_period_adjust") == 0) pointers[curve][j] = &(params[curve].PERIOD);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_dpdt_adjust")   == 0) pointers[curve][j] = &(params[curve].DPDT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_pshift_adjust") == 0) pointers[curve][j] = &(params[curve].PSHIFT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_sma_adjust")    == 0) pointers[curve][j] = &(params[curve].SMA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_rm_adjust")     == 0) pointers[curve][j] = &(params[curve].RM);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_incl_adjust")   == 0) pointers[curve][j] = &(params[curve].INCL);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_vga_adjust")    == 0) pointers[curve][j] = &(params[curve].VGA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_tavh_adjust")   == 0) pointers[curve][j] = &(params[curve].TAVH);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_tavc_adjust")   == 0) pointers[curve][j] = &(params[curve].TAVC);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_phsv_adjust")   == 0) pointers[curve][j] = &(params[curve].PHSV);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_pcsv_adjust")   == 0) pointers[curve][j] = &(params[curve].PCSV);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_logg1_adjust")  == 0) pointers[curve][j] = &(params[curve].LOGG1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_logg2_adjust")  == 0) pointers[curve][j] = &(params[curve].LOGG2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_met1_adjust")   == 0) pointers[curve][j] = &(params[curve].MET1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_met2_adjust")   == 0) pointers[curve][j] = &(params[curve].MET2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_ecc_adjust")    == 0) pointers[curve][j] = &(params[curve].E);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_perr0_adjust")  == 0) pointers[curve][j] = &(params[curve].PERR0);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_dperdt_adjust") == 0) pointers[curve][j] = &(params[curve].DPERDT);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_f1_adjust")     == 0) pointers[curve][j] = &(params[curve].F1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_f2_adjust")     == 0) pointers[curve][j] = &(params[curve].F2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_alb1_adjust")   == 0) pointers[curve][j] = &(params[curve].ALB1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_alb2_adjust")   == 0) pointers[curve][j] = &(params[curve].ALB2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_gr1_adjust")    == 0) pointers[curve][j] = &(params[curve].GR1);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_gr2_adjust")    == 0) pointers[curve][j] = &(params[curve].GR2);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_hla_adjust")    == 0) pointers[curve][j] = &(params[k++].HLA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_cla_adjust")    == 0) pointers[curve][j] = &(params[k++].CLA);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_el3_adjust")    == 0) pointers[curve][j] = &(params[k++].EL3);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_opsf_adjust")   == 0) pointers[curve][j] = &(params[k++].OPSF);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_lcx1_adjust")   == 0) pointers[curve][j] = &(params[k++].X1A);
				if (strcmp (PHOEBE_parameters[indices[i]].qualifier, "phoebe_lcx2_adjust")   == 0) pointers[curve][j] = &(params[k++].X2A);

				j++;
				if (k == lcno) k = 0;
				}

		passed_pars.pars[curve] = &params[curve];

		/* Initialize static experimental data:                                     */
		initialize_memory_for_data (&exp_data[curve]);

		/* Read the data in and do all exception checking rigorously:             */
		if (curve < lcno)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_lc_filename", curve);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_lc_column1", curve));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_lc_column2", curve));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_lc_column3", curve));

			if (indep  == -1) return -9;
			if (  dep  == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_TOTAL_FLUX, weight, OUTPUT_UNAVAILABLE);
			}
		if (curve == lcno)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_rv_filename", curve-lcno);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_rv_column1", curve-lcno));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_rv_column2", curve-lcno));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_rv_column3", curve-lcno));

			if (indep  == -1) return -9;
			if (  dep  == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_PRIMARY_RV, weight, OUTPUT_UNAVAILABLE);
			}
		if (curve == lcno+1)
			{
			char *file = phoebe_get_value_list_string   ("phoebe_rv_filename", curve-lcno);
			int indep  = get_input_independent_variable ((char *) phoebe_get_value_list_string ("phoebe_rv_column1", curve-lcno));
			int   dep  = get_input_dependent_variable   ((char *) phoebe_get_value_list_string ("phoebe_rv_column2", curve-lcno));
			int weight = get_input_weight               ((char *) phoebe_get_value_list_string ("phoebe_rv_column3", curve-lcno));

			if (indep  == -1) return -9;
			if (  dep  == -1) return -8;
			if (weight == -1) return -7;

			status = read_in_experimental_data (file, &exp_data[curve], indep, OUTPUT_PHASE, dep, OUTPUT_SECONDARY_RV, weight, OUTPUT_UNAVAILABLE);
			}

		if (status == -1) return -2;
		}

	passed_pars.to_be_adjusted = to_be_adjusted;
	passed_pars.lcno           = lcno;
	passed_pars.rvno           = rvno;
	passed_pars.pointers       = pointers;

  gsl_siman_solve (r, &passed_pars, siman_chi2_cost_function, siman_step_function, siman_metric_function, siman_print_function, NULL, NULL, NULL, to_be_adjusted * sizeof (passed_pars), siman_params);

	printf ("  %lf, ", passed_pars.values[0]);
	for (i = 0; i < to_be_adjusted - 1; i++)
		printf ("%lf, ", passed_pars.values[i]);
	printf ("  %lf\n", passed_pars.values[to_be_adjusted - 1]);

	for (i = 0; i < lcno; i++)
		{
		free (pointers[i]);
		free_allocated_memory_for_data (&exp_data[i]);
		}

	free (switch_states);
	free (steps);
	free (initvals);
	free (indices);

	free (pointers);
	free (params);
	free (exp_data);

	phoebe_debug ("leaving simulated annealing minimizer.\n");

	return 0;
	}

#endif
#endif
