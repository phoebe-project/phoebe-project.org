#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "phoebe_build_config.h"
#include "phoebe_global.h"

#include "phoebe_base.h"
#include "phoebe_scripter_ast.h"
#include "phoebe_scripter_grammar.tab.h"

int main (int argc, char *argv[])
	{
	PHOEBE_VERSION_NUMBER = strdup (PHOEBE_RELEASE_NAME);
	PHOEBE_VERSION_DATE = strdup (PHOEBE_RELEASE_DATE);

	variables_init ();
	parse_startup_line (argc, argv);

	if (PHOEBE_args.INTERACTIVE_SCRIPTER_SWITCH == 1)
		{
		phoebe_init ();

		scripter_st_initialize ();
		scripter_initialize ();
		}
	else
		{
		printf ("\n%s\n\n", PHOEBE_RELEASE_NAME);
		printf ("     Thank you for your interest in PHOEBE! Please note that this is the\n");
		printf ("     pre-release and as such it is meant *exclusively* for testing.  The\n");
		printf ("     Graphical User Interface (GUI) is turned off in this version, since\n");
		printf ("     its build process is independent of PHOEBE core (the scripter).\n\n");
		printf ("     Please start PHOEBE scripter by passing the '-s' switch in the com-\n");
		printf ("     mand line!\n\n");
/*
		gtk_set_locale ();
		gtk_init (&argc, &argv);
		phoebe_gui_init ();
		gtk_widget_show (PHOEBE);
		gtk_main ();
*/
		}

	return 0;
	}
