#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <dirent.h>

#include "phoebe_build_config.h"

#include "phoebe_allocations.h"
#include "phoebe_error_handling.h"
#include "phoebe_global.h"

#ifdef HAVE_LIBGSL
#ifndef PHOEBE_GSL_DISABLED

#include <gsl/gsl_errno.h>
#include <gsl/gsl_spline.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_histogram.h>

#endif
#endif

int query_spectra_repository (char *rep_name, PHOEBE_spectrum *spec)
	{
	/* This function queries the passed directory location for spectra; it re-  */
	/* turns the number of spectra found or -1 if the directory failed to open  */
	/* or if it doesn't contain any spectra.                                    */

	DIR *repository = opendir (rep_name);
	struct dirent *filelist;

	int RES, LAMIN, LAMAX, VROT, MET, TEMP, LOGG;
	char METSIGN;

	if (repository == NULL)
		return -1;

	spec->no = 0; spec->prop = NULL;

	while (filelist = readdir (repository))
		{
		if (sscanf (filelist->d_name, "F%4d%dV%d-R%d%c%dT%dG%dK2NOVER.ASC", &LAMIN, &LAMAX, &VROT, &RES, &METSIGN, &MET, &TEMP, &LOGG) != 8) continue;
		if (METSIGN == 'M') MET = -MET;
		spec->no++;
		spec->prop = phoebe_realloc (spec->prop, spec->no * sizeof (*spec->prop));
		spec->prop[spec->no-1].resolution  = RES;
		spec->prop[spec->no-1].lambda_min  = LAMIN;
		spec->prop[spec->no-1].lambda_max  = LAMAX;
		spec->prop[spec->no-1].temperature = TEMP;
		spec->prop[spec->no-1].metallicity = MET;
		spec->prop[spec->no-1].gravity     = LOGG;
		spec->prop[spec->no-1].rotvelocity = VROT;
		}
	closedir (repository);

	return spec->no;
	}

#ifdef HAVE_LIBGSL
#ifndef PHOEBE_GSL_DISABLED

int get_spectrum_from_repository (PHOEBE_data *data, int T, int v, int M, int g, int ll, int ul)
	{
	/* This function queries the spectra repository, takes closest gridded spe- */
	/* ctra from it and linearly interpolates to the spectrum represented by    */
	/* the passed parameters.                                                   */
	/*                                                                          */
	/* Return values:                                                           */
	/*   -1   ..   the defined repository directory cannot be opened, abort.    */

	double RESOLUTION = 50000.0;

	int i;
	int N;
	double q, p;
	int Tlow, Thigh, vlow, vhigh, Mlow, Mhigh, glow, ghigh;
	gsl_histogram *Tlowhist, *Thighhist, *vhighhist, *Mhighhist, *ghighhist;
	gsl_histogram *out;
	double *nodes;
	char filename[255];
	char dummy[255];
	FILE *file;
	double lambda, flux;
	double value;

	double square, minsquare;
	int    minindex;

	PHOEBE_spectrum spec;

	if (query_spectra_repository (PHOEBE_KURUCZ_DIR, &spec) <= 0)
		{
		phoebe_warning ("the Kurucz spectra repository cannot be found. Aborting.\n");
		return -1;
		}

	phoebe_notice ("\nRepository location: %s\n", PHOEBE_KURUCZ_DIR);
	phoebe_notice ("Synthetic spectra in the repository: %d\n\n", spec.no);

	/* Now we have to find the closest match from the grid; we shall use the    */
	/* the least squares for this ;) :                                          */
	minsquare = pow (T - spec.prop[0].temperature, 2) + 
		          pow (M - spec.prop[0].metallicity, 2) +
						  pow (g - spec.prop[0].gravity,     2) +
						  pow (v - spec.prop[0].rotvelocity, 2);

	for (i = 1; i < spec.no; i++)
		{
		square = pow (T - spec.prop[i].temperature, 2) + 
		         pow (M - spec.prop[i].metallicity, 2) +
					   pow (g - spec.prop[i].gravity,     2) +
						 pow (v - spec.prop[i].rotvelocity, 2);
		if (square < minsquare)
			{
			minsquare = square; minindex = i;
			}
		}

	printf ("The closest spectrum is: R=%d at [%d, %d]\n                         T=%d, [M/H]=%d, logg=%d, vrot=%d\n", spec.prop[minindex].resolution, 
		spec.prop[minindex].lambda_min, spec.prop[minindex].lambda_max, spec.prop[minindex].temperature,
		spec.prop[minindex].metallicity, spec.prop[minindex].gravity, spec.prop[minindex].rotvelocity);

	/* Since we now know which is the closest spectrum, let's find the limiting */
	/* values for all parameters:                                               */
	if (T > spec.prop[minindex].temperature)
		{
		Tlow  = spec.prop[minindex].temperature;
		Thigh = 2 * spec.prop[minindex].temperature;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].temperature - spec.prop[minindex].temperature > 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity)        &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[i].temperature - spec.prop[minindex].temperature < Thigh - Tlow)
					Thigh = spec.prop[i].temperature;
		}
	if (T < spec.prop[minindex].temperature)
		{
		Thigh = spec.prop[minindex].temperature;
		Tlow  = spec.prop[minindex].temperature / 2;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].temperature - spec.prop[minindex].temperature < 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity)        &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[minindex].temperature - spec.prop[i].temperature < Thigh - Tlow)
					Tlow = spec.prop[i].temperature;
		}
	if (T == spec.prop[minindex].temperature)
		Thigh = Tlow = spec.prop[minindex].temperature;

	if (M > spec.prop[minindex].metallicity)
		{
		Mlow  = spec.prop[minindex].metallicity;
		Mhigh = 5 + spec.prop[minindex].metallicity;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].metallicity - spec.prop[minindex].metallicity > 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity)        &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[i].metallicity - spec.prop[minindex].metallicity < Mhigh - Mlow)
					Mhigh = spec.prop[i].metallicity;
		}
	if (M < spec.prop[minindex].metallicity)
		{
		Mhigh = spec.prop[minindex].metallicity;
		Mlow  = spec.prop[minindex].metallicity - 5;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].metallicity - spec.prop[minindex].metallicity < 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity)        &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[minindex].metallicity - spec.prop[i].metallicity < Mhigh - Mlow)
					Mlow = spec.prop[i].metallicity;
		}
	if (M == spec.prop[minindex].metallicity)
		Mhigh = Mlow = spec.prop[minindex].metallicity;

	if (g > spec.prop[minindex].gravity)
		{
		glow  = spec.prop[minindex].gravity;
		ghigh = 2 * spec.prop[minindex].gravity;          /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].gravity - spec.prop[minindex].gravity > 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[i].gravity - spec.prop[minindex].gravity < ghigh - glow)
					ghigh = spec.prop[i].gravity;
		}
	if (g < spec.prop[minindex].gravity)
		{
		ghigh = spec.prop[minindex].gravity;
		glow  = spec.prop[minindex].gravity / 2;          /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].gravity - spec.prop[minindex].gravity < 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].rotvelocity == spec.prop[minindex].rotvelocity) )
				if (spec.prop[minindex].gravity - spec.prop[i].gravity < ghigh - glow)
					glow = spec.prop[i].gravity;
		}
	if (g == spec.prop[minindex].gravity)
		ghigh = glow = spec.prop[minindex].gravity;

	if (v > spec.prop[minindex].rotvelocity)
		{
		vlow  = spec.prop[minindex].rotvelocity;
		vhigh = 2 * spec.prop[minindex].rotvelocity;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].rotvelocity - spec.prop[minindex].rotvelocity > 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity    ) )
				if (spec.prop[i].rotvelocity - spec.prop[minindex].rotvelocity < vhigh - vlow)
					vhigh = spec.prop[i].rotvelocity;
		}
	if (v < spec.prop[minindex].rotvelocity)
		{
		vhigh = spec.prop[minindex].rotvelocity;
		vlow  = spec.prop[minindex].rotvelocity / 2;      /* This should suffice! */
		for (i = 0; i < spec.no; i++)
			if ( (spec.prop[i].rotvelocity - spec.prop[minindex].rotvelocity < 0) &&
			     (spec.prop[i].lambda_min  == spec.prop[minindex].lambda_min)     &&
			     (spec.prop[i].lambda_max  == spec.prop[minindex].lambda_max)     &&
			     (spec.prop[i].temperature == spec.prop[minindex].temperature)    &&
			     (spec.prop[i].metallicity == spec.prop[minindex].metallicity)    &&
			     (spec.prop[i].gravity     == spec.prop[minindex].gravity    ) )
				if (spec.prop[minindex].rotvelocity - spec.prop[i].rotvelocity < vhigh - vlow)
					vlow = spec.prop[i].rotvelocity;
		}
	if (v == spec.prop[minindex].rotvelocity)
		vhigh = vlow = spec.prop[minindex].rotvelocity;

	printf ("\n");
	printf ("Temperature range: [%d, %d]\n", Tlow, Thigh);
	printf ("Metallicity range: [%d, %d]\n", Mlow, Mhigh);
	printf ("Gravity range:     [%d, %d]\n", glow, ghigh);
	printf ("RotVelocity range: [%d, %d]\n", vlow, vhigh);

	/* We don't need the grid anymore, so let's free the memory:                */
	free (spec.prop);

	/* We now have all limits, let's read in the data into histograms:          */
	q = (double) (2.0*RESOLUTION+1) / (2.0*RESOLUTION-1);
	p = (double) (ul - ll) / ll;
	N = (int) (log (q - (1-q) * RESOLUTION * p) / log (q));

	nodes = phoebe_malloc (sizeof (double) * (N+1));
	nodes[0] = ll;
	for (i = 1; i <= N; i++)
		nodes[i] = nodes[i-1] + pow (q, i) * ll / RESOLUTION;

	Tlowhist = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (Tlowhist, nodes, N+1);

	if (Mlow >= 0)
		sprintf (filename, "%s/F%d%dV%03d-R20000P%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow,  Mlow, Tlow, glow);
	else
		sprintf (filename, "%s/F%d%dV%03d-R20000M%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow, -Mlow, Tlow, glow);

	if ( (file = fopen (filename, "r")) == NULL )
		{
		printf ("File %s not found! Exiting...\n", filename);
		exit (-1);
		}

	/* Skip the header: */
	fgets (dummy, 255, file); fgets (dummy, 255, file);

	/* Read out all values to the histogram: */
	for (i = 0; i < N; i++)
		{
		fscanf (file, "%lf %lf %*lf %*lf\n", &lambda, &flux);
		gsl_histogram_accumulate (Tlowhist, lambda, flux);
		}
	fclose (file);

	Thighhist = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (Thighhist, nodes, N+1);

	if (Mlow >= 0)
		sprintf (filename, "%s/F%d%dV%03d-R20000P%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow,  Mlow, Thigh, glow);
	else
		sprintf (filename, "%s/F%d%dV%03d-R20000M%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow, -Mlow, Thigh, glow);

	if ( (file = fopen (filename, "r")) == NULL )
		{
		printf ("File %s not found! Exiting...\n", filename);
		exit (-1);
		}
	fgets (dummy, 255, file); fgets (dummy, 255, file);
	for (i = 0; i < N; i++)
		{
		fscanf (file, "%lf %lf %*lf %*lf\n", &lambda, &flux);
		gsl_histogram_accumulate (Thighhist, lambda, flux);
		}
	fclose (file);

	ghighhist = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (ghighhist, nodes, N+1);

	if (Mlow >= 0)
		sprintf (filename, "%s/F%d%dV%03d-R20000P%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow,  Mlow, Tlow, ghigh);
	else
		sprintf (filename, "%s/F%d%dV%03d-R20000M%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vlow, -Mlow, Tlow, ghigh);

	if ( (file = fopen (filename, "r")) == NULL )
		{
		printf ("File %s not found! Exiting...\n", filename);
		exit (-1);
		}
	fgets (dummy, 255, file); fgets (dummy, 255, file);
	for (i = 0; i < N; i++)
		{
		fscanf (file, "%lf %lf %*lf %*lf\n", &lambda, &flux);
		gsl_histogram_accumulate (ghighhist, lambda, flux);
		}
	fclose (file);

	vhighhist = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (vhighhist, nodes, N+1);

	if (Mlow >= 0)
		sprintf (filename, "%s/F%d%dV%03d-R20000P%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vhigh,  Mlow, Tlow, glow);
	else
		sprintf (filename, "%s/F%d%dV%03d-R20000M%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vhigh, -Mlow, Tlow, glow);

	if ( (file = fopen (filename, "r")) == NULL )
		{
		printf ("File %s not found! Exiting...\n", filename);
		exit (-1);
		}
	fgets (dummy, 255, file); fgets (dummy, 255, file);
	for (i = 0; i < N; i++)
		{
		fscanf (file, "%lf %lf %*lf %*lf\n", &lambda, &flux);
		gsl_histogram_accumulate (vhighhist, lambda, flux);
		}
	fclose (file);

	Mhighhist = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (Mhighhist, nodes, N+1);

	if (Mhigh >= 0)
		sprintf (filename, "%s/F%d%dV%03d-R20000P%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vhigh,  Mhigh, Tlow, glow);
	else
		sprintf (filename, "%s/F%d%dV%03d-R20000M%02dT%dG%dK2NOVER.ASC", PHOEBE_KURUCZ_DIR, ll, ul, vhigh, -Mhigh, Tlow, glow);

	if ( (file = fopen (filename, "r")) == NULL )
		{
		printf ("File %s not found! Exiting...\n", filename);
		exit (-1);
		}
	fgets (dummy, 255, file); fgets (dummy, 255, file);
	for (i = 0; i < N; i++)
		{
		fscanf (file, "%lf %lf %*lf %*lf\n", &lambda, &flux);
		gsl_histogram_accumulate (Mhighhist, lambda, flux);
		}
	fclose (file);

	/* That's all there's to it. Now we do the linear interpolation:            */
	out = gsl_histogram_alloc (N);
	gsl_histogram_set_ranges (out, nodes, N+1);

	for (i = 0; i < N; i++)
		{
		value = gsl_histogram_get (Tlowhist, i);
		if (Tlow != Thigh) value += (double)(gsl_histogram_get (Thighhist, i) - gsl_histogram_get (Tlowhist, i)) / (Thigh - Tlow) * (T - Tlow);
		if (vlow != vhigh) value += (double)(gsl_histogram_get (vhighhist, i) - gsl_histogram_get (Tlowhist, i)) / (vhigh - vlow) * (v - vlow);
		if (Mlow != Mhigh) value += (double)(gsl_histogram_get (Mhighhist, i) - gsl_histogram_get (Tlowhist, i)) / (Mhigh - Mlow) * (M - Mlow);
		if (glow != ghigh) value += (double)(gsl_histogram_get (ghighhist, i) - gsl_histogram_get (Tlowhist, i)) / (ghigh - glow) * (g - glow);
		gsl_histogram_accumulate (out, 	0.5 * (nodes[i] + nodes[i+1]), value);
		}

	for (i = 0; i < N; i++)
		{
		data->indep[i]  = 0.5 * (nodes[i] + nodes[i+1]);
		data->dep[i]    = gsl_histogram_get (out, i);
		data->weight[i] = 1.0;
		}

	gsl_histogram_free (Tlowhist);
	gsl_histogram_free (Thighhist);
	gsl_histogram_free (ghighhist);
	gsl_histogram_free (vhighhist);
	gsl_histogram_free (Mhighhist);
	gsl_histogram_free (out);
	free (nodes);
	}

#endif
#endif
