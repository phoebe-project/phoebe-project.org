/* ************************************************************************** */
/*                                                                            */
/*             ADDING NUMERICAL ALGORIGHMS TO PHOEBE_CALCULATIONS             */
/*            ----------------------------------------------------            */
/*                                                                            */
/*                                                                            */
/*   When adding new algorithms to this part of the program, one should use   */
/*   GSL (GNU Scientific Library) if available. Thus definition switches      */
/*   are provided in config.h by which the presence of GSL may be checked:    */
/*   HAVE_LIBGSL and HAVE_LIBGSLCBLAS. Optionally, the user may disable GSL   */
/*   usage although it is installed on his system by the explicit disable     */
/*   switch passed to ./configure: --disable-gsl. In this case the two de-    */
/*   finitions mentioned before remain defined, but also another definition   */
/*   is declared: PHOEBE_GSL_DISABLED. So to properly code the GSL depen-     */
/*   dent algorithm, it is necessary to check against *both* definitions.     */
/*                                                                            */
/* ************************************************************************** */

#include "phoebe_build_config.h"
#include "../include/cfortran.h"

#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "phoebe_allocations.h"
#include "phoebe_calculations.h"
#include "phoebe_error_handling.h"
#include "phoebe_global.h"

PROTOCCALLSFFUN5(VOID,WDGETCURVE,wdgetcurve,INT,DOUBLE,DOUBLE,DOUBLE,DOUBLEV)
#define WD_GET_CURVE(MODE,PHS,PHE,VER,FLUXES) CCALLSFFUN5(WDGETCURVE,wdgetcurve,INT,DOUBLE,DOUBLE,DOUBLE,DOUBLEV,MODE,PHS,PHE,VER,FLUXES)

void call_wd_to_get_fluxes (double phase_start, double phase_end, double phase_step, PHOEBE_data *data)
	{
	WD_GET_CURVE (1, phase_start, phase_end, phase_step, data->dep);
	}

void call_wd_to_get_rv1 (double phase_start, double phase_end, double phase_step, PHOEBE_data *data)
	{
	WD_GET_CURVE (2, phase_start, phase_end, phase_step, data->dep);
	}

void call_wd_to_get_rv2 (double phase_start, double phase_end, double phase_step, PHOEBE_data *data)
	{
	WD_GET_CURVE (3, phase_start, phase_end, phase_step, data->dep);
	}

double calculate_phsv_value (int ELLIPTIC, double D, double q, double r, double F, double lambda, double nu)
	{
	/* This function calculates the modified Kopal gravity potential. If the    */
	/* ELLIPTIC switch is turned off, the calculation is simpler.               */

	if (ELLIPTIC == 0)
		return 1./r + q*pow(D*D+r*r,-0.5) + 0.5*(1.+q)*r*r;
	else
		return 1./r + q*(pow(D*D+r*r-2*r*lambda*D,-0.5)-r*lambda/D/D) + 0.5*F*F*(1.+q)*r*r*(1-nu*nu);
	}
	
double calculate_pcsv_value (int ELLIPTIC, double D, double q, double r, double F, double lambda, double nu)
	{
	/* This function calculates the modified Kopal gravity potential of the se- */
	/* condary star by transforming the origin of space and calling the calcu-  */
	/* lation procedure for the primary star potential.                         */

	double phsv;

	/* We changed the coordinate system, thus q -> 1/q:                         */
	q = 1./q;

	if (ELLIPTIC == 0)
		phsv = calculate_phsv_value (0, D, q, r, 0, 0, 0);
	else
		phsv = calculate_phsv_value (1, D, q, r, F, lambda, nu);

	return phsv/q + 0.5 * (q-1)/q;
	}

int calculate_critical_potentials (double q, double F, double e, double *L1crit, double *L2crit)
	{
	/* This function calculates the value of the gravitational potential \Omega */
	/* (PHSV) in Lagrange points L1 and L2.                                     */
	/*                                                                          */
	/* Input parameters:                                                        */
	/*                                                                          */
	/*   q .. mass ratio                                                        */
	/*   F .. synchronicity parameter                                           */
	/*   e .. eccentricity                                                      */
	/*                                                                          */
	/* Output parameters:                                                       */
	/*                                                                          */
	/*   L1crit .. L1 potential value                                           */
	/*   L2crit .. L2 potential value                                           */

	double D = 1.0 - e;
	double  xL = 0.5;                             /* Initial x coordinate value */
	double dxL = 1.1e-6;                          /* Initial x coordinate step  */
	double Force;                                 /* Gravitational force        */
	double dxLdF;                                 /* Spatial derivative         */

	double xL1;                                   /* L1 x coordinate            */
	double xL2;                                   /* L2 x coordinate            */

	double q2;
	double factor;

	/* First L1: we iterate to the point of accuracy better than 1e-6:          */

	while (fabs(dxL) > 1e-6)
		{
		xL = xL + dxL;
		Force = F*F*(q+1)*xL - 1.0/xL/xL - q*(xL-D)/fabs(pow(D-xL,3)) - q/D/D;
		dxLdF  = 1.0/(F*F*(q+1) + 2.0/xL/xL/xL + 2*q/fabs(pow(D-xL,3)));
		dxL = -Force * dxLdF;
		}
	xL1 = xL;
	*L1crit = calculate_phsv_value (1, D, q, xL1, F, 1.0, 0.0);

	/* Next, L2: we have to make sure that L2 is properly defined, i.e. behind  */
	/* the lower mass star, and that it makes sense to calculate it only in     */
	/* synchronous rotation and circular orbit case:                            */

	if (q > 1.0) q2 = 1.0/q; else q2 = q;
	D = 1.0; F = 1.0; dxL = 1.1e-6;

	factor = pow (q2/3/(q2+1), 1./3.);
	xL = 1 + factor + 1./3. * factor*factor + 1./9. * factor*factor*factor;
	while (fabs(dxL) > 1e-6)
		{
		xL = xL + dxL;
		Force = F*F*(q2+1)*xL - 1.0/xL/xL - q2*(xL-D)/fabs(pow(D-xL,3)) - q2/D/D;
		dxLdF  = 1.0/(F*F*(q2+1) + 2.0/xL/xL/xL + 2*q2/fabs(pow(D-xL,3)));
		dxL = -Force * dxLdF;
		}
	if (q > 1.0) xL = D - xL;
	xL2 = xL;
	*L2crit = 1.0/fabs(xL2) + q*(1.0/fabs(xL2-1)-xL2) + 1./2.*(q+1)*xL2*xL2;
	}

int compare_doubles (const void *a, const void *b)
	{
	/* This function is called by the sorting algorithm to compare two doubles. */

	const double *da = (const double *) a;
	const double *db = (const double *) b;

	return (*da > *db) - (*da < *db);
	}

double calculate_median (PHOEBE_data data)
	{
	/* This function calculates the median by first sorting the data and then   */
	/* taking the value of the mid-index of the array.                          */

	/* Since we'll be modifying the array, we must make a copy (really!):       */
	double *copy;
	double median;
	int i;

	if (data.ptsno < 1) return -1.0;

	copy = phoebe_malloc (data.ptsno * sizeof (*copy));
	for (i = 0; i < data.ptsno; i++)
		copy[i] = data.dep[i];

	qsort (copy, data.ptsno, sizeof (double), compare_doubles);

	if (data.ptsno % 2 == 0) median = copy[data.ptsno/2];
	else median = 0.5*(copy[data.ptsno/2]+copy[data.ptsno/2+1]);
	
	free (copy);
	return median;
	}

double calculate_sum (PHOEBE_data data)
	{
	/* This function calculates the sum of all values in the array.             */

	int i;
	double sum = 0.0;

	if (data.ptsno < 1) return -1.0;
	
	for (i = 0; i < data.ptsno; i++)
		sum += data.dep[i];
	
	return sum;
	}

double calculate_average (PHOEBE_data data)
	{
	/* This function calculates the average of the values in the array.         */

	if (data.ptsno < 1) return -1.0;

	return calculate_sum (data) / data.ptsno;
	}

double calculate_phase_from_ephemeris (double hjd, double hjd0, double period, double dpdt, double pshift)
	{
	/* This function transforms heliocentric julian date (HJD) with given ori-  */
	/* gin HJD0, period P, time derivative DPDT and phase shift PSHIFT to phase */
	/* on interval [-0.5,0.5].                                                  */

	double phase;

	if (dpdt < 1E-15) phase = pshift + fmod ((hjd-hjd0)/period, 1.0);
	else              phase = pshift + fmod (1.0/dpdt * log (period+dpdt*(hjd-hjd0)), 1.0);

	/* If HJD0 is larger than HJD, then the difference is negative and we       */
	/* must fix that:                                                           */
	if (phase < 0.0) phase += 1.0;

	/* Now we have the phase interval [0,1], but we want [-0.5, 0.5]:           */
	if (phase > 0.5) phase -= 1.0;

	return phase;
	}

int transform_hjd_to_phase (PHOEBE_data *data, double hjd0, double period, double dpdt, double pshift)
	{
	/* This function transforms heliocentric Julian dates within the in data    */
	/* vector to phases according to the ephemeris parameters. The return value */
	/* is the number of successful transformations.                             */

	int i;
	
	for (i = 0; i < data->ptsno; i++)
		data->indep[i] = calculate_phase_from_ephemeris (data->indep[i], hjd0, period, dpdt, pshift);

	return i+1;
	}

int transform_magnitude_to_flux (PHOEBE_data *data, double mnorm)
	{
	/* This function transforms dependent data contents from magnitudes to flux */
	/* with respect to the user-defined mnorm value (from the Data tab).        */

	int i;

	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = pow (10, -2./5. * (data->dep[i] - mnorm));
	
	return i+1;
	}

int transform_flux_to_magnitude (PHOEBE_data *data, double mnorm)
	{
	/* This function transforms dependent data contents from flux to magnitudes */
	/* with respect to the user-defined mnorm value (from the Data tab).        */

	int i;

	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = mnorm - 5./2. * log10 (data->dep[i]);

	return i+1;
	}

void alias_phase_to_interval (PHOEBE_data *data, double phmin, double phmax)
	{
	/* This function redimensiones the array of data phases by aliasing points  */
	/* to outside the [-0.5, 0.5] range. If the new interval is narrower, the   */
	/* points are omitted, otherwise they are aliased.                          */

	int i, j;
	PHOEBE_data new_data;
	
	/* Make a new array record to keep the original array, since it will be mo- */
	/* dified in the end:                                                       */
	initialize_memory_for_data (&new_data);
	allocate_memory_for_data (&new_data, data->ptsno);
	memcpy (new_data.indep,  data->indep,  data->ptsno * sizeof (double));
	memcpy (new_data.dep,    data->dep,    data->ptsno * sizeof (double));
	memcpy (new_data.weight, data->weight, data->ptsno * sizeof (double));
	free_allocated_memory_for_data (data);

	initialize_memory_for_data (data);
	/* Now make a loop that does the actual aliasing:                           */
	for (i = 0; i < new_data.ptsno; i++)
		{
		for (j = (int) (phmin - 1); j <= (int) (phmax + 1); j++)
			{
			if ( (new_data.indep[i] + j > phmin) && (new_data.indep[i] + j < phmax) )
				{
				data->ptsno++;
				data->indep  = phoebe_realloc (data->indep,  data->ptsno * sizeof (*data->indep));
				data->dep    = phoebe_realloc (data->dep,    data->ptsno * sizeof (*data->dep));
				data->weight = phoebe_realloc (data->weight, data->ptsno * sizeof (*data->weight));
				data->indep[data->ptsno-1]  = new_data.indep[i] + j;
				data->dep[data->ptsno-1]    = new_data.dep[i];
				data->weight[data->ptsno-1] = new_data.weight[i];
				}
			}
		}

	/* Free the temporary array record:                                         */
	free_allocated_memory_for_data (&new_data);
	}

void bin_data (PHOEBE_data *data, int bin_no)
	{
	int i, j;

	double bin_step;
	int bin, empty_count;

	PHOEBE_data src;

	/* First, let's copy the contents of data to the newly allocated src:       */
	initialize_memory_for_data (&src);
	allocate_memory_for_data (&src, data->ptsno);
	memcpy (src.indep,  data->indep,  data->ptsno * sizeof (double));
	memcpy (src.dep,    data->dep,    data->ptsno * sizeof (double));
	memcpy (src.weight, data->weight, data->ptsno * sizeof (double));

	/* Now reallocate memory to data so it contains only binned values:         */
	free_allocated_memory_for_data (data);
	allocate_memory_for_data (data, bin_no);

	/* We take such a step that the binned range is from phase -0.5 + step/2    */
	/* to 0.5 - step/2, so it is not merely an OB1 error:                       */
	bin_step = ( 0.5 - (-0.5) ) / bin_no;
	for (i = 0; i < bin_no; i++)
		{
		data->indep[i] = -0.5 + (1./2. + i) * bin_step;
		data->dep[i]   = data->weight[i] = 0.0;
		}

	/* Binning of points: */
	for (i = 0; i < src.ptsno; i++)
		{
		bin = (int) ((src.indep[i] - (-0.5)) * bin_no / (0.5 - (-0.5)));
		if ( bin == bin_no ) bin = bin_no - 1; /* This takes care of 0.50000 phase. */
		data->dep[bin] += src.dep[i];
		data->weight[bin] += 1.0;           /* We are using .weight for counting. */
		}

	/* Let's get a bin average over all binned values. If there are no points   */
	/* in a particular bin, we set it to zero and discard it later:             */
	for (i = 0; i < bin_no; i++)
		{
		if (data->weight[i] != 0) data->dep[i] /= data->weight[i];
	                       else data->dep[i] = 0.0;
		}

	/* The idea now is to discard all empty bins, since they serve no purpose:  */
	empty_count = 0;
	for (i = 0; i < bin_no - empty_count; i++)
		{
		if (data->weight[i] < 0.1)      /* Actually, == 0, but just to be safe... */
			{
			for (j = i; j < bin_no - empty_count; j++)
				{
				data->indep[j]  = data->indep[j+1];
				data->dep[j]    = data->dep[j+1];
				data->weight[j] = data->weight[j+1];
				}
			empty_count++;
			/* If there are two consecutive empty bins, this takes care of it:      */
			i--;
			}
		}
	data->ptsno = bin_no - empty_count;

	/* Finally, free the copy of original data:                                 */
	free_allocated_memory_for_data (&src);
	}

void shift_data (PHOEBE_data *data, double shift)
	{
	int i;
	
	for (i = 0; i < data->ptsno; i++)
		data->dep[i] += shift;
	}

void calculate_main_sequence_parameters (double T1, double T2, double P0, double *L1, double *L2, double *M1, double *M2, double *q, double *a, double *R1, double *R2, double *Omega1, double *Omega2)
	{
	/* This is the table of conversions between the surface temperature T and   */
	/* luminosity L (expressed in solar luminosity), ref. Carroll & Ostlie      */
	/* (1996):                                                                  */
	double TL[46][2] =
		{
		{44500, 790000.0}, {41000, 420000.0}, {38000, 260000.0}, {35800, 170000.0},
		{33000,  97000.0}, {30000,  52000.0}, {25400,  16000.0}, {22000,   5700.0},
		{18700,   1900.0}, {15400,    830.0}, {14000,    500.0}, {13000,    320.0},
		{11900,    180.0}, {10500,     95.0}, { 9520,     54.0}, { 9230,     35.0},
		{ 8970,     26.0}, { 8720,     21.0}, { 8200,     14.0}, { 7850,     10.5},
		{ 7580,      8.6}, { 7200,      6.5}, { 6890,      3.2}, { 6440,      2.9},
		{ 6200,      2.1}, { 6030,      1.5}, { 5860,      1.1}, { 5780,      1.0},
		{ 5670,     0.79}, { 5570,     0.66}, { 5250,     0.42}, { 5080,     0.37},
		{ 4900,     0.29}, { 4730,     0.26}, { 4590,     0.19}, { 4350,     0.15},
		{ 4060,     0.10}, { 3850,    0.077}, { 3720,    0.061}, { 3580,    0.045},
		{ 3470,    0.036}, { 3370,    0.019}, { 3240,    0.011}, { 3050,   0.0053},
		{ 2940,   0.0034}, { 2640,   0.0012}
		};
	double Tsun = 5780;
	double Rsun = 696000000;
	double Msun = 1.99E30;
	double G    = 6.67E-11;

	int i;

	/* First step: let's check whether supplied temperatures are OK:            */
	if ( (T1 > TL[0][0]) || (T1 < TL[45][0]) )
		{
		phoebe_warning ("Temperature T1 out of range!\n");
		return;
		}
	if ( (T2 > TL[0][0]) || (T2 < TL[45][0]) )
		{
		phoebe_warning ("Temperature T2 out of range!\n");
		return;
		}
	
	/* Second step: let's find both luminosities from the T-L table:            */
	i = 0; while (T1 < TL[i][0]) i++;
	*L1 = TL[i][1] + (T1-TL[i][0]) / (TL[i-1][0]-TL[i][0]) * (TL[i-1][1]-TL[i][1]);
	i = 0; while (T2 < TL[i][0]) i++;
	*L2 = TL[i][1] + (T2-TL[i][0]) / (TL[i-1][0]-TL[i][0]) * (TL[i-1][1]-TL[i][1]);

	/* Third step: let's calculate the masses and the mass ratio:               */
	*M1 = pow (*L1, 1./3.5); *M2 = pow (*L2, 1./3.5); *q = *M2 / *M1;

	/* Forth step: let's calculate semi-major axis:                             */
	*a = pow (G*(*M1+*M2)*Msun * pow (P0*24.*3600.,2) / 4. / M_PI / M_PI, 1./3.) / Rsun;

	/* Fifth step: let's calculate the radii:                                   */
	*R1 = pow (*L1, 1./2.) * pow (T1/Tsun, -2.);
	*R2 = pow (*L2, 1./2.) * pow (T2/Tsun, -2.);

	/* Sixth step: let's calculate the potentials:                              */
	*Omega1 = calculate_phsv_value (0, 1, *q, *R1 / *a, 1.0, 1.0, 0.0);
	*Omega2 = calculate_pcsv_value (0, 1, *q, *R2 / *a, 1.0, 1.0, 0.0);

	/* That's all. Goodbye!                                                     */
	return;
	}

double calculate_synthetic_scatter_seed ()
	{
	srand (time (0));
	return 100000001.0 + (double) rand () / RAND_MAX * 100000000.0;
	}

double calculate_interstellar_reddening_correction (double lambda, double R, double EBV, int output_type)
	{
	/* This function calculates the reddening coefficient A_\lambda following   */
	/* the Allen's Astrophysical Quantities 3rd Ed., pg. 264. Since the input   */
	/* could be both flux or magnitudes, output_type parameter is supplied:     */
	/*   0 .. flux                                                              */
	/*   1 .. magnitude                                                         */

	double extinction = R * EBV * 0.68 * (1000./lambda - 0.35);
	
	if (output_type == 1) return extinction;
	if (output_type == 0) return pow (10, -2./5. * extinction);
	}

double intern_interstellar_extinction_coefficient_a (double lambda)
	{
	double a;
	double x = 10000./lambda;
	double y = x - 1.82;

	if (lambda >= 1700.0 && lambda < 3030.0)
		a = 1.752 - 0.316*x - 0.104/(pow(x-4.67,2)+0.341);
	if (lambda >= 3030.0 && lambda < 9091.0)
		a = 1.0 + 0.17699*y - 0.50447*pow(y,2) - 0.02427*pow(y,3) + 0.72085*pow(y,4)
	                      + 0.01979*pow(y,5) - 0.77530*pow(y,6) + 0.32999*pow(y,7);
	if (lambda >= 9091.0 && lambda < 33330.0)
		a = 0.574 * pow (x, 1.61);
	
	return a;
	}

double intern_interstellar_extinction_coefficient_b (double lambda)
	{
	double b;
	double x = 10000./lambda;
	double y = x - 1.82;

	if (lambda >= 1700.0 && lambda < 3030.0)
		b = -3.090 + 1.825*x + 1.206/(pow(x-4.62,2)+0.263);
	if (lambda >= 3030.0 && lambda < 9091.0)
		b = 1.41338*pow(y,1) + 2.28305*pow(y,2) + 1.07233*pow(y,3) - 5.38434*pow(y,4)
                         - 0.62251*pow(y,5) + 5.30260*pow(y,6) - 2.09002*pow(y,7);
	if (lambda >= 9091.0 && lambda < 33330.0)
		b = -0.527 * pow (x, 1.61);
	
	return b;
	}

int apply_interstellar_extinction_correction (PHOEBE_data *data, double R, double E)
	{
	/* This function takes the spectrum 'data' and applies the reddening based  */
	/* on the extinction coefficient 'R' and the color excess 'E'.              */

	int i;

	for (i = 0; i < data->ptsno; i++)
		data->dep[i] = data->dep[i] / pow (10.0, 2./5.*R*E*(intern_interstellar_extinction_coefficient_a (data->dep[i]) + intern_interstellar_extinction_coefficient_b (data->dep[i])/R));

	return 0;
	}
