#include "phoebe_global.h"
#include "phoebe_scripter_grammar.h"

#define scripter_symbol_table_size   97
#define scripter_stack_length        1000

typedef enum
	{
	kind_block,
	kind_system_call,
	kind_add,
	kind_sub,
	kind_mul,
	kind_div,
	kind_pot,
	kind_unaryp,
	kind_unarym,
	kind_equal,
	kind_nequal,
	kind_lequal,
	kind_gequal,
	kind_less,
	kind_greater,
	kind_and,
	kind_or,
	kind_not,
	kind_inc,
	kind_dec,
	kind_incby,
	kind_decby,
	kind_multby,
	kind_divby,
	kind_concat,
	kind_set,
	kind_define,
	kind_print,
	kind_calc,
	kind_if,
	kind_ifelse,
	kind_while,
	kind_for,
	kind_func,
	kind_builtin,
	kind_command,
	kind_qual_value,
	kind_ignore
	} scripter_ast_kind;

typedef struct scripter_ast
	{
  enum
		{
		ast_int,
		ast_double,
		ast_bool,
		ast_string,
		ast_variable,
		ast_function,
		ast_node
		} type;
  union
		{
		int    integer;
		double real;
		bool   boolean;
		char  *variable;
		char  *function;
		char  *string;
		struct
			{
			scripter_ast_kind         kind;
			struct scripter_ast_list *args;
			}    node;
		} value;
	} scripter_ast;

typedef struct scripter_ast_list
	{ 
	scripter_ast *elem;
	struct scripter_ast_list *next;
	} scripter_ast_list;

typedef struct scripter_ast_value
	{
	enum
		{
		type_int,
		type_bool,
		type_double,
		type_string,
		type_void,
		} type;
	anytype value;
	} scripter_ast_value;

scripter_ast      *scripter_ast_add_int          (const int val);
scripter_ast      *scripter_ast_add_double       (const double val);
scripter_ast      *scripter_ast_add_bool         (const bool val);
scripter_ast      *scripter_ast_add_string       (const char *val);
scripter_ast      *scripter_ast_add_literal      (const char *val);
scripter_ast      *scripter_ast_add_variable     (const char *val);
scripter_ast      *scripter_ast_add_function     (const char *val);
scripter_ast      *scripter_ast_add_node         (const scripter_ast_kind kind, scripter_ast_list *args);
scripter_ast_list *scripter_ast_construct_list   (scripter_ast *ast, scripter_ast_list *list);
scripter_ast_list *scripter_ast_reverse_list     (scripter_ast_list *r, scripter_ast_list *s);
int                scripter_ast_list_length      (scripter_ast_list *in);
scripter_ast_value scripter_ast_evaluate         (scripter_ast *in);

int                scripter_scope_level;

void               scripter_ast_flow_begin_scope ();
void               scripter_ast_flow_end_scope ();

void scripter_ast_print_list (scripter_ast_list *in);
void scripter_ast_print (scripter_ast *in);

/* **********  This part of the code describes the Symbol Table:  *********** */

typedef struct scripter_symbol
	{
	char                   *name;
	scripter_ast           *link;
	struct scripter_symbol *next;
	} scripter_symbol;

scripter_symbol *scripter_st[scripter_symbol_table_size]; /* 97 */

void             scripter_st_initialize           ();

int scripter_stack[scripter_stack_length]; /* 1000 */
int scripter_stack_size;

long             scripter_st_identifier_hash      (const char *id);
void             scripter_st_identifier_assign    (const char *id, const double value);
void             scripter_st_identifier_insert    (const char *id, scripter_ast *ast);
scripter_symbol *scripter_st_identifier_lookup    (const char *id);

void             scripter_st_user_function_insert (const char *id, scripter_ast *ast);
