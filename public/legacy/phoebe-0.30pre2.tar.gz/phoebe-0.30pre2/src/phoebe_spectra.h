#ifndef PHOEBE_SPECTRA_H
	#define PHOEBE_SPECTRA_H 1

int query_spectra_repository ();

#ifdef HAVE_LIBGSL
#ifndef PHOEBE_GSL_DISABLED
int get_spectrum_from_repository (PHOEBE_data *data, int T, int v, int M, int g, int ll, int ul);
#endif
#endif


#endif
