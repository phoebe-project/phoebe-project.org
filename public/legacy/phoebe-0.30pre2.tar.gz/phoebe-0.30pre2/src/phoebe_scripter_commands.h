#ifndef PHOEBE_SCRIPTER_COMMANDS_H
	#define PHOEBE_SCRIPTER_COMMANDS_H 1

int    scripter_minimize_using_simplex    (scripter_ast_list *args);
int    scripter_compute_lc                (scripter_ast_list *args);
int    scripter_compute_rv                (scripter_ast_list *args);
int    scripter_open_keyword_file         (scripter_ast_list *args);
int    scripter_save_keyword_file         (scripter_ast_list *args);
int    scripter_set_parameter_value       (scripter_ast_list *args);
int    scripter_get_parameter_value       (scripter_ast_list *args);
int    scripter_create_wd_lci_file        (scripter_ast_list *args);

#endif
