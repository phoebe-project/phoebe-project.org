#ifndef PHOEBE_CALCULATIONS_H
	#define PHOEBE_CALCULATIONS_H 1

#include "phoebe_global.h"

void call_wd_to_get_fluxes (double phase_start, double phase_end, double phase_step, PHOEBE_data *data);
void call_wd_to_get_rv1    (double phase_start, double phase_end, double phase_step, PHOEBE_data *data);
void call_wd_to_get_rv2    (double phase_start, double phase_end, double phase_step, PHOEBE_data *data);

double calculate_phsv_value (int ELLIPTIC, double D, double q, double r, double F, double lambda, double nu);
double calculate_pcsv_value (int ELLIPTIC, double D, double q, double r, double F, double lambda, double nu);
int    calculate_critical_potentials (double q, double F, double e, double *L1crit, double *L2crit);

int    compare_doubles (const void *a, const void *b);

double calculate_median (PHOEBE_data data);
double calculate_sum (PHOEBE_data data);
double calculate_average (PHOEBE_data data);
double calculate_phase_from_ephemeris (double hjd, double hjd0, double period, double dpdt, double pshift);

int    transform_hjd_to_phase      (PHOEBE_data *data, double hjd0, double period, double dpdt, double pshift);
int    transform_magnitude_to_flux (PHOEBE_data *data, double mnorm);
int    transform_flux_to_magnitude (PHOEBE_data *data, double mnorm);

void   alias_phase_to_interval    (PHOEBE_data *data, double phmin, double phmax);
void   bin_data                   (PHOEBE_data *data, int bin_no);
void   shift_data                 (PHOEBE_data *data, double shift);

void   calculate_main_sequence_parameters (double T1, double T2, double P0,
			  double *L1, double *L2, double *M1, double *M2, double *q, double *a,
			  double *R1, double *R2, double *Omega1, double *Omega2);

double calculate_synthetic_scatter_seed ();

double calculate_interstellar_reddening_correction (double lambda, double R, double EBV, int output_type);
int    apply_interstellar_extinction_correction (PHOEBE_data *data, double R, double E);

#endif
