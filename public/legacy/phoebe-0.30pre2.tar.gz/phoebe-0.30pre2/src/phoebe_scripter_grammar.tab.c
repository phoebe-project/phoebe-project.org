/* A Bison parser, made from phoebe_scripter_grammar.y
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

# define	INTEGER	257
# define	BOOLEAN	258
# define	VALUE	259
# define	IDENT	260
# define	LITERAL	261
# define	FUNCTION	262
# define	SYSTEM_CALL	263
# define	COMMAND	264
# define	HELP	265
# define	CALC	266
# define	SET	267
# define	DEFINE	268
# define	IF	269
# define	ELSE	270
# define	PRINT	271
# define	QUIT	272
# define	WHILE	273
# define	FOR	274
# define	START_BLOCK	275
# define	END_BLOCK	276
# define	OPEN_KEYWORD_FILE	277
# define	SAVE_KEYWORD_FILE	278
# define	SET_PARAMETER_VALUE	279
# define	GET_PARAMETER_VALUE	280
# define	COMPUTE_LC	281
# define	COMPUTE_RV	282
# define	CREATE_WD_LCI_FILE	283
# define	MINIMIZE_USING_SIMPLEX	284
# define	EQ	285
# define	NEQ	286
# define	LEQ	287
# define	LE	288
# define	GEQ	289
# define	GR	290
# define	INC	291
# define	DEC	292
# define	INCBY	293
# define	DECBY	294
# define	MULTBY	295
# define	DIVBY	296
# define	AND	297
# define	OR	298
# define	NEG	299

#line 7 "phoebe_scripter_grammar.y"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <math.h>

#include "phoebe_global.h"
#include "phoebe_error_handling.h"

#include "phoebe_scripter_ast.h"
#include "phoebe_scripter_grammar.h"
#include "phoebe_scripter_grammar.tab.h"
#include "phoebe_scripter_directives.h"

/*int yydebug=1;*/

bool scripter_print_prompt = TRUE;

#line 28 "phoebe_scripter_grammar.y"
#ifndef YYSTYPE
typedef union
  {
  bool                      swc;	/* Switch                                 */
  int                       idx;	/* Index                                  */
  double                    val;	/* Double-precision value                 */
  char                     *str;	/* String (literal or a variable)         */
  struct scripter_ast      *ast;	/* Abstract Syntax Tree leaf              */
  struct scripter_ast_list *lst;	/* AST arguments list                     */
  } yystype;
# define YYSTYPE yystype
# define YYSTYPE_IS_TRIVIAL 1
#endif
#ifndef YYDEBUG
# define YYDEBUG 1
#endif



#define	YYFINAL		223
#define	YYFLAG		-32768
#define	YYNTBASE	58

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 299 ? yytranslate[x] : 90)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      53,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    43,     2,     2,     2,     2,     2,     2,
      54,    55,    49,    48,    57,    47,     2,    50,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    56,
       2,    46,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,    52,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    44,    45,    51
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     1,     4,     6,     8,    10,    12,    14,    16,
      18,    20,    22,    24,    26,    28,    30,    32,    34,    37,
      39,    40,    44,    45,    50,    52,    55,    59,    62,    64,
      70,    82,    87,    92,    99,   108,   115,   124,   131,   140,
     149,   154,   167,   180,   185,   190,   193,   201,   203,   207,
     209,   212,   215,   218,   222,   226,   228,   230,   236,   244,
     246,   248,   250,   252,   254,   256,   258,   262,   266,   268,
     270,   272,   274,   276,   280,   282,   286,   290,   294,   298,
     302,   305,   308,   312,   316,   320,   324,   328,   332,   336,
     340,   343,   348,   353,   357,   359,   362,   365,   369,   373,
     377
};
static const short yyrhs[] =
{
      -1,    58,    59,     0,     1,     0,    60,     0,    62,     0,
      53,     0,    66,     0,    67,     0,    71,     0,    72,     0,
      75,     0,    78,     0,    76,     0,    70,     0,    68,     0,
      69,     0,    65,     0,    61,    60,     0,    60,     0,     0,
      21,    63,    22,     0,     0,    21,    64,    61,    22,     0,
       9,     0,    11,    53,     0,    11,    11,    53,     0,    11,
      79,     0,    18,     0,    19,    54,    87,    55,    62,     0,
      20,    54,    79,    46,    87,    56,    87,    56,    89,    55,
      62,     0,    23,    54,    84,    55,     0,    24,    54,    84,
      55,     0,    25,    54,    79,    57,    87,    55,     0,    25,
      54,    79,    57,    87,    57,    87,    55,     0,    25,    54,
      79,    57,    83,    55,     0,    25,    54,    79,    57,    83,
      57,    87,    55,     0,    26,    54,    79,    57,    79,    55,
       0,    26,    54,    79,    57,    79,    57,    87,    55,     0,
      29,    54,    84,    57,    87,    57,    87,    55,     0,    30,
      54,    88,    55,     0,    27,    54,    83,    57,    87,    57,
      87,    57,    87,    57,    87,    55,     0,    28,    54,    83,
      57,    87,    57,    87,    57,    87,    57,    87,    55,     0,
      13,    79,    46,    87,     0,    13,    79,    46,    85,     0,
      13,    89,     0,    14,    79,    54,    74,    55,    46,    87,
       0,    79,     0,    74,    57,    73,     0,    73,     0,    12,
      87,     0,    12,    83,     0,    17,    77,     0,    77,    57,
      83,     0,    77,    57,    87,     0,    87,     0,    83,     0,
      15,    54,    87,    55,    62,     0,    15,    54,    87,    55,
      62,    16,    62,     0,     6,     0,     3,     0,     5,     0,
       4,     0,     7,     0,    83,     0,    79,     0,    85,    48,
      83,     0,    85,    48,    87,     0,    83,     0,     8,     0,
      80,     0,    81,     0,    82,     0,    54,    87,    55,     0,
      79,     0,    87,    48,    87,     0,    87,    47,    87,     0,
      87,    49,    87,     0,    87,    50,    87,     0,    87,    52,
      87,     0,    48,    87,     0,    47,    87,     0,    87,    31,
      87,     0,    87,    32,    87,     0,    87,    33,    87,     0,
      87,    35,    87,     0,    87,    34,    87,     0,    87,    36,
      87,     0,    87,    44,    87,     0,    87,    45,    87,     0,
      43,    87,     0,    79,    54,    88,    55,     0,    86,    54,
      87,    55,     0,    88,    57,    87,     0,    87,     0,    79,
      37,     0,    79,    38,     0,    79,    39,    87,     0,    79,
      40,    87,     0,    79,    41,    87,     0,    79,    42,    87,
       0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,    97,    98,   103,   110,   111,   113,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   129,   131,
     133,   133,   139,   139,   146,   148,   149,   150,   155,   160,
     165,   170,   175,   180,   185,   190,   195,   200,   205,   210,
     215,   221,   226,   232,   236,   242,   247,   254,   256,   257,
     259,   263,   270,   276,   278,   279,   280,   282,   283,   287,
     289,   291,   293,   295,   297,   298,   300,   301,   302,   304,
     306,   307,   308,   309,   310,   311,   312,   313,   314,   315,
     316,   317,   318,   319,   320,   321,   322,   323,   324,   325,
     326,   327,   331,   333,   334,   336,   337,   338,   339,   340,
     341
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "INTEGER", "BOOLEAN", "VALUE", "IDENT", 
  "LITERAL", "FUNCTION", "SYSTEM_CALL", "COMMAND", "HELP", "CALC", "SET", 
  "DEFINE", "IF", "ELSE", "PRINT", "QUIT", "WHILE", "FOR", "START_BLOCK", 
  "END_BLOCK", "OPEN_KEYWORD_FILE", "SAVE_KEYWORD_FILE", 
  "SET_PARAMETER_VALUE", "GET_PARAMETER_VALUE", "COMPUTE_LC", 
  "COMPUTE_RV", "CREATE_WD_LCI_FILE", "MINIMIZE_USING_SIMPLEX", "EQ", 
  "NEQ", "LEQ", "LE", "GEQ", "GR", "INC", "DEC", "INCBY", "DECBY", 
  "MULTBY", "DIVBY", "'!'", "AND", "OR", "'='", "'-'", "'+'", "'*'", 
  "'/'", "NEG", "'^'", "'\\n'", "'('", "')'", "';'", "','", "input", 
  "body", "statement", "statements", "block", "@1", "@2", "system_call", 
  "help_line", "quit_line", "while_line", "for_line", "command_line", 
  "set_line", "define_line", "arg", "args", "calc_line", "print_line", 
  "print_args", "if_line", "ident", "integer", "value", "boolean", 
  "literal", "lit_or_id", "litexprs", "function", "expr", "exprs", 
  "idexpr", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,    58,    58,    58,    59,    59,    60,    60,    60,    60,
      60,    60,    60,    60,    60,    60,    60,    60,    61,    61,
      63,    62,    64,    62,    65,    66,    66,    66,    67,    68,
      69,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    71,    71,    71,    72,    73,    74,    74,
      75,    75,    76,    77,    77,    77,    77,    78,    78,    79,
      80,    81,    82,    83,    84,    84,    85,    85,    85,    86,
      87,    87,    87,    87,    87,    87,    87,    87,    87,    87,
      87,    87,    87,    87,    87,    87,    87,    87,    87,    87,
      87,    87,    87,    88,    88,    89,    89,    89,    89,    89,
      89
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     0,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     1,
       0,     3,     0,     4,     1,     2,     3,     2,     1,     5,
      11,     4,     4,     6,     8,     6,     8,     6,     8,     8,
       4,    12,    12,     4,     4,     2,     7,     1,     3,     1,
       2,     2,     2,     3,     3,     1,     1,     5,     7,     1,
       1,     1,     1,     1,     1,     1,     3,     3,     1,     1,
       1,     1,     1,     3,     1,     3,     3,     3,     3,     3,
       2,     2,     3,     3,     3,     3,     3,     3,     3,     3,
       2,     4,     4,     3,     1,     2,     2,     3,     3,     3,
       3
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       0,     3,     0,    24,     0,     0,     0,     0,     0,     0,
      28,     0,     0,    22,     0,     0,     0,     0,     0,     0,
       0,     0,     6,     2,     4,     5,    17,     7,     8,    15,
      16,    14,     9,    10,    11,    13,    12,    59,     0,    25,
      27,    60,    62,    61,    63,    69,     0,     0,     0,     0,
      74,    70,    71,    72,    51,     0,    50,     0,    45,     0,
       0,    52,    56,    55,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    26,    90,    81,    80,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    95,    96,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    21,    19,
       0,    65,    64,     0,     0,     0,     0,     0,     0,     0,
      94,     0,    73,     0,     0,    82,    83,    84,    86,    85,
      87,    88,    89,    76,    75,    77,    78,    79,    97,    98,
      99,   100,    68,    44,    43,    49,     0,    47,     0,    53,
      54,     0,     0,    23,    18,    31,    32,     0,     0,     0,
       0,     0,    40,     0,    91,    92,     0,     0,     0,    57,
      29,     0,     0,     0,     0,     0,     0,     0,    93,    66,
      67,     0,    48,     0,     0,    35,     0,    33,     0,    37,
       0,     0,     0,     0,    46,    58,     0,     0,     0,     0,
       0,     0,     0,     0,    36,    34,    38,     0,     0,    39,
       0,     0,     0,     0,     0,     0,     0,    30,     0,     0,
      41,    42,     0,     0
};

static const short yydefgoto[] =
{
       2,    23,    24,   110,    25,    66,    67,    26,    27,    28,
      29,    30,    31,    32,    33,   145,   146,    34,    35,    61,
      36,    50,    51,    52,    53,   112,   113,   143,    55,   120,
     121,    58
};

static const short yypact[] =
{
     107,-32768,   205,-32768,     0,     9,    -4,    -4,   -53,     9,
  -32768,   -28,   -27,     8,   -21,    -3,     4,    14,    38,    48,
      49,    51,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    20,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,   233,   233,   233,   233,
      52,-32768,-32768,-32768,-32768,    55,   -13,   125,-32768,    56,
     233,    41,-32768,   -13,   233,    -4,    32,   280,     3,     3,
      -4,    -4,    54,    54,     3,   233,-32768,   146,    59,    59,
     550,   233,   233,   233,   233,   233,   233,   233,   233,   233,
     233,   233,   233,   233,   233,   233,-32768,-32768,   233,   233,
     233,   233,     9,    -4,   575,     9,   600,    68,-32768,-32768,
     237,-32768,-32768,    60,    62,    66,    72,    81,    82,    83,
     -13,   -17,-32768,     7,   625,   146,   146,   146,   146,   146,
     146,   146,   146,    -2,    -2,    59,    59,    59,   -13,   -13,
     -13,   -13,-32768,    93,   -13,-32768,    10,-32768,   122,-32768,
     -13,   122,   233,-32768,-32768,-32768,-32768,     9,    -4,   233,
     233,   233,-32768,   233,-32768,-32768,     9,    98,    -4,   130,
  -32768,   498,    19,   282,    44,   309,   336,   363,   -13,-32768,
     800,   233,-32768,   122,   233,-32768,   233,-32768,   233,-32768,
     233,   233,   233,   233,   -13,-32768,   524,   650,   675,   700,
     390,   417,   725,    -4,-32768,-32768,-32768,   233,   233,-32768,
     231,    94,   444,   471,   122,   233,   233,-32768,   750,   775,
  -32768,-32768,   148,-32768
};

static const short yypgoto[] =
{
  -32768,-32768,   -64,-32768,  -123,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,   -18,-32768,-32768,-32768,-32768,
  -32768,     1,-32768,-32768,-32768,    40,   -45,-32768,-32768,    -5,
      70,   -50
};


#define	YYLAST		852


static const short yytable[] =
{
      56,    60,    37,   109,    63,    40,    37,    57,    59,    37,
      44,    38,    41,    42,    43,    37,    44,    45,    83,    84,
      85,    86,    87,    88,   114,   169,    64,    65,   170,   119,
     -20,    89,    90,    68,    91,    92,    93,    94,   162,    95,
     163,    77,    78,    79,    80,    54,   154,    93,    94,    62,
      95,    69,    46,    39,   108,   104,    47,    48,    70,   106,
     195,    44,   164,    49,   163,   167,   107,   168,    71,   111,
     111,   115,   116,    76,   185,   111,   186,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
     137,   217,    72,   138,   139,   140,   141,   144,   105,   189,
     150,   190,    73,    74,   147,    75,    81,    -1,     1,    82,
     103,    95,   117,   118,   152,   155,    -1,   156,    -1,    -1,
      -1,    -1,    -1,   157,    -1,    -1,    -1,    -1,    -1,   158,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   159,   160,
     161,   166,   142,    13,   181,   149,   183,   171,   223,   214,
     182,   123,   173,   211,   175,   176,   177,     0,   178,   174,
      -1,   180,    96,    97,    98,    99,   100,   101,     0,   147,
       0,   102,     0,     0,     0,     0,   194,     0,     0,   196,
       0,   197,     0,   198,     0,   199,   200,   201,   202,     0,
      89,    90,     0,    91,    92,    93,    94,   172,    95,     0,
       0,     0,   212,   213,   210,   222,   179,     0,     0,     0,
     218,   219,     0,     0,     3,     0,     4,     5,     6,     7,
       8,     0,     9,    10,    11,    12,    13,     0,    14,    15,
      16,    17,    18,    19,    20,    21,    41,    42,    43,    37,
       0,    45,     0,     0,     0,     0,     3,     0,     4,     5,
       6,     7,     8,     0,     9,    10,    11,    12,    22,   153,
      14,    15,    16,    17,    18,    19,    20,    21,    96,    97,
      98,    99,   100,   101,     0,     0,    46,     0,     0,     0,
      47,    48,     0,     0,     0,     0,     0,    49,     0,     3,
      22,     4,     5,     6,     7,     8,     0,     9,    10,    11,
      12,     0,     0,    14,    15,    16,    17,    18,    19,    20,
      21,     0,     0,    83,    84,    85,    86,    87,    88,     0,
       0,     0,     0,     0,     0,     0,    89,    90,     0,    91,
      92,    93,    94,    22,    95,     0,     0,   187,     0,   188,
      83,    84,    85,    86,    87,    88,     0,     0,     0,     0,
       0,     0,     0,    89,    90,     0,    91,    92,    93,    94,
       0,    95,     0,     0,     0,     0,   191,    83,    84,    85,
      86,    87,    88,     0,     0,     0,     0,     0,     0,     0,
      89,    90,     0,    91,    92,    93,    94,     0,    95,     0,
       0,     0,     0,   192,    83,    84,    85,    86,    87,    88,
       0,     0,     0,     0,     0,     0,     0,    89,    90,     0,
      91,    92,    93,    94,     0,    95,     0,     0,     0,     0,
     193,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,     0,     0,   207,    83,    84,
      85,    86,    87,    88,     0,     0,     0,     0,     0,     0,
       0,    89,    90,     0,    91,    92,    93,    94,     0,    95,
       0,     0,     0,     0,   208,    83,    84,    85,    86,    87,
      88,     0,     0,     0,     0,     0,     0,     0,    89,    90,
       0,    91,    92,    93,    94,     0,    95,     0,     0,     0,
       0,   215,    83,    84,    85,    86,    87,    88,     0,     0,
       0,     0,     0,     0,     0,    89,    90,     0,    91,    92,
      93,    94,     0,    95,     0,     0,     0,     0,   216,    83,
      84,    85,    86,    87,    88,     0,     0,     0,     0,     0,
       0,     0,    89,    90,     0,    91,    92,    93,    94,     0,
      95,     0,     0,     0,   184,    83,    84,    85,    86,    87,
      88,     0,     0,     0,     0,     0,     0,     0,    89,    90,
       0,    91,    92,    93,    94,     0,    95,     0,     0,     0,
     203,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,   122,    83,    84,    85,    86,
      87,    88,     0,     0,     0,     0,     0,     0,     0,    89,
      90,     0,    91,    92,    93,    94,     0,    95,     0,     0,
     148,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,   151,    83,    84,    85,    86,
      87,    88,     0,     0,     0,     0,     0,     0,     0,    89,
      90,     0,    91,    92,    93,    94,     0,    95,     0,     0,
     165,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,   204,    83,    84,    85,    86,
      87,    88,     0,     0,     0,     0,     0,     0,     0,    89,
      90,     0,    91,    92,    93,    94,     0,    95,     0,     0,
     205,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,   206,    83,    84,    85,    86,
      87,    88,     0,     0,     0,     0,     0,     0,     0,    89,
      90,     0,    91,    92,    93,    94,     0,    95,     0,     0,
     209,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,    92,    93,
      94,     0,    95,     0,     0,   220,    83,    84,    85,    86,
      87,    88,     0,     0,     0,     0,     0,     0,     0,    89,
      90,     0,    91,    92,    93,    94,     0,    95,     0,     0,
     221,    83,    84,    85,    86,    87,    88,     0,     0,     0,
       0,     0,     0,     0,    89,    90,     0,    91,     0,    93,
      94,     0,    95
};

static const short yycheck[] =
{
       5,    54,     6,    67,     9,     4,     6,     6,     7,     6,
       7,    11,     3,     4,     5,     6,     7,     8,    31,    32,
      33,    34,    35,    36,    69,   148,    54,    54,   151,    74,
      22,    44,    45,    54,    47,    48,    49,    50,    55,    52,
      57,    46,    47,    48,    49,     5,   110,    49,    50,     9,
      52,    54,    43,    53,    22,    60,    47,    48,    54,    64,
     183,     7,    55,    54,    57,    55,    65,    57,    54,    68,
      69,    70,    71,    53,    55,    74,    57,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,   214,    54,    98,    99,   100,   101,   102,    57,    55,
     105,    57,    54,    54,   103,    54,    54,     0,     1,    54,
      54,    52,    72,    73,    46,    55,     9,    55,    11,    12,
      13,    14,    15,    57,    17,    18,    19,    20,    21,    57,
      23,    24,    25,    26,    27,    28,    29,    30,    57,    57,
      57,    48,   102,    21,    46,   105,    16,   152,     0,    55,
     168,    81,   157,   203,   159,   160,   161,    -1,   163,   158,
      53,   166,    37,    38,    39,    40,    41,    42,    -1,   168,
      -1,    46,    -1,    -1,    -1,    -1,   181,    -1,    -1,   184,
      -1,   186,    -1,   188,    -1,   190,   191,   192,   193,    -1,
      44,    45,    -1,    47,    48,    49,    50,   157,    52,    -1,
      -1,    -1,   207,   208,   203,     0,   166,    -1,    -1,    -1,
     215,   216,    -1,    -1,     9,    -1,    11,    12,    13,    14,
      15,    -1,    17,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,     3,     4,     5,     6,
      -1,     8,    -1,    -1,    -1,    -1,     9,    -1,    11,    12,
      13,    14,    15,    -1,    17,    18,    19,    20,    53,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    37,    38,
      39,    40,    41,    42,    -1,    -1,    43,    -1,    -1,    -1,
      47,    48,    -1,    -1,    -1,    -1,    -1,    54,    -1,     9,
      53,    11,    12,    13,    14,    15,    -1,    17,    18,    19,
      20,    -1,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    -1,    -1,    31,    32,    33,    34,    35,    36,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    44,    45,    -1,    47,
      48,    49,    50,    53,    52,    -1,    -1,    55,    -1,    57,
      31,    32,    33,    34,    35,    36,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,    50,
      -1,    52,    -1,    -1,    -1,    -1,    57,    31,    32,    33,
      34,    35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      44,    45,    -1,    47,    48,    49,    50,    -1,    52,    -1,
      -1,    -1,    -1,    57,    31,    32,    33,    34,    35,    36,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    45,    -1,
      47,    48,    49,    50,    -1,    52,    -1,    -1,    -1,    -1,
      57,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    -1,    -1,    57,    31,    32,
      33,    34,    35,    36,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    44,    45,    -1,    47,    48,    49,    50,    -1,    52,
      -1,    -1,    -1,    -1,    57,    31,    32,    33,    34,    35,
      36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    45,
      -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,    -1,
      -1,    57,    31,    32,    33,    34,    35,    36,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,
      49,    50,    -1,    52,    -1,    -1,    -1,    -1,    57,    31,
      32,    33,    34,    35,    36,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    44,    45,    -1,    47,    48,    49,    50,    -1,
      52,    -1,    -1,    -1,    56,    31,    32,    33,    34,    35,
      36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    45,
      -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,    -1,
      56,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    55,    31,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      45,    -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,
      55,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    55,    31,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      45,    -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,
      55,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    55,    31,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      45,    -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,
      55,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    55,    31,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      45,    -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,
      55,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    48,    49,
      50,    -1,    52,    -1,    -1,    55,    31,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      45,    -1,    47,    48,    49,    50,    -1,    52,    -1,    -1,
      55,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    45,    -1,    47,    -1,    49,
      50,    -1,    52
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison/bison.simple"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "/usr/share/bison/bison.simple"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 2:
#line 98 "phoebe_scripter_grammar.y"
{
			if (scripter_print_prompt == TRUE)
			  printf ("> ");
			else scripter_print_prompt = TRUE;
			;
    break;}
case 3:
#line 103 "phoebe_scripter_grammar.y"
{
			yyclearin;
			yyerrok;
			scripter_print_prompt = TRUE;
			scripter_scope_level = 0;
			;
    break;}
case 4:
#line 110 "phoebe_scripter_grammar.y"
{ ;
    break;}
case 5:
#line 111 "phoebe_scripter_grammar.y"
{ ;
    break;}
case 6:
#line 113 "phoebe_scripter_grammar.y"
{
			  /* This ignores any newlines in stmts.  */
			  yyval.ast = scripter_ast_add_node (kind_ignore, NULL);
			;
    break;}
case 7:
#line 117 "phoebe_scripter_grammar.y"
{ /* Nothing to do. */ ;
    break;}
case 8:
#line 118 "phoebe_scripter_grammar.y"
{ /* Nothing to do. */ ;
    break;}
case 9:
#line 119 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 10:
#line 120 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 11:
#line 121 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 12:
#line 122 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 13:
#line 123 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 14:
#line 124 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 15:
#line 125 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 16:
#line 126 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 17:
#line 127 "phoebe_scripter_grammar.y"
{ if (scripter_scope_level == 0) scripter_ast_evaluate (yyvsp[0].ast); ;
    break;}
case 18:
#line 130 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-1].lst);   ;
    break;}
case 19:
#line 131 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 20:
#line 133 "phoebe_scripter_grammar.y"
{ scripter_scope_level++; ;
    break;}
case 21:
#line 134 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_block, NULL);
			  scripter_scope_level--;
			  scripter_print_prompt = FALSE;
 			;
    break;}
case 22:
#line 139 "phoebe_scripter_grammar.y"
{ scripter_scope_level++; ;
    break;}
case 23:
#line 140 "phoebe_scripter_grammar.y"
{
			  scripter_ast_list *s = scripter_ast_reverse_list (yyvsp[-1].lst, NULL);
			  yyval.ast = scripter_ast_add_node (kind_block, s);
			  scripter_scope_level--;
			;
    break;}
case 24:
#line 146 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_system_call, scripter_ast_construct_list (scripter_ast_add_string (yyvsp[0].str), NULL)); ;
    break;}
case 25:
#line 148 "phoebe_scripter_grammar.y"
{ scripter_directive_help (""); ;
    break;}
case 26:
#line 149 "phoebe_scripter_grammar.y"
{ scripter_directive_help ("help"); ;
    break;}
case 27:
#line 150 "phoebe_scripter_grammar.y"
{
			  phoebe_scripter_output ("sorry, online help is not implemented in alpha release.\n");
			  scripter_print_prompt = FALSE;
			;
    break;}
case 28:
#line 155 "phoebe_scripter_grammar.y"
{
			  scripter_directive_quit ();
			  scripter_print_prompt = FALSE;
			;
    break;}
case 29:
#line 161 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_while, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL)));
			;
    break;}
case 30:
#line 166 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_for, scripter_ast_construct_list (yyvsp[-8].ast, scripter_ast_construct_list (yyvsp[-6].ast, scripter_ast_construct_list (yyvsp[-4].ast, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))))));
			;
    break;}
case 31:
#line 171 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("open_keyword_file"), scripter_ast_construct_list (yyvsp[-1].ast, NULL)));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 32:
#line 176 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("save_keyword_file"), scripter_ast_construct_list (yyvsp[-1].ast, NULL)));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 33:
#line 181 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("set_parameter_value"), scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 34:
#line 186 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("set_parameter_value"), scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 35:
#line 191 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("set_parameter_value"), scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 36:
#line 196 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("set_parameter_value"), scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 37:
#line 201 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("get_parameter_value"), scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 38:
#line 206 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("get_parameter_value"), scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 39:
#line 211 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("create_wd_lci_file"), scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 40:
#line 216 "phoebe_scripter_grammar.y"
{
			  scripter_ast_list *params = scripter_ast_reverse_list (yyvsp[-1].lst, NULL);
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("minimize_using_simplex"), params));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 41:
#line 222 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("compute_lc"), scripter_ast_construct_list (yyvsp[-9].ast, scripter_ast_construct_list (yyvsp[-7].ast, scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 42:
#line 227 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_command, scripter_ast_construct_list (scripter_ast_add_string ("compute_rv"), scripter_ast_construct_list (yyvsp[-9].ast, scripter_ast_construct_list (yyvsp[-7].ast, scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL)))))));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 43:
#line 232 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_set, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL)));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 44:
#line 237 "phoebe_scripter_grammar.y"
{
			  scripter_ast_list *params = scripter_ast_reverse_list (yyvsp[0].lst, NULL);
			  yyval.ast = scripter_ast_add_node (kind_set, scripter_ast_construct_list (yyvsp[-2].ast, params));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 45:
#line 242 "phoebe_scripter_grammar.y"
{
			  yyval.ast = scripter_ast_add_node (kind_set, scripter_ast_construct_list (yyvsp[0].ast, NULL));
			  scripter_print_prompt = FALSE;
			;
    break;}
case 46:
#line 248 "phoebe_scripter_grammar.y"
{
			scripter_ast_list *params = scripter_ast_reverse_list (yyvsp[-3].lst, NULL);
			yyval.ast = scripter_ast_add_node (kind_define, scripter_ast_construct_list (yyvsp[-5].ast, scripter_ast_construct_list (yyvsp[0].ast, params)));
			scripter_print_prompt = FALSE;
			;
    break;}
case 47:
#line 254 "phoebe_scripter_grammar.y"
{;
    break;}
case 48:
#line 256 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst); ;
    break;}
case 49:
#line 257 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 50:
#line 259 "phoebe_scripter_grammar.y"
{
			yyval.ast = scripter_ast_add_node (kind_calc, scripter_ast_construct_list (yyvsp[0].ast, NULL));
			scripter_print_prompt = FALSE;
			;
    break;}
case 51:
#line 263 "phoebe_scripter_grammar.y"
{
			/* This can't be done, but someone may    */
			/* try it, so we'd better support it.     */
			yyval.ast = scripter_ast_add_node (kind_calc, scripter_ast_construct_list (yyvsp[0].ast, NULL));
			scripter_print_prompt = FALSE;
			;
    break;}
case 52:
#line 270 "phoebe_scripter_grammar.y"
{
			scripter_ast_list *params = scripter_ast_reverse_list (yyvsp[0].lst, NULL);
			yyval.ast = scripter_ast_add_node (kind_print, params);
			scripter_print_prompt = FALSE;
			;
    break;}
case 53:
#line 277 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst); ;
    break;}
case 54:
#line 278 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst); ;
    break;}
case 55:
#line 279 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 56:
#line 280 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 57:
#line 282 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_if, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 58:
#line 284 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_ifelse, scripter_ast_construct_list (yyvsp[-4].ast, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL)))); ;
    break;}
case 59:
#line 287 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_variable (yyvsp[0].str); ;
    break;}
case 60:
#line 289 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_int (yyvsp[0].idx); ;
    break;}
case 61:
#line 291 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_double (yyvsp[0].val); ;
    break;}
case 62:
#line 293 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_bool (yyvsp[0].swc); ;
    break;}
case 63:
#line 295 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_string (yyvsp[0].str); ;
    break;}
case 64:
#line 297 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 65:
#line 298 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 66:
#line 300 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst);   ;
    break;}
case 67:
#line 301 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst);   ;
    break;}
case 68:
#line 302 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 69:
#line 304 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_function (yyvsp[0].str); ;
    break;}
case 70:
#line 306 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 71:
#line 307 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 72:
#line 308 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 73:
#line 309 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[-1].ast; ;
    break;}
case 74:
#line 310 "phoebe_scripter_grammar.y"
{ yyval.ast = yyvsp[0].ast; ;
    break;}
case 75:
#line 311 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_add,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 76:
#line 312 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_sub,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 77:
#line 313 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_mul,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 78:
#line 314 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_div,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 79:
#line 315 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_pot,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 80:
#line 316 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_unaryp,  scripter_ast_construct_list (yyvsp[0].ast, NULL)); ;
    break;}
case 81:
#line 317 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_unarym,  scripter_ast_construct_list (yyvsp[0].ast, NULL)); ;
    break;}
case 82:
#line 318 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_equal,   scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 83:
#line 319 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_nequal,  scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 84:
#line 320 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_lequal,  scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 85:
#line 321 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_gequal,  scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 86:
#line 322 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_less,    scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 87:
#line 323 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_greater, scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 88:
#line 324 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_and,     scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 89:
#line 325 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_or,      scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 90:
#line 326 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_not,     scripter_ast_construct_list (yyvsp[0].ast, NULL)); ;
    break;}
case 91:
#line 327 "phoebe_scripter_grammar.y"
{
			  scripter_ast_list *s = scripter_ast_reverse_list (yyvsp[-1].lst, NULL);
			  yyval.ast = scripter_ast_add_node (kind_func, scripter_ast_construct_list (yyvsp[-3].ast, s));
			;
    break;}
case 92:
#line 331 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_builtin, scripter_ast_construct_list (yyvsp[-3].ast, scripter_ast_construct_list (yyvsp[-1].ast, NULL))); ;
    break;}
case 93:
#line 333 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, yyvsp[-2].lst); ;
    break;}
case 94:
#line 334 "phoebe_scripter_grammar.y"
{ yyval.lst = scripter_ast_construct_list (yyvsp[0].ast, NULL); ;
    break;}
case 95:
#line 336 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_inc,     scripter_ast_construct_list (yyvsp[-1].ast, NULL)); ;
    break;}
case 96:
#line 337 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_dec,     scripter_ast_construct_list (yyvsp[-1].ast, NULL)); ;
    break;}
case 97:
#line 338 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_incby,   scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 98:
#line 339 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_decby,   scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 99:
#line 340 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_multby,  scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
case 100:
#line 341 "phoebe_scripter_grammar.y"
{ yyval.ast = scripter_ast_add_node (kind_divby,   scripter_ast_construct_list (yyvsp[-2].ast, scripter_ast_construct_list (yyvsp[0].ast, NULL))); ;
    break;}
}

#line 705 "/usr/share/bison/bison.simple"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 344 "phoebe_scripter_grammar.y"


int yyerror (const char *str)
  {
  if (strcmp (str, "parse error") == 0)
    phoebe_scripter_output ("syntax error\n", str);
  }

int yywrap ()
  {
  return 1;
  }

int scripter_initialize ()
  {
  scripter_scope_level = 0;

  /* Let's define the constants:                                              */
  scripter_st_identifier_assign ("CONST_PI",   3.14159265359);
  scripter_st_identifier_assign ("CONST_E",    2.71828182846);
  scripter_st_identifier_assign ("CONST_AU",   149597870.691);
  scripter_st_identifier_assign ("CONST_RSUN", 696000.0);
  scripter_st_identifier_assign ("CONST_MSUN", 1.99E30);

  printf ("\nThis is PHOEBE %s scripter.\n\n> ", PHOEBE_VERSION_NUMBER);
  yyparse ();
  }
