#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>

#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
    gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

#include "phoebe_build_config.h"

int phoebe_notice (const char *fmt, ...)
	{
	va_list ap;
	int r;

	printf ("PHOEBE notice: ");
	va_start (ap, fmt);
	r = vprintf (fmt, ap);
	va_end (ap);

	return r;
	}

int phoebe_warning (const char *fmt, ...)
	{
	va_list ap;
	int r;

	printf ("PHOEBE warning: ");
	va_start (ap, fmt);
	r = vprintf (fmt, ap);
	va_end (ap);

	return r;
	}

int phoebe_debug (const char *fmt, ...)
	{
	/* This function writes the message to stdout in case PHOEBE was compiled   */
	/* with --enable-debug switch, otherwise it just returns control to the ma- */
	/* in program.                                                              */

	va_list ap;
	int r = -1;

	#ifdef PHOEBE_DEBUG_SUPPORT
		printf ("PHOEBE debug: ");
		va_start (ap, fmt);
		r = vprintf (fmt, ap);
		va_end (ap);
	#endif

	return r;
	}

int phoebe_fatal (const char *fmt, ...)
	{
	va_list ap;

	printf ("PHOEBE fatal: ");
	va_start (ap, fmt);
	vprintf (fmt, ap);
	va_end (ap);

	exit (EXIT_FAILURE);
	}

int phoebe_scripter_output (const char *fmt, ...)
	{
	va_list ap;
	int r;

	printf ("PHOEBE scripter: ");
	va_start (ap, fmt);
	r = vprintf (fmt, ap);
	va_end (ap);

	return r;
	}

void *phoebe_malloc (size_t size)
	{
	register void *value = malloc (size);
	if (value == 0) phoebe_fatal ("Virtual memory exhauseted.\n");
	return value;
	}

void *phoebe_realloc (void *ptr, size_t size)
	{
	/* This function reallocates the space with the check whether the memory    */
	/* was exhausted. If the size equals 0, realloc calls free() on ptr.        */

	register void *value = realloc (ptr, size);
	if ( (value == 0) && (size != 0) ) phoebe_fatal ("Virtual memory exhauseted.\n");
	return value;
	}

GtkWidget* create_warning_window (char *title, char *main_label, char *description1, char *description2, GCallback ok_function, GCallback cancel_function)
	{
  GtkWidget *warning_window;
  GtkWidget *warning_window_main_box;
  GtkWidget *warning_window_main_frame;
  GtkWidget *warning_window_message_box;
  GtkWidget *warning_window_title_button;
  GtkWidget *warning_window_title_alignment;
  GtkWidget *warning_window_title_box;
  GtkWidget *warning_window_title_icon;
  GtkWidget *warning_window_title_label;
  GtkWidget *warning_window_line_1;
  GtkWidget *warning_window_line_2;
  GtkWidget *warning_window_button_box;
  GtkWidget *warning_window_ok_button;
  GtkWidget *warning_window_cancel_button;

  warning_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (warning_window), title);

  warning_window_main_box = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (warning_window_main_box);
  gtk_container_add (GTK_CONTAINER (warning_window), warning_window_main_box);

  warning_window_main_frame = gtk_frame_new (NULL);
  gtk_widget_show (warning_window_main_frame);
  gtk_box_pack_start (GTK_BOX (warning_window_main_box), warning_window_main_frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_main_frame), 5);

  warning_window_message_box = gtk_vbox_new (FALSE, 5);
  gtk_widget_show (warning_window_message_box);
  gtk_container_add (GTK_CONTAINER (warning_window_main_frame), warning_window_message_box);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_message_box), 5);

  warning_window_title_button = gtk_button_new ();
  gtk_widget_show (warning_window_title_button);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_title_button, FALSE, FALSE, 0);
  gtk_button_set_relief (GTK_BUTTON (warning_window_title_button), GTK_RELIEF_NONE);

  warning_window_title_alignment = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (warning_window_title_alignment);
  gtk_container_add (GTK_CONTAINER (warning_window_title_button), warning_window_title_alignment);

  warning_window_title_box = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (warning_window_title_box);
  gtk_container_add (GTK_CONTAINER (warning_window_title_alignment), warning_window_title_box);

  warning_window_title_icon = gtk_image_new_from_stock ("gtk-dialog-warning", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (warning_window_title_icon);
  gtk_box_pack_start (GTK_BOX (warning_window_title_box), warning_window_title_icon, FALSE, FALSE, 0);

  warning_window_title_label = gtk_label_new_with_mnemonic (main_label);
  gtk_widget_show (warning_window_title_label);
  gtk_box_pack_start (GTK_BOX (warning_window_title_box), warning_window_title_label, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_title_label), GTK_JUSTIFY_LEFT);

  warning_window_line_1 = gtk_label_new (description1);
  gtk_widget_show (warning_window_line_1);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_line_1, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_line_1), GTK_JUSTIFY_LEFT);

  warning_window_line_2 = gtk_label_new (description2);
  gtk_widget_show (warning_window_line_2);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_line_2, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_line_2), GTK_JUSTIFY_LEFT);

  warning_window_button_box = gtk_hbox_new (TRUE, 0);
  gtk_widget_show (warning_window_button_box);
  gtk_box_pack_start (GTK_BOX (warning_window_main_box), warning_window_button_box, FALSE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_button_box), 5);

  warning_window_ok_button = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (warning_window_ok_button);
  gtk_box_pack_start (GTK_BOX (warning_window_button_box), warning_window_ok_button, TRUE, TRUE, 0);
  g_signal_connect ((gpointer) warning_window_ok_button, "clicked", G_CALLBACK (ok_function), NULL);

  warning_window_cancel_button = gtk_button_new_from_stock ("gtk-cancel");
  gtk_widget_show (warning_window_cancel_button);
  gtk_box_pack_start (GTK_BOX (warning_window_button_box), warning_window_cancel_button, TRUE, TRUE, 0);
  g_signal_connect_swapped ((gpointer) warning_window_cancel_button, "clicked", G_CALLBACK (cancel_function), warning_window);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (warning_window, warning_window, "warning_window");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_main_box, "warning_window_main_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_main_frame, "warning_window_main_frame");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_message_box, "warning_window_message_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_button, "warning_window_title_button");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_alignment, "warning_window_title_alignment");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_box, "warning_window_title_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_icon, "warning_window_title_icon");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_label, "warning_window_title_label");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_line_1, "warning_window_line_1");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_line_2, "warning_window_line_2");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_button_box, "warning_window_button_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_ok_button, "warning_window_ok_button");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_cancel_button, "warning_window_cancel_button");

	gtk_widget_show (warning_window);
  return warning_window;
	}

GtkWidget* create_notice_window (char *title, char *main_label, char *description1, char *description2, GCallback function)
	{
  GtkWidget *warning_window;
  GtkWidget *warning_window_main_box;
  GtkWidget *warning_window_main_frame;
  GtkWidget *warning_window_message_box;
  GtkWidget *warning_window_title_button;
  GtkWidget *warning_window_title_alignment;
  GtkWidget *warning_window_title_box;
  GtkWidget *warning_window_title_icon;
  GtkWidget *warning_window_title_label;
  GtkWidget *warning_window_line_1;
  GtkWidget *warning_window_line_2;
  GtkWidget *warning_window_button_box;
  GtkWidget *warning_window_ok_button;

  warning_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (warning_window), title);

  warning_window_main_box = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (warning_window_main_box);
  gtk_container_add (GTK_CONTAINER (warning_window), warning_window_main_box);

  warning_window_main_frame = gtk_frame_new (NULL);
  gtk_widget_show (warning_window_main_frame);
  gtk_box_pack_start (GTK_BOX (warning_window_main_box), warning_window_main_frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_main_frame), 5);

  warning_window_message_box = gtk_vbox_new (FALSE, 5);
  gtk_widget_show (warning_window_message_box);
  gtk_container_add (GTK_CONTAINER (warning_window_main_frame), warning_window_message_box);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_message_box), 5);

  warning_window_title_button = gtk_button_new ();
  gtk_widget_show (warning_window_title_button);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_title_button, FALSE, FALSE, 0);
  gtk_button_set_relief (GTK_BUTTON (warning_window_title_button), GTK_RELIEF_NONE);

  warning_window_title_alignment = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (warning_window_title_alignment);
  gtk_container_add (GTK_CONTAINER (warning_window_title_button), warning_window_title_alignment);

  warning_window_title_box = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (warning_window_title_box);
  gtk_container_add (GTK_CONTAINER (warning_window_title_alignment), warning_window_title_box);

  warning_window_title_icon = gtk_image_new_from_stock ("gtk-dialog-warning", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (warning_window_title_icon);
  gtk_box_pack_start (GTK_BOX (warning_window_title_box), warning_window_title_icon, FALSE, FALSE, 0);

  warning_window_title_label = gtk_label_new_with_mnemonic (main_label);
  gtk_widget_show (warning_window_title_label);
  gtk_box_pack_start (GTK_BOX (warning_window_title_box), warning_window_title_label, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_title_label), GTK_JUSTIFY_LEFT);

  warning_window_line_1 = gtk_label_new (description1);
  gtk_widget_show (warning_window_line_1);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_line_1, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_line_1), GTK_JUSTIFY_LEFT);

  warning_window_line_2 = gtk_label_new (description2);
  gtk_widget_show (warning_window_line_2);
  gtk_box_pack_start (GTK_BOX (warning_window_message_box), warning_window_line_2, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (warning_window_line_2), GTK_JUSTIFY_LEFT);

  warning_window_button_box = gtk_hbox_new (TRUE, 0);
  gtk_widget_show (warning_window_button_box);
  gtk_box_pack_start (GTK_BOX (warning_window_main_box), warning_window_button_box, FALSE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (warning_window_button_box), 5);

  warning_window_ok_button = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (warning_window_ok_button);
  gtk_box_pack_start (GTK_BOX (warning_window_button_box), warning_window_ok_button, TRUE, TRUE, 0);
  g_signal_connect_swapped ((gpointer) warning_window_ok_button, "clicked", G_CALLBACK (function), warning_window);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (warning_window, warning_window, "warning_window");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_main_box, "warning_window_main_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_main_frame, "warning_window_main_frame");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_message_box, "warning_window_message_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_button, "warning_window_title_button");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_alignment, "warning_window_title_alignment");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_box, "warning_window_title_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_icon, "warning_window_title_icon");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_title_label, "warning_window_title_label");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_line_1, "warning_window_line_1");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_line_2, "warning_window_line_2");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_button_box, "warning_window_button_box");
  GLADE_HOOKUP_OBJECT (warning_window, warning_window_ok_button, "warning_window_ok_button");

	gtk_widget_show (warning_window);
  return warning_window;
	}
