#ifndef PHOEBE_GLOBAL_H
	#define PHOEBE_GLOBAL_H 1

#include <stdarg.h>

/* ************************************************************************** */
/*                    Global PHOEBE command line arguments:                   */
/* ************************************************************************** */

typedef struct PHOEBE_COMMAND_LINE_ARGS
	{
	int KEYWORD_SWITCH;
	char *KEYWORD;
	int SCRIPT_SWITCH;
	char *SCRIPT_NAME;
	int INTERACTIVE_SCRIPTER_SWITCH;
	} PHOEBE_COMMAND_LINE_ARGS;

PHOEBE_COMMAND_LINE_ARGS PHOEBE_args;

/* ************************************************************************** */
/*                        Global PHOEBE setup strings:                        */
/* ************************************************************************** */

char *USER_HOME_DIR;

char *PHOEBE_VERSION_NUMBER;
char *PHOEBE_VERSION_DATE;
char *PHOEBE_KEYWORD_FILENAME;
char *PHOEBE_DEFAULTS;

char *PHOEBE_STARTUP_DIR;
char *PHOEBE_HOME_DIR;
char *PHOEBE_CONFIG;
char *PHOEBE_BASE_DIR;
char *PHOEBE_SOURCE_DIR;
char *PHOEBE_DEFAULTS_DIR;
char *PHOEBE_TEMP_DIR;
char *PHOEBE_DATA_DIR;
char *PHOEBE_FF_DIR;
char *PHOEBE_PLOTTING_PACKAGE;
int   PHOEBE_LD_SWITCH;
char *PHOEBE_LD_DIR;
int   PHOEBE_KURUCZ_SWITCH;
char *PHOEBE_KURUCZ_DIR;

char *PHOEBE_INPUT_LOCALE;

/* ************************************************************************** */
/*                    Global PHOEBE configuration options:                    */
/* ************************************************************************** */

int PHOEBE_3D_PLOT_CALLBACK_OPTION;
int PHOEBE_CONFIRM_ON_SAVE;
int PHOEBE_CONFIRM_ON_QUIT;
int PHOEBE_WARN_ON_SYNTHETIC_SCATTER;

/* ************************************************************************** */
/*                       PHOEBE typedefs and structs:                         */
/* ************************************************************************** */

typedef enum bool
	{
	NO,
	YES
	} bool;

typedef union anytype
	{
	int      i;
	double   d;
	bool     b;
	char    *str;
	int     *iarray;
	double  *darray;
	bool    *barray;
	char   **strarray;
	} anytype;

typedef enum PHOEBE_type
	{
	TYPE_INT,
	TYPE_DOUBLE,
	TYPE_STRING,
	TYPE_BOOL,
	TYPE_INT_ARRAY,
	TYPE_DOUBLE_ARRAY,
	TYPE_STRING_ARRAY,
	TYPE_BOOL_ARRAY,
	TYPE_ANY
	} PHOEBE_type;

typedef enum PHOEBE_input_indep
	{
	INPUT_HJD,
	INPUT_PHASE
	} PHOEBE_input_indep;

typedef enum PHOEBE_input_dep
	{
	INPUT_FLUX,
	INPUT_MAGNITUDE,
	INPUT_RV_IN_KMS
	} PHOEBE_input_dep;

typedef enum PHOEBE_input_weight
	{
	INPUT_STANDARD_WEIGHT,
	INPUT_STANDARD_DEVIATION,
	INPUT_UNAVAILABLE
	} PHOEBE_input_weight;

typedef enum PHOEBE_output_indep
	{
	OUTPUT_HJD,
	OUTPUT_PHASE
	} PHOEBE_output_indep;

typedef enum PHOEBE_output_dep
	{
	OUTPUT_MAGNITUDE,
	OUTPUT_PRIMARY_FLUX,
	OUTPUT_SECONDARY_FLUX,
	OUTPUT_TOTAL_FLUX,
	OUTPUT_PRIMARY_RV,
	OUTPUT_SECONDARY_RV,
	OUTPUT_BOTH_RVS,
	OUTPUT_PRIMARY_NORMALIZED_RV,
	OUTPUT_SECONDARY_NORMALIZED_RV
	} PHOEBE_output_dep;

typedef enum PHOEBE_output_weight
	{
	OUTPUT_STANDARD_WEIGHT,
	OUTPUT_STANDARD_DEVIATION,
	OUTPUT_UNAVAILABLE
	} PHOEBE_output_weight;

typedef struct PHOEBE_data
	{
	int     ptsno;   /* The number of points that PHOEBE_data currently holds   */
	double *indep;   /* An array of independent data points                     */
	double *dep;     /* An array of dependent data points                       */
	double *weight;  /* An array of weights for data points                     */
	} PHOEBE_data;

typedef struct PHOEBE_spectrum_tag
	{
	int resolution;
	int lambda_min;
	int lambda_max;
	int temperature;
	int metallicity;
	int gravity;
	int rotvelocity;
	} PHOEBE_spectrum_tag;

typedef struct PHOEBE_spectrum
	{
	int                  no;
	PHOEBE_spectrum_tag *prop;
	} PHOEBE_spectrum;

typedef struct PHOEBE_parameter_tag
	{
	char        *qualifier;
	char        *bond;
	char        *keyword;
	char        *description;
	PHOEBE_type  type;
	anytype      value;
	} PHOEBE_parameter_tag;

PHOEBE_parameter_tag *PHOEBE_parameters;
int                   PHOEBE_parameters_no;

typedef struct WD_LCI_parameters
	{
	int    MPAGE;
	int    NREF;
	int    MREF;
	int    IFSMV1;
	int    IFSMV2;
	int    ICOR1;
	int    ICOR2;
	int    LD;
	int    JDPHS;
	double HJD0;
	double PERIOD;
	double DPDT;
	double PSHIFT;
	double SIGMA;
	int    WEIGHTING;
	double SEED;
	double HJDST;
	double HJDSP;
	double HJDIN;
	double PHSTRT;
	double PHSTOP;
	double PHIN;
	double PHNORM;
	int    MODE;
	int    IPB;
	int    IFAT1;
	int    IFAT2;
	int    N1;
	int    N2;
	double PERR0;
	double DPERDT;
	double THE;
	double VUNIT;
	double E;
	double SMA;
	double F1;
	double F2;
	double VGA;
	double INCL;
	double GR1;
	double GR2;
	double LOGG1;
	double LOGG2;
	double MET1;
	double MET2;
	double TAVH;
	double TAVC;
	double ALB1;
	double ALB2;
	double PHSV;
	double PCSV;
	double RM;
	double XBOL1;
	double XBOL2;
	double YBOL1;
	double YBOL2;
	int    IBAND;
	double HLA;
	double CLA;
	double X1A;
	double X2A;
	double Y1A;
	double Y2A;
	double EL3;
	double OPSF;
	double MZERO;
	double FACTOR;
	double WLA;
	double SPRIM;
	double *XLAT1;
	double *XLONG1;
	double *RADSP1;
	double *TEMSP1;
	double SSEC;
	double *XLAT2;
	double *XLONG2;
	double *RADSP2;
	double *TEMSP2;
	} WD_LCI_parameters;

typedef struct PHOEBE_lc_plot_parameters
	{
	bool                 alias;
	bool                 bin;
	bool                 deredden;
	bool                 synthderedden;
	bool                 residuals;
	bool                *synthetic;
	bool                *experimental;
	double              *filter;
	double              *shift;
	PHOEBE_output_indep  indep;
	PHOEBE_output_dep    dep;
	PHOEBE_output_weight weight;
	double               phstart;
	double               phend;
	double               vertices;
	} PHOEBE_lc_plot_parameters;

#endif
