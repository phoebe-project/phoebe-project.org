#include <stdlib.h>
#include <stdio.h>

#include "phoebe_build_config.h"

#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_keywords.h"

void emit_parameter_changed_signal_for_plugins (char *qualifier, int index)
	{
	/* This function is called whenever a particular parameter value determined */
	/* by the passed qualifier is changed. All plug-ins to PHOEBE must put      */
	/* their catching functions to this function.                               */

	/* PHOEBE Graphical User Interface (GUI):                                   */
/*
	GtkWidget *widget;

	switch (phoebe_type_from_qualifier (qualifier))
		{
		case TYPE_INT:
			phoebe_gui_set_value_int (qualifier, phoebe_get_value_int (qualifier));
		break;
		case TYPE_DOUBLE:
			phoebe_gui_set_value_double (qualifier, phoebe_get_value_double (qualifier));
		break;
		case TYPE_BOOL:
			phoebe_gui_set_value_bool (qualifier, phoebe_get_value_bool (qualifier));
		break;
		case TYPE_STRING:
			phoebe_gui_set_value_string (qualifier, phoebe_get_value_string (qualifier));
		break;
		case TYPE_INT_ARRAY:
			phoebe_gui_set_value_list_int (qualifier, index, phoebe_get_value_list_int (qualifier, index));
		case TYPE_BOOL_ARRAY:
			phoebe_gui_set_value_list_bool (qualifier, index, phoebe_get_value_list_bool (qualifier, index));
		case TYPE_DOUBLE_ARRAY:
			phoebe_gui_set_value_list_double (qualifier, index, phoebe_get_value_list_double (qualifier, index));
		case TYPE_STRING_ARRAY:
			phoebe_gui_set_value_list_string (qualifier, index, phoebe_get_value_list_string (qualifier, index));
		break;
		}
*/
	}
