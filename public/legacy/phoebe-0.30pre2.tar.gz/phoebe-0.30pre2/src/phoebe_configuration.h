#ifndef PHOEBE_CONFIGURATION_H
	#define PHOEBE_CONFIGURATION_H 1

void configuration_save_file ();

#endif
