#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "phoebe_build_config.h"
#include "phoebe_global.h"

#include "phoebe_accessories.h"
#include "phoebe_error_handling.h"
#include "phoebe_keywords.h"

void parse_startup_line (int argc, char *argv[])
	{
	/* This function parses the command line and looks for known switches; it   */
	/* doesn't really do anything with them, it just writes what it found to    */
	/* the PHOEBE_args variable that is supposed to be used for real actions.   */

	int i;

	for (i = 1; i < argc; i++)
		{
		if ( (strcmp (argv[i],  "-h"   ) == 0) ||
		     (strcmp (argv[i],  "-?"   ) == 0) ||
				 (strcmp (argv[i], "--help") == 0) )
			{
			printf ("\nPHOEBE %s command line arguments: [-hsv] [keyword_file]\n\n", PHOEBE_VERSION_NUMBER);
			printf ("  -e, --execute       ..  execute PHOEBE script\n");
			printf ("  -h, --help, -?      ..  this help screen\n");
			printf ("  -s, --scripter      ..  Run PHOEBE scripter interactively\n");
			printf ("  -v, --version       ..  display PHOEBE version and exit\n");
			printf ("\n");
			exit (0);
			}
		if ( (strcmp (argv[i],  "-v"      ) == 0) ||
				 (strcmp (argv[i], "--version") == 0) )
			{
			printf ("\nPHOEBE %s, %s by Andrej Prsa\n", PHOEBE_VERSION_NUMBER, PHOEBE_VERSION_DATE);
			printf ("  Send comments and/or requests to andrej.prsa@fmf.uni-lj.si\n\n");
			exit (0);
			}
		if ( (strcmp (argv[i],  "-e"      ) == 0) ||
				 (strcmp (argv[i], "--execute") == 0) )
			{
			/* We cannot start the script from here because the widgets aren't ini- */
			/* tialized yet; thus we just initialize the proper switches:           */
			PHOEBE_args.SCRIPT_SWITCH = 1;
			
			/* If someone forgot to put the script name, we should warn him and     */
			/* exit:                                                                */
			if ( (i+1 == argc) || (argv[i+1][0] == '-') )
				{
				printf ("\nPHOEBE %s command line arguments: [-hsv] [keyword_file]\n\n", PHOEBE_VERSION_NUMBER);
				printf ("  -e, --execute       ..  execute PHOEBE script\n");
				printf ("  -h, --help, -?      ..  this help screen\n");
				printf ("  -s, --scripter      ..  Run PHOEBE scripter interactively\n");
				printf ("  -v, --version       ..  display PHOEBE version and exit\n");
				printf ("\n");
				phoebe_fatal ("there is no argument given to the '-e' switch.\n\n");
				exit (0);
				}

			/* Otherwise let's read in the script's name:                           */
			PHOEBE_args.SCRIPT_NAME = strdup (argv[i+1]);
			i++; i++;                            /* This will skip the script name. */
			if (i >= argc) break;   /* If this was the last switch, break the loop. */
			}

		if ( (strcmp (argv[i],  "-s"       ) == 0) ||
				 (strcmp (argv[i], "--scripter") == 0) )
			PHOEBE_args.INTERACTIVE_SCRIPTER_SWITCH = 1;
		else
			PHOEBE_args.INTERACTIVE_SCRIPTER_SWITCH = 0;

		if ( argv[i][0] != '-' )
			{
			/* This means that the command line argument doesn't contain '-'; thus  */
			/* it should be a keyword file. All other arguments to - and -- swit-   */
			/* ches (without -/--) are read in before and they should never evalua- */
			/* te here.                                                             */

			PHOEBE_args.KEYWORD_SWITCH = 1;
			PHOEBE_args.KEYWORD = strdup (argv[i]);
			}
		}
	}

int variables_init ()
	{
	/* This function initializes all global literal strings, so that they may   */
	/* be used fearlessly by other functions.                                   */
	
	/* Let's declare a global keyword filename string to "Undefined". This is   */
	/* needed for command line keyword filenames' incorporation.                */
	PHOEBE_KEYWORD_FILENAME = strdup ("Undefined");

	/* The following are global parameter variables which are identified by the */
	/* widget, qualifier, keyword and description. Since they will be dynamica- */
	/* lly stored by realloc, we need to set it to NULL.                        */
	PHOEBE_parameters_no = 0;
	PHOEBE_parameters    = NULL;

	/* Much the same as above, we initialize command line argument strings:     */
	PHOEBE_args.KEYWORD          = NULL;
	PHOEBE_args.SCRIPT_NAME      = NULL;
	}

int phoebe_init ()
	{
	/* This function initializes all core parameters.                           */

	char working_string[255];
	char *working_str = working_string;

	char keyword_string[255];
	char *keyword_str = keyword_string;

	FILE *config_file;

	/* Assign a current directory (i.e. the directory from which PHOEBE was     */
	/* started to PHOEBE_STARTUP_DIR; this is used for resolving relative       */
	/* pathnames.                                                               */
	getcwd (working_str, 255);
	PHOEBE_STARTUP_DIR = strdup (working_str);

	/* Get the current locale decimal point, store it to the global variable,   */
	/* change it to "C" and change it back to original upon exit.               */
	PHOEBE_INPUT_LOCALE = strdup (setlocale (LC_NUMERIC, NULL));
	setlocale (LC_NUMERIC, "C");

	if (getenv ("HOME") == NULL)
		phoebe_fatal ("Environment variable $HOME is not defined. PHOEBE needs this variable\n              to install its configuration files. Please define it with e.g.:\n\n                export HOME=/home/user\n\n              and restart PHOEBE.\n");
	USER_HOME_DIR = strdup (getenv ("HOME"));

	/* Although it sounds silly, let's check full permissions of the home di-   */
	/* rectory:                                                                 */
	if (!filename_has_full_permissions (USER_HOME_DIR))
		phoebe_fatal ("Your home directory (defined by $HOME variable) doesn't exist or it doesn't\n              have proper permissions set (e.g. 755). Please correct this and restart\n              PHOEBE.\n");

	/* Everything OK, let's initialize PHOEBE environment file:                 */
	sprintf (working_str, "%s/.phoebe2", USER_HOME_DIR);
	PHOEBE_HOME_DIR = strdup (working_str);
	sprintf (working_str, "%s/phoebe.config", PHOEBE_HOME_DIR);
	PHOEBE_CONFIG = strdup (working_str);

	/* Read out the configuration from the config file.                         */
	if (filename_exists (PHOEBE_CONFIG))
		{
		config_file = fopen (PHOEBE_CONFIG, "r");

		while (!feof (config_file))
			{
			/* The following line reads the line from the input file and checks if  */
			/* everything went OK; if en error occured (e.g. EoF reached), it bre-  */
			/* aks the loop.                                                        */

			if (fgets (keyword_str, 254, config_file) == NULL) break;

			if (strstr (keyword_str, "PHOEBE_BASE_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_BASE_DIR %s", working_str) != 1) PHOEBE_BASE_DIR = strdup ("");
				else PHOEBE_BASE_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_SOURCE_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_SOURCE_DIR %s", working_str) != 1) PHOEBE_SOURCE_DIR = strdup ("");
				else PHOEBE_SOURCE_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_DEFAULTS_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_DEFAULTS_DIR %s", working_str) != 1) PHOEBE_DEFAULTS_DIR = strdup ("");
				else PHOEBE_DEFAULTS_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_TEMP_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_TEMP_DIR %s", working_str) != 1) PHOEBE_TEMP_DIR = strdup ("");
				else PHOEBE_TEMP_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_DATA_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_DATA_DIR %s", working_str) != 1) PHOEBE_DATA_DIR = strdup ("");
				else PHOEBE_DATA_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_FF_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_FF_DIR %s", working_str) != 1) PHOEBE_FF_DIR = strdup ("");
				else PHOEBE_FF_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_PLOTTING_PACKAGE") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_PLOTTING_PACKAGE %s", working_str) != 1) PHOEBE_PLOTTING_PACKAGE = strdup ("");
				else PHOEBE_PLOTTING_PACKAGE = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_LD_SWITCH") != NULL)
				if (sscanf (keyword_str, "PHOEBE_LD_SWITCH %d", &PHOEBE_LD_SWITCH) != 1) PHOEBE_LD_SWITCH = 0;
			if (strstr (keyword_str, "PHOEBE_LD_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_LD_DIR %s", working_str) != 1) PHOEBE_LD_DIR = strdup ("");
				else PHOEBE_LD_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_KURUCZ_SWITCH") != NULL)
				if (sscanf (keyword_str, "PHOEBE_KURUCZ_SWITCH %d", &PHOEBE_KURUCZ_SWITCH) != 1) PHOEBE_KURUCZ_SWITCH = 0;
			if (strstr (keyword_str, "PHOEBE_KURUCZ_DIR") != NULL)
				{
				if (sscanf (keyword_str, "PHOEBE_KURUCZ_DIR %s", working_str) != 1) PHOEBE_KURUCZ_DIR = strdup ("");
				else PHOEBE_KURUCZ_DIR = strdup (working_str);
				}
			if (strstr (keyword_str, "PHOEBE_3D_PLOT_CALLBACK_OPTION") != NULL)
				if (sscanf (keyword_str, "PHOEBE_3D_PLOT_CALLBACK_OPTION %d", &PHOEBE_3D_PLOT_CALLBACK_OPTION) != 1) PHOEBE_3D_PLOT_CALLBACK_OPTION = 0;
			if (strstr (keyword_str, "PHOEBE_CONFIRM_ON_SAVE") != NULL)
				if (sscanf (keyword_str, "PHOEBE_CONFIRM_ON_SAVE %d", &PHOEBE_CONFIRM_ON_SAVE) != 1) PHOEBE_CONFIRM_ON_SAVE = 1;
			if (strstr (keyword_str, "PHOEBE_CONFIRM_ON_QUIT") != NULL)
				if (sscanf (keyword_str, "PHOEBE_CONFIRM_ON_QUIT %d", &PHOEBE_CONFIRM_ON_QUIT) != 1) PHOEBE_CONFIRM_ON_QUIT = 1;
			if (strstr (keyword_str, "PHOEBE_WARN_ON_SYNTHETIC_SCATTER") != NULL)
				if (sscanf (keyword_str, "PHOEBE_WARN_ON_SYNTHETIC_SCATTER %d", &PHOEBE_WARN_ON_SYNTHETIC_SCATTER) != 1) PHOEBE_WARN_ON_SYNTHETIC_SCATTER = 1;
			}
		fclose (config_file);
		}

	if (!filename_exists (PHOEBE_CONFIG))             /* Config file is missing */
		phoebe_fatal ("Configuration file missing. Please start PHOEBE in interactive mode first.\n");

	/* All PHOEBE parameters are referenced globally, so we have to initialize  */
	/* them before they could be used.                                          */
	declare_all_parameters ();
	}
