#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "phoebe_build_config.h"

#include "phoebe_error_handling.h"
#include "phoebe_global.h"

int intern_scripter_print_help (const char *synopsis, const char *summary, const char *description)
	{
	/* This function takes all fields and writes them to screen in a unified    */
	/* manner.                                                                  */

	printf ("\n");
	printf ("  Synopsis:\t%s\n", synopsis);
	printf ("  Summary:\t%s\n", summary);
	printf ("  Description:\t%s\n\n", description);
	}

int scripter_directive_help (char *command)
	{
	/* This function gives help about a particular command passed as argument.  */

	if (strlen (command) == 0)
		{
		/* This means generic help directive with no arguments passed.            */
		printf ("\n  This is PHOEBE %s scripter. For general help on PHOEBE\n", PHOEBE_VERSION_NUMBER);
		printf ("  scripting please refer to PHOEBE API documentation. For specific online help\n");
		printf ("  use 'help help' or 'help command'. To quit, use 'quit'.\n\n");
		}
	else if (strcmp (command, "help") == 0)
		intern_scripter_print_help ("help [command]", "PHOEBE scripter's online help on commands and directives", "Please refer to PHOEBE API for further assistance.");
	else
		{
		printf ("\n  Sorry, command or directive '%s' isn't recognized.\n", command);
		printf ("  To list available commands and directives, use 'list'.\n\n");
		}

	return 0;
	}

int scripter_directive_quit ()
	{
	int c;

	phoebe_scripter_output ("are you sure you want to quit [y/N]: ");
	c = getchar ();
	if ( ( c  == 'y' ) || (c == 'Y') )
		exit (0);
	
	return 0;
	}

int scripter_execute_directive (char *directive, char *argument)
	{
	printf ("entered with directive %s.\n", directive);
	if (strcmp (directive, "help") == 0)
		scripter_directive_help (argument);
	}
