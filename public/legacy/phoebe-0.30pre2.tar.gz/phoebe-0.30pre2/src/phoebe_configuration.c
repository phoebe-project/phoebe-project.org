#include "phoebe_build_config.h"

#include <stdio.h>
#include "phoebe_global.h"

void configuration_save_file ()
	{
	/* This function will go through all global PHOEBE keywords that are set    */
	/* via Configuration window and write them to the configuration file. The   */
	/* function that defines these global variables is called right before this */
	/* function, so all error handling is done there. This function only flush- */
	/* es the values to the disk.                                               */

	FILE *CONFIG_FILE = fopen (PHOEBE_CONFIG, "w");

	fprintf (CONFIG_FILE, "PHOEBE_BASE_DIR                  %s\n", PHOEBE_BASE_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_SOURCE_DIR                %s\n", PHOEBE_SOURCE_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_DEFAULTS_DIR              %s\n", PHOEBE_DEFAULTS_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_TEMP_DIR                  %s\n", PHOEBE_TEMP_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_DATA_DIR                  %s\n", PHOEBE_DATA_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_FF_DIR                    %s\n", PHOEBE_FF_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_PLOTTING_PACKAGE          %s\n", PHOEBE_PLOTTING_PACKAGE);
	fprintf (CONFIG_FILE, "PHOEBE_LD_SWITCH                 %d\n", PHOEBE_LD_SWITCH);
	fprintf (CONFIG_FILE, "PHOEBE_LD_DIR                    %s\n", PHOEBE_LD_DIR);
	fprintf (CONFIG_FILE, "PHOEBE_3D_PLOT_CALLBACK_OPTION   %d\n", PHOEBE_3D_PLOT_CALLBACK_OPTION);
	fprintf (CONFIG_FILE, "PHOEBE_CONFIRM_ON_SAVE           %d\n", PHOEBE_CONFIRM_ON_SAVE);
	fprintf (CONFIG_FILE, "PHOEBE_CONFIRM_ON_QUIT           %d\n", PHOEBE_CONFIRM_ON_QUIT);
	fprintf (CONFIG_FILE, "PHOEBE_WARN_ON_SYNTHETIC_SCATTER %d\n", PHOEBE_WARN_ON_SYNTHETIC_SCATTER);

	fclose (CONFIG_FILE);
	}
