#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "phoebe_build_config.h"

#include "phoebe_accessories.h"
#include "phoebe_connectivity.h"
#include "phoebe_error_handling.h"
#include "phoebe_global.h"
#include "phoebe_keywords.h"

void declare_parameter (char *qualifier, char *bond, char *keyword, char *description, ...)
	{
	/* This function adds an empty record to the PHOEBE_parameter struct (defi- */
	/* ned in phoebe_global.h dynamically and fills it in with values given as  */
	/* arguments to this function. It should be called *only* by declare_all_   */
	/* _parameters () function.                                                 */
	/*                                                                          */
	/* This function handles two types of parameters - native types (all ints,  */
	/* doubles, char *s, ...) and parameter arrays. In case of the latter, no   */
	/* initialization is performed, since the array sizes depend on particular  */
	/* bond parameters (e.g. LC number, ...).                                   */

	va_list args;
	int i = PHOEBE_parameters_no;

	PHOEBE_parameters_no++;
	PHOEBE_parameters = realloc (PHOEBE_parameters, PHOEBE_parameters_no * (sizeof (*PHOEBE_parameters)));

	PHOEBE_parameters[i].qualifier   = strdup (qualifier);
	PHOEBE_parameters[i].bond        = strdup (bond);
	PHOEBE_parameters[i].keyword     = strdup (keyword);
	PHOEBE_parameters[i].description = strdup (description);

	va_start (args, description);
	PHOEBE_parameters[i].type        = va_arg (args, PHOEBE_type);

	switch (PHOEBE_parameters[i].type)
		{
		case TYPE_INT:
			PHOEBE_parameters[i].value.i = va_arg (args, int);
		break;
		case TYPE_DOUBLE:
			PHOEBE_parameters[i].value.d = va_arg (args, double);
		break;
		case TYPE_BOOL:
			PHOEBE_parameters[i].value.b = va_arg (args, bool);
		break;
		case TYPE_STRING:
			{
			char *str = va_arg (args, char *);
			PHOEBE_parameters[i].value.str = phoebe_malloc (strlen (str) + 1);
			strcpy (PHOEBE_parameters[i].value.str, str);
			}
		break;
		case TYPE_INT_ARRAY:
			PHOEBE_parameters[i].value.iarray = NULL;
		break;
		case TYPE_DOUBLE_ARRAY:
			PHOEBE_parameters[i].value.darray = NULL;
		break;
		case TYPE_BOOL_ARRAY:
			PHOEBE_parameters[i].value.barray = NULL;
		break;
		case TYPE_STRING_ARRAY:
			PHOEBE_parameters[i].value.strarray = NULL;
		break;
		}
	va_end (args);
	}

void update_parameter_arrays (char *bond, int oldval)
	{
	int dim = PHOEBE_parameters[phoebe_index_from_qualifier(bond)].value.i;
	int i, j;
	PHOEBE_type type;

	for (i = 0; i < PHOEBE_parameters_no; i++)
		if (strcmp (PHOEBE_parameters[i].bond, bond) == 0)
			{
			type = PHOEBE_parameters[i].type;
			switch (type)
				{
				case TYPE_INT_ARRAY:
					PHOEBE_parameters[i].value.iarray = phoebe_realloc (PHOEBE_parameters[i].value.iarray, dim * sizeof (int));
					for (j = oldval; j < dim; j++)
						PHOEBE_parameters[i].value.iarray[j] = 0;
				break;
				case TYPE_BOOL_ARRAY:
					PHOEBE_parameters[i].value.barray = phoebe_realloc (PHOEBE_parameters[i].value.barray, dim * sizeof (bool));
					for (j = oldval; j < dim; j++)
						PHOEBE_parameters[i].value.barray[j] = NO;
				break;
				case TYPE_DOUBLE_ARRAY:
					PHOEBE_parameters[i].value.darray = phoebe_realloc (PHOEBE_parameters[i].value.darray, dim * sizeof (double));
					for (j = oldval; j < dim; j++)
						PHOEBE_parameters[i].value.darray[j] = 0.0;
				break;
				case TYPE_STRING_ARRAY:
					PHOEBE_parameters[i].value.strarray = phoebe_realloc (PHOEBE_parameters[i].value.darray, dim * sizeof (char *));
					for (j = oldval; j < dim; j++)
						PHOEBE_parameters[i].value.strarray[j] = strdup ("");
				break;
				}
			}
	}

void declare_all_parameters ()
	{
	/* This (and only this) function holds all parameters that are accessible   */
	/* to PHOEBE; there is no GUI connection or any other plug-in connection in */
	/* this function, only native PHOEBE parameters.                            */

	/* **********************   Data tab parameters   ************************* */

	declare_parameter ("phoebe_name_value",          "",                  "NAME",          "Star name",                                     TYPE_STRING,       "");
	declare_parameter ("phoebe_model_value",         "",                  "MODEL",         "Model (applied constraints)",                   TYPE_STRING,       "General binary system (no constraints)");
	declare_parameter ("phoebe_lcno_value",          "bond",              "LCNO",          "Number of experimental light curves",           TYPE_INT,          0);
	declare_parameter ("phoebe_rvno_value",          "bond",              "RVNO",          "Number of experimental radial velocity curves", TYPE_INT,          0);
	declare_parameter ("phoebe_spno_value",          "bond",              "SPNO",          "Number of experimental spectra",                TYPE_INT,          0);
	declare_parameter ("phoebe_mnorm_value",         "",                  "MNORM",         "Flux-normalizing magnitude",                    TYPE_DOUBLE,       10.0);
	declare_parameter ("phoebe_binning_switch",      "",                  "BINSWITCH",     "Data binning",                                  TYPE_BOOL,         NO);
	declare_parameter ("phoebe_binno_value",         "",                  "BINNO",         "Number of bins",                                TYPE_INT,          100);
	declare_parameter ("phoebe_reddening_switch",    "",                  "REDSWITCH",     "Interstellar extinction (reddening)",           TYPE_BOOL,         NO);
	declare_parameter ("phoebe_reddeningr_value",    "",                  "REDFACTOR",     "Interstellar extinction coefficient",           TYPE_DOUBLE,       3.1);
	declare_parameter ("phoebe_reddeninge_value",    "",                  "REDEXCESS",     "Interstellar extinction color excess value",    TYPE_DOUBLE,       0.0);
	declare_parameter ("phoebe_rv1proximity_switch", "",                  "RV1PROXSWITCH", "Proximity effects for primary star",            TYPE_BOOL,         YES);
	declare_parameter ("phoebe_rv2proximity_switch", "",                  "RV2PROXSWITCH", "Proximity effects for secondary star",          TYPE_BOOL,         YES);
	declare_parameter ("phoebe_lc_filename",         "phoebe_lcno_value", "LCFILENAME",    "Experimental LC data filename",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_lc_sigma",            "phoebe_lcno_value", "LCSIGMA",       "Experimental LC data standard deviation",       TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lc_filter",           "phoebe_lcno_value", "LCFILTER",      "Experimental LC data filter",                   TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_lc_column1",          "phoebe_lcno_value", "LCCOLUMN1",     "Experimental LC data column 1",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_lc_column2",          "phoebe_lcno_value", "LCCOLUMN2",     "Experimental LC data column 2",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_lc_column3",          "phoebe_lcno_value", "LCCOLUMN3",     "Experimental LC data column 3",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_lc_weighting",        "phoebe_lcno_value", "LCWEIGHTING",   "Experimental LC data weighting",                TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_rv_filename",         "phoebe_rvno_value", "RVFILENAME",    "Experimental RV data filename",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_rv_sigma",            "phoebe_rvno_value", "RVSIGMA",       "Experimental RV data standard deviation",       TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rv_filter",           "phoebe_rvno_value", "RVFILTER",      "Experimental RV data filter",                   TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_rv_column1",          "phoebe_rvno_value", "RVCOLUMN1",     "Experimental RV data column 1",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_rv_column2",          "phoebe_rvno_value", "RVCOLUMN2",     "Experimental RV data column 2",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_rv_column3",          "phoebe_rvno_value", "RVCOLUMN3",     "Experimental RV data column 3",                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_sp_filename",         "phoebe_spno_value", "SPFILENAME",    "Experimental spectra data filename",            TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_sp_sigma",            "phoebe_spno_value", "SPSIGMA",       "Experimental spectra data standard deviation",  TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_sp_filter",           "phoebe_spno_value", "SPFILTER",      "Experimental spectra data filter",              TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_sp_column1",          "phoebe_spno_value", "SPCOLUMN1",     "Experimental spectra data column 1",            TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_sp_column2",          "phoebe_spno_value", "SPCOLUMN2",     "Experimental spectra data column 2",            TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_sp_column3",          "phoebe_spno_value", "SPCOLUMN3",     "Experimental spectra data column 3",            TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_time_switch",         "",                  "TIMESWITCH",    "HJD as independent variable",                   TYPE_BOOL,         NO);
	declare_parameter ("phoebe_phase_switch",        "",                  "PHASESWITCH",   "Phase as independent variable",                 TYPE_BOOL,         YES);

	/* *********************   System tab parameters   ************************ */

	declare_parameter ("phoebe_hjd0_value",          "",                  "HJD0VAL", "Heliocentric Julian date ephemeris origin",         TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_hjd0_adjust",         "",                  "HJD0ADJ", "",                                                 TYPE_BOOL,   NO);
	declare_parameter ("phoebe_hjd0_step",           "",                  "HJD0STEP", "",                                            TYPE_DOUBLE, 0.0001);
	declare_parameter ("phoebe_hjd0_min",            "",                  "HJD0MIN", "",                                              TYPE_DOUBLE, -1E10);
	declare_parameter ("phoebe_hjd0_max",            "",                  "HJD0MAX", "",                                              TYPE_DOUBLE, 1E10);
	declare_parameter ("phoebe_period_value",        "",                  "PERIODVAL", "Orbital period in days",                        TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_period_adjust",       "",                  "PERIODADJ", "",                                             TYPE_BOOL,   NO);
	declare_parameter ("phoebe_period_step",         "",                  "PERIODSTEP", "",                                        TYPE_DOUBLE, 0.0001);
	declare_parameter ("phoebe_period_min",          "",                  "PERIODMIN", "",                                          TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_period_max",          "",                  "PERIODMAX", "",                                          TYPE_DOUBLE, 1000.0);
	declare_parameter ("phoebe_dpdt_value",          "",                  "DPDTVAL", "First time derivative of period (days per day)",    TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_dpdt_adjust",         "",                  "DPDTADJ", "",                                                 TYPE_BOOL,   NO);
	declare_parameter ("phoebe_dpdt_step",           "",                  "DPDTSTEP", "",                                            TYPE_DOUBLE, 0.0001);
	declare_parameter ("phoebe_dpdt_min",            "",                  "DPDTMIN", "",                                              TYPE_DOUBLE, -1.0);
	declare_parameter ("phoebe_dpdt_max",            "",                  "DPDTMAX", "",                                              TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_pshift_value",        "",                  "PSHIFTVAL", "Phase shift",                                   TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_pshift_adjust",       "",                  "PSHIFTADJ", "",                                             TYPE_BOOL,   NO);
	declare_parameter ("phoebe_pshift_step",         "",                  "PSHIFTSTEP", "",                                        TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_pshift_min",          "",                  "PSHIFTMIN", "",                                          TYPE_DOUBLE, -0.5);
	declare_parameter ("phoebe_pshift_max",          "",                  "PSHIFTMAX", "",                                          TYPE_DOUBLE, 0.5);
	declare_parameter ("phoebe_sma_value",           "",                  "SMAVAL", "Semi-major axis in solar radii",                      TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_sma_adjust",          "",                  "SMAADJ", "",                                                   TYPE_BOOL,   NO);
	declare_parameter ("phoebe_sma_step",            "",                  "SMASTEP", "",                                              TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_sma_min",             "",                  "SMAMIN", "",                                                TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_sma_max",             "",                  "SMAMAX", "",                                                TYPE_DOUBLE, 1000.0);
	declare_parameter ("phoebe_rm_value",            "",                  "RMVAL", "Mass ratio (secondary over primary",                    TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_rm_adjust",           "",                  "RMADJ", "",                                                     TYPE_BOOL,   NO);
	declare_parameter ("phoebe_rm_step",             "",                  "RMSTEP", "",                                                TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_rm_min",              "",                  "RMMIN", "",                                                  TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_rm_max",              "",                  "RMMAX", "",                                                  TYPE_DOUBLE, 50.0);
	declare_parameter ("phoebe_incl_value",          "",                  "INCLVAL", "Inclination in degrees",                            TYPE_DOUBLE, 80.0);
	declare_parameter ("phoebe_incl_adjust",         "",                  "INCLADJ", "",                                                 TYPE_BOOL,   NO);
	declare_parameter ("phoebe_incl_step",           "",                  "INCLSTEP", "",                                            TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_incl_min",            "",                  "INCLMIN", "",                                              TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_incl_max",            "",                  "INCLMAX", "",                                              TYPE_DOUBLE, 180.0);
	declare_parameter ("phoebe_vga_value",           "",                  "VGAVAL", "Center-of-mass velocity in km/s",                     TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_vga_adjust",          "",                  "VGAADJ", "",                                                   TYPE_BOOL,   NO);
	declare_parameter ("phoebe_vga_step",            "",                  "VGASTEP", "",                                              TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_vga_min",             "",                  "VGAMIN", "",                                                TYPE_DOUBLE, -1000.0);
	declare_parameter ("phoebe_vga_max",             "",                  "VGAMAX", "",                                                TYPE_DOUBLE, 1000.0);

	/* *******************   Component tab parameters   *********************** */

	declare_parameter ("phoebe_tavh_value",          "",                  "TAVHVAL", "Primary star effective temperature in Kelvin",   TYPE_DOUBLE, 6000.0);
	declare_parameter ("phoebe_tavh_adjust",         "",                  "TAVHADJ", "",                                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_tavh_step",           "",                  "TAVHSTEP", "",                                              TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_tavh_min",            "",                  "TAVHMIN", "",                                               TYPE_DOUBLE, 3500.0);
	declare_parameter ("phoebe_tavh_max",            "",                  "TAVHMAX", "",                                               TYPE_DOUBLE, 50000.0);
	declare_parameter ("phoebe_tavc_value",          "",                  "TAVCVAL", "Secondary star effective temperature in Kelvin", TYPE_DOUBLE, 6000.0);
	declare_parameter ("phoebe_tavc_adjust",         "",                  "TAVCADJ", "",                                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_tavc_step",           "",                  "TAVCSTEP", "",                                              TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_tavc_min",            "",                  "TAVCMIN", "",                                               TYPE_DOUBLE, 3500.0);
	declare_parameter ("phoebe_tavc_max",            "",                  "TAVCMAX", "",                                               TYPE_DOUBLE, 50000.0);
	declare_parameter ("phoebe_phsv_value",          "",                  "PHSVVAL", "Primary star surface potential",                 TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_phsv_adjust",         "",                  "PHSVADJ", "",                                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_phsv_step",           "",                  "PHSVSTEP", "",                                              TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_phsv_min",            "",                  "PHSVMIN", "",                                               TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_phsv_max",            "",                  "PHSVMAX", "",                                               TYPE_DOUBLE, 1000.0);
	declare_parameter ("phoebe_pcsv_value",          "",                  "PCSVVAL", "Secondary star surface potential",               TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_pcsv_adjust",         "",                  "PCSVADJ", "",                                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_pcsv_step",           "",                  "PCSVSTEP", "",                                              TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_pcsv_min",            "",                  "PCSVMIN", "",                                               TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_pcsv_max",            "",                  "PCSVMAX", "",                                               TYPE_DOUBLE, 1000.0);
	declare_parameter ("phoebe_logg1_value",         "",                  "LOGG1VAL", "Primary star gravity acceleration [cgs]",       TYPE_DOUBLE, 4.3);
	declare_parameter ("phoebe_logg1_adjust",        "",                  "LOGG1ADJ", "",                                              TYPE_BOOL,   NO);
	declare_parameter ("phoebe_logg1_step",          "",                  "LOGG1STEP", "",                                             TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_logg1_min",           "",                  "LOGG1MIN", "",                                              TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_logg1_max",           "",                  "LOGG1MAX", "",                                              TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_logg2_value",         "",                  "LOGG2VAL", "Secondary star gravity acceleration [cgs]",     TYPE_DOUBLE, 4.3);
	declare_parameter ("phoebe_logg2_adjust",        "",                  "LOGG2ADJ", "",                                              TYPE_BOOL,   NO);
	declare_parameter ("phoebe_logg2_step",          "",                  "LOGG2STEP", "",                                             TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_logg2_min",           "",                  "LOGG2MIN", "",                                              TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_logg2_max",           "",                  "LOGG2MAX", "",                                              TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_met1_value",          "",                  "MET1VAL", "Primary star metallicity [solar abundances]",    TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_met1_adjust",         "",                  "MET1ADJ", "",                                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_met1_step",           "",                  "MET1STEP", "",                                              TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_met1_min",            "",                  "MET1MIN", "",                                               TYPE_DOUBLE, -10.0);
	declare_parameter ("phoebe_met1_max",            "",                  "MET1MAX", "",                                               TYPE_DOUBLE, 10.0);
	declare_parameter ("phoebe_met2_value",          "",                  "MET2VAL", "Secondary star metallicity [solar abundances]",  TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_met2_adjust",         "",                  "MET2ADJ", "",  																						 TYPE_BOOL,   NO);
	declare_parameter ("phoebe_met2_step",           "",                  "MET2STEP", "", 																				     TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_met2_min",            "",                  "MET2MIN", "", 																					     TYPE_DOUBLE, -10.0);
	declare_parameter ("phoebe_met2_max",            "",                  "MET2MAX", "", 																					     TYPE_DOUBLE, 10.0);

	/* *********************   Orbit tab parameters   ************************* */

	declare_parameter ("phoebe_ecc_value",           "",                  "ECCVAL", "Orbital eccentricity",                                 TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_ecc_adjust",          "",                  "ECCADJ", "",                                                    TYPE_BOOL,   NO);
	declare_parameter ("phoebe_ecc_step",            "",                  "ECCSTEP", "",                                               TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_ecc_min",             "",                  "ECCMIN", "",                                                 TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_ecc_max",             "",                  "ECCMAX", "",                                                 TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_perr0_value",         "",                  "PERR0VAL", "Argument of periastron",                           TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_perr0_adjust",        "",                  "PERR0ADJ", "",                                                TYPE_BOOL,   NO);
	declare_parameter ("phoebe_perr0_step",          "",                  "PERR0STEP", "",                                           TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_perr0_min",           "",                  "PERR0MIN", "",                                             TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_perr0_max",           "",                  "PERR0MAX", "",                                             TYPE_DOUBLE, 6.28319);
	declare_parameter ("phoebe_dperdt_value",        "",                  "DPERDTVAL", "First time derivative of periastron",            TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_dperdt_adjust",       "",                  "DPERDTADJ", "",                                              TYPE_BOOL,   NO);
	declare_parameter ("phoebe_dperdt_step",         "",                  "DPERDTSTEP", "",                                         TYPE_DOUBLE, 0.0001);
	declare_parameter ("phoebe_dperdt_min",          "",                  "DPERDTMIN", "",                                           TYPE_DOUBLE, -1.0);
	declare_parameter ("phoebe_dperdt_max",          "",                  "DPERDTMAX", "",                                           TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_f1_value",            "",                  "F1VAL", "Primary star synchronicity parameter",                   TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_f1_adjust",           "",                  "F1ADJ", "",                                                      TYPE_BOOL,   NO);
	declare_parameter ("phoebe_f1_step",             "",                  "F1STEP", "",                                                 TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_f1_min",              "",                  "F1MIN", "",                                                   TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_f1_max",              "",                  "F1MAX", "",                                                   TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_f2_value",            "",                  "F2VAL", "Secondary star synchronicity parameter",                 TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_f2_adjust",           "",                  "F2ADJ", "",                                                     TYPE_BOOL,   NO);
	declare_parameter ("phoebe_f2_step",             "",                  "F2STEP", "",                                                TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_f2_min",              "",                  "F2MIN", "",                                                   TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_f2_max",              "",                  "F2MAX", "",                                                   TYPE_DOUBLE, 1.0);

	/* ********************   Surface tab parameters   ************************ */

	declare_parameter ("phoebe_alb1_value",          "",                  "ALB1VAL", "Primary star albedo",                                                    TYPE_DOUBLE, 0.6);
	declare_parameter ("phoebe_alb1_adjust",         "",                  "ALB1ADJ", "",                                                                      TYPE_BOOL,   NO);
	declare_parameter ("phoebe_alb1_step",           "",                  "ALB1STEP", "",                                                                 TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_alb1_min",            "",                  "ALB1MIN", "",                                                                   TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_alb1_max",            "",                  "ALB1MAX", "",                                                                   TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_alb2_value",          "",                  "ALB2VAL", "Secondary star albedo",                                                  TYPE_DOUBLE, 0.6);
	declare_parameter ("phoebe_alb2_adjust",         "",                  "ALB2ADJ", "",                                                                      TYPE_BOOL,   NO);
	declare_parameter ("phoebe_alb2_step",           "",                  "ALB2STEP", "",                                                                 TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_alb2_min",            "",                  "ALB2MIN", "",                                                                    TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_alb2_max",            "",                  "ALB2MAX", "",                                                                    TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_gr1_value",           "",                  "GR1VAL", "Primary star gravity brightening",                                         TYPE_DOUBLE, 0.32);
	declare_parameter ("phoebe_gr1_adjust",          "",                  "GR1ADJ", "",                                                                        TYPE_BOOL,   NO);
	declare_parameter ("phoebe_gr1_step",            "",                  "GR1STEP", "",                                                                   TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_gr1_min",             "",                  "GR1MIN", "",                                                                     TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_gr1_max",             "",                  "GR1MAX", "",                                                                     TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_gr2_value",           "",                  "GR2VAL", "Secondary star gravity brightening",                                       TYPE_DOUBLE, 0.32);
	declare_parameter ("phoebe_gr2_adjust",          "",                  "GR2ADJ", "",                                                                         TYPE_BOOL,   NO);
	declare_parameter ("phoebe_gr2_step",            "",                  "GR2STEP", "",                                                                    TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_gr2_min",             "",                  "GR2MIN", "",                                                                     TYPE_DOUBLE, 0.0);
	declare_parameter ("phoebe_gr2_max",             "",                  "GR2MAX", "",                                                                     TYPE_DOUBLE, 1.0);
	declare_parameter ("phoebe_hla_value",           "phoebe_lcno_value", "HLAVAL", "",                                                          TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_hla_adjust",          "",                  "HLAADJ", "",                                                                        TYPE_BOOL,   NO);
	declare_parameter ("phoebe_hla_step",            "",                  "HLASTEP", "",                                                                   TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_cla_value",           "phoebe_lcno_value", "CLAVAL", "",                                                          TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_cla_adjust",          "",                  "CLAADJ", "",                                                                        TYPE_BOOL,   NO);
	declare_parameter ("phoebe_cla_step",            "",                  "CLASTEP", "",                                                                   TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_decouplecla_switch",  "",                  "DECOUPLECLA", "Decouple secondary star surface brightness levels from temperature", TYPE_BOOL,   NO);
	declare_parameter ("phoebe_atm1_switch",         "",                  "ATM1SWITCH", "Use stellar atmosphere model for primary star",                     TYPE_BOOL,   YES);
	declare_parameter ("phoebe_atm2_switch",         "",                  "ATM2SWITCH", "Use stellar atmosphere model for secondary star",                   TYPE_BOOL,   YES);
	declare_parameter ("phoebe_el3_value",           "phoebe_lcno_value", "EL3VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_el3_adjust",          "",                  "EL3ADJ", "",                                                                        TYPE_BOOL,   NO);
	declare_parameter ("phoebe_el3_step",            "",                  "EL3STEP", "",                                                                   TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_opsf_value",          "phoebe_lcno_value", "OPSFVAL", "",                                                           TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_opsf_adjust",         "",                  "OPSFADJ", "",                                                                      TYPE_BOOL,   NO);
	declare_parameter ("phoebe_opsf_step",           "",                  "OPSFSTEP", "",                                                                 TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_reflection_switch",   "",                  "NREFSWITCH", "Detailed reflection effect",                                         TYPE_BOOL,   NO);
	declare_parameter ("phoebe_reflection_value",    "",                  "NREFVAL", "Number of reflections taken into account",                               TYPE_INT,    2);
	declare_parameter ("phoebe_n1f_value",           "",                  "N1F",  "Fine grid size on primary star",                                            TYPE_INT,    20);
	declare_parameter ("phoebe_n2f_value",           "",                  "N2F",  "Fine grid size on secondary star",                                          TYPE_INT,    20);
	declare_parameter ("phoebe_n1c_value",           "",                  "N1C", "Coarse grid size on primary star",                                            TYPE_INT,    5);
	declare_parameter ("phoebe_n2c_value",           "",                  "N2C", "Coarse grid size on secondary star",                                          TYPE_INT,    5);

	/* ******************   Perturbations tab parameters   ******************** */

	declare_parameter ("phoebe_ldmodel_value",       "",                   "LDMODEL", "Limb darkening model",                                                       TYPE_STRING, "Logarithmic law");
	declare_parameter ("phoebe_xbol1_value",         "",                   "XBOL1",   "Limb darkening linear bolometric coefficient for primary star",              TYPE_DOUBLE, 0.5);
	declare_parameter ("phoebe_ybol1_value",         "",                   "YBOL1",   "Limb darkening non-linear bolometric coefficient for primary star",          TYPE_DOUBLE, 0.5);
	declare_parameter ("phoebe_xbol2_value",         "",                   "XBOL2",   "Limb darkening linear bolometric coefficient for secondary star",            TYPE_DOUBLE, 0.5);
	declare_parameter ("phoebe_ybol2_value",         "",                   "YBOL2",   "Limb darkening non-linear bolometric coefficient for secondary star",        TYPE_DOUBLE, 0.5);
	declare_parameter ("phoebe_lcx1_value",          "phoebe_lcno_value",  "LCX1VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lcy1_value",          "phoebe_lcno_value",  "LCY1VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lcx2_value",          "phoebe_lcno_value",  "LCX2VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lcy2_value",          "phoebe_lcno_value",  "LCY2VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lcx1_adjust",         "",                   "LCX1ADJ", "",                                                                             TYPE_BOOL,   NO);
	declare_parameter ("phoebe_lcx2_adjust",         "",                   "LCX2ADJ", "",                                                                             TYPE_BOOL,   NO);
	declare_parameter ("phoebe_lcx1_step",           "",                   "LCX1STEP", "",                                                                        TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_lcx2_step",           "",                   "LCX2STEP", "",                                                                        TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_rvx1_value",          "phoebe_rvno_value",  "RVX1VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rvy1_value",          "phoebe_rvno_value",  "RVY1VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rvx2_value",          "phoebe_rvno_value",  "RVX2VAL", "",                                                            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rvy2_value",          "phoebe_rvno_value",  "RVY2VAL", "",                                                            TYPE_DOUBLE_ARRAY);

	declare_parameter ("phoebe_sprim_value",         "bond",               "SPRIMVAL", "Number of spots on primary star",                                        TYPE_INT,    0);
	declare_parameter ("phoebe_ssec_value",          "bond",               "SSECVAL", "Number of spots on secondary star",                                        TYPE_INT,    0);
	declare_parameter ("phoebe_ifsmv1_switch",       "",                   "IFSMV1", "Do the spots on primary star move?",                                     TYPE_BOOL,   NO);
	declare_parameter ("phoebe_ifsmv2_switch",       "",                   "IFSMV2", "Do the spots on secondary star move?",                                   TYPE_BOOL,   NO);
	declare_parameter ("phoebe_lat1_value",          "phoebe_sprim_value", "LAT1VAL", "Latitude of the spot on primary star",                    TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_long1_value",         "phoebe_sprim_value", "LONG1VAL", "Longitude of the spot on primary star",                  TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_radsp1_value",        "phoebe_sprim_value", "RADSP1VAL", "Radius of the spot on primary star",                    TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_temsp1_value",        "phoebe_sprim_value", "TEMSP1VAL", "Temperature factor of the spot on primary star",        TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lat2_value",          "phoebe_ssec_value",  "LAT2VAL", "Latitude of the spot on secondary star",                 TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_long2_value",         "phoebe_ssec_value",  "LONG2VAL", "Longitude of the spot on secondary star",               TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_radsp2_value",        "phoebe_ssec_value",  "RADSP2VAL", "Radius of the spot on secondary star",                 TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_temsp2_value",        "phoebe_ssec_value",  "TEMSP2VAL", "Temperature factor of the spot on secondary star",     TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lat1_*djust",         "",                   "LAT1ADJ", "",                                                                       TYPE_BOOL,   NO);
	declare_parameter ("phoebe_long1_*djust",        "",                   "LONG1ADJ", "",                                                                     TYPE_BOOL,   NO);
	declare_parameter ("phoebe_radsp1_*djust",       "",                   "RADSP1ADJ", "",                                                                    TYPE_BOOL,   NO);
	declare_parameter ("phoebe_temsp1_*djust",       "",                   "TEMSP1ADJ", "",                                                                    TYPE_BOOL,   NO);
	declare_parameter ("phoebe_lat2_*djust",         "",                   "LAT2ADJ", "",                                                                       TYPE_BOOL,   NO);
	declare_parameter ("phoebe_long2_*djust",        "",                   "LONG2ADJ", "",                                                                     TYPE_BOOL,   NO);
	declare_parameter ("phoebe_radsp2_*djust",       "",                   "RADSP2ADJ", "",                                                                    TYPE_BOOL,   NO);
	declare_parameter ("phoebe_temsp2_*djust",       "",                   "TEMSP2ADJ", "",                                                                    TYPE_BOOL,   NO);
	declare_parameter ("phoebe_lat1_step",           "",                   "LAT1STEP", "",                                                                  TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_long1_step",          "",                   "LONG1STEP", "",                                                                TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_radsp1_step",         "",                   "RADSP1STEP", "",                                                               TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_temsp1_step",         "",                   "TEMSP1STEP", "",                                                               TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_lat2_step",           "",                   "LAT2STEP", "",                                                                  TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_long2_step",          "",                   "LONG2STEP", "",                                                                TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_radsp2_step",         "",                   "RADSP2STEP", "",                                                               TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_temsp2_step",         "",                   "TEMSP2STEP", "",                                                               TYPE_DOUBLE, 0.01);

	/* ********************   Utilities tab parameters   ********************** */

	declare_parameter ("phoebe_scatter_switch",      "",                  "SCATTER", "Synthetic scatter",                                                   TYPE_BOOL,   NO);
	declare_parameter ("phoebe_scatter_sigma",       "",                  "SCATSIGMA", "Synthetic scatter standard deviation",                         TYPE_DOUBLE, 0.01);
	declare_parameter ("phoebe_scatter_seed",        "",                  "SCATSEED", "Synthetic scatter seed",                                         TYPE_DOUBLE, 150000000.0);
	declare_parameter ("phoebe_scatter_weighting",   "",                  "SCATWEIGHTING", "Synthetic scatter weighting",                     TYPE_STRING, "Poissonian scatter");
	declare_parameter ("phoebe_synthred_switch",     "",                  "SYNTHREDSWITCH", "Synthetic interstellar extinction (reddening)",         TYPE_BOOL,   NO);
	declare_parameter ("phoebe_synthredr_value",     "",                  "SYNTHREDFACTOR", "Synthetic interstellar extinction coefficient",        TYPE_DOUBLE, 3.1);
	declare_parameter ("phoebe_synthrede_value",     "",                  "SYNTHREDEXCESS", "Synthetic interstellar extinction color excess value", TYPE_DOUBLE, 0.0);

	/* ******************    Data statistics parameters     ******************* */

	declare_parameter ("phoebe_lc_ptsno_value",      "phoebe_lcno_value", "LCPTSNO",   "Experimental data points number",             TYPE_INT_ARRAY);
	declare_parameter ("phoebe_lc_sum_value",        "phoebe_lcno_value", "LCSUM",     "Experimental data points sum",                TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lc_average_value",    "phoebe_lcno_value", "LCAVERAGE", "Experimental data points average",            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_lc_median_value",     "phoebe_lcno_value", "LCMEDIAN",  "Experimental data points median",             TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rv_ptsno_value",      "phoebe_rvno_value", "RVPTSNO",   "Experimental data points number",             TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rv_sum_value",        "phoebe_rvno_value", "RVSUM",     "Experimental data points sum",                TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rv_average_value",    "phoebe_rvno_value", "RVAVERAGE", "Experimental data points average",            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_rv_median_value",     "phoebe_rvno_value", "RVMEDIAN",  "Experimental data points median",             TYPE_DOUBLE_ARRAY);

	/* ********************   LC plot window parameters   ********************* */

	declare_parameter ("phoebe_lc_indep_variable",   "",                  "LCINDEP", "LC independent output variable",                 TYPE_STRING, "Phase");
	declare_parameter ("phoebe_lc_dep_variable",     "",                  "LCDEP", "LC dependent output variable",                       TYPE_STRING, "Magnitude");
	declare_parameter ("phoebe_lc_phase_start",      "",                  "LCPHSTART",  "LC phase start",                                       TYPE_DOUBLE, -0.6);
	declare_parameter ("phoebe_lc_phase_end",        "",                  "LCPHEND",    "LC phase end",                                         TYPE_DOUBLE, 0.6);
	declare_parameter ("phoebe_lc_vertices_value",   "",                  "LCVERTICES", "LC vertices number",                                   TYPE_INT,    300);
	declare_parameter ("phoebe_lc_alias_switch",     "",                  "LCALIAS", "LC Data aliasing",                                     TYPE_BOOL,   YES);
	declare_parameter ("phoebe_lc_residuals_switch", "",                  "LCRESIDUALS", "LC residuals plot",                               TYPE_BOOL,   NO);
	declare_parameter ("phoebe_plot_lc_column_2",    "phoebe_lcno_value", "PLOTLCCOLUMN2", "",                                                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_plot_lc_column_3",    "phoebe_lcno_value", "PLOTLCCOLUMN3", "",                                                 TYPE_STRING_ARRAY);
	declare_parameter ("phoebe_plot_lc_shift",       "phoebe_lcno_value", "PLOTLCSHIFT", "",                                                   TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_nexp_value",  "phoebe_lcno_value", "LCSTATNEXP",  "Experimental data points number",         TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_aexp_value",  "phoebe_lcno_value", "LCSTATAEXP",  "Experimental data points average",        TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_mexp_value",  "phoebe_lcno_value", "LCSTATMEXP",  "Experimental data points median",         TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_asyn_value",  "phoebe_lcno_value", "LCSTATASYN",  "Synthetic data points average",           TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_msyn_value",  "phoebe_lcno_value", "LCSTATMSYN",  "Synthetic data points median",            TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_sigma_value", "phoebe_lcno_value", "LCSTATSIGMA", "Unweighted standard deviation",           TYPE_DOUBLE_ARRAY);
	declare_parameter ("phoebe_plot_lc_wsig_value",  "phoebe_lcno_value", "LCSTATWSIG",  "Weighted standard deviation",             TYPE_DOUBLE_ARRAY);
	}

char *phoebe_qualifier_from_keyword (char *keyword)
	{
	/* This function returns the qualifier of the given keyword.                */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].keyword, keyword) == 0 )
			return PHOEBE_parameters[i].qualifier;

	phoebe_warning ("phoebe_qualifier_from_keyword () called with keyword\n                '%s', which doesn't exist!\n", keyword);
	return NULL;
	}

char *phoebe_qualifier_from_description (char *description)
	{
	/* This function returns the qualifier of the given description.            */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].description, description) == 0 )
			return PHOEBE_parameters[i].qualifier;

	phoebe_warning ("phoebe_qualifier_from_description () called with description\n                '%s', which doesn't exist!\n", description);
	return NULL;
	}

char *phoebe_keyword_from_qualifier (char *qualifier)
	{
	/* This function returns the keyword of the given qualifier.                */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].qualifier, qualifier) == 0 )
			return PHOEBE_parameters[i].keyword;

	phoebe_warning ("phoebe_keyword_from_qualifier () called with qualifier\n                '%s', which doesn't exist!\n", qualifier);
	return NULL;
	}

char *phoebe_keyword_from_description (char *description)
	{
	/* This function returns the keyword of the given description.              */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].description, description) == 0 )
			return PHOEBE_parameters[i].keyword;

	phoebe_warning ("phoebe_keyword_from_description () called with description\n                '%s', which doesn't exist!\n", description);
	return NULL;
	}

char *phoebe_description_from_qualifier (char *qualifier)
	{
	/* This function returns the description of the given qualifier.            */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].qualifier, qualifier) == 0 )
			return PHOEBE_parameters[i].description;

	phoebe_warning ("phoebe_description_from_qualifier () called with qualifier\n                '%s', which doesn't exist!\n", qualifier);
	return NULL;
	}

char *phoebe_description_from_keyword (char *keyword)
	{
	/* This function returns the description of the given keyword.              */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].keyword, keyword) == 0 )
			return PHOEBE_parameters[i].description;

	phoebe_warning ("phoebe_description_from_keyword () called with keyword\n                '%s', which doesn't exist!\n", keyword);
	return NULL;
	}

int phoebe_index_from_qualifier (char *qualifier)
	{
	/* This function returns the parameter table index of the given qualifier.  */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].qualifier, qualifier) == 0 )
			return i;

	phoebe_warning ("phoebe_index_from_qualifier () called with qualifier\n                '%s', which doesn't exist!\n", qualifier);
	return -1;
	}

int phoebe_index_from_keyword (char *keyword)
	{
	/* This function returns the parameter table index of the given keyword.    */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].keyword, keyword) == 0 )
			return i;

	phoebe_warning ("phoebe_index_from_keyword () called with keyword\n                '%s', which doesn't exist!\n", keyword);
	return -1;
	}

int phoebe_index_from_description (char *description)
	{
	/* This function returns the parameter table index of the given description.*/
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].description, description) == 0 )
			return i;

	phoebe_warning ("phoebe_index_from_description () called with description\n                '%s', which doesn't exist!\n", description);
	return -1;
	}

PHOEBE_type phoebe_type_from_qualifier (char *qualifier)
	{
	/* This function returns the parameter type of the given qualifier. If the  */
	/* qualifier doesn't exist, -1 is returned.                                 */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].qualifier, qualifier) == 0 )
			return PHOEBE_parameters[i].type;

	return -1;
	}

PHOEBE_type phoebe_type_from_keyword (char *keyword)
	{
	/* This function returns the parameter type of the given keyword.           */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].keyword, keyword) == 0 )
			return PHOEBE_parameters[i].type;

	phoebe_warning ("phoebe_type_from_keyword () called with keyword\n                '%s', which doesn't exist!\n", keyword);
	return -1;
	}

PHOEBE_type phoebe_type_from_description (char *description)
	{
	/* This function returns the parameter type of the given description.       */
	
	int i;
	
	for (i = 0; i < PHOEBE_parameters_no; i++)
		if ( strcmp (PHOEBE_parameters[i].description, description) == 0 )
			return PHOEBE_parameters[i].type;

	phoebe_warning ("phoebe_type_from_description () called with description\n                '%s', which doesn't exist!\n", description);
	return -1;
	}

/* ************************************************************************** */

int phoebe_get_value_int (char *qualifier)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.i;
	}

bool phoebe_get_value_bool (char *qualifier)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.b;
	}

double phoebe_get_value_double (char *qualifier)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.d;
	}

const char *phoebe_get_value_string (char *qualifier)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.str;
	}

char *phoebe_get_value_list_string (char *qualifier, int row)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.strarray[row];
	}

double phoebe_get_value_list_double (char *qualifier, int row)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.darray[row];
	}

bool phoebe_get_value_list_bool (char *qualifier, int row)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.barray[row];
	}

int phoebe_get_value_list_int (char *qualifier, int row)
	{
	return PHOEBE_parameters[phoebe_index_from_qualifier (qualifier)].value.iarray[row];
	}

int phoebe_get_parameter_value (char *qualifier, ...)
	{
	/* This is the public function for changing qualifier values. It is the on- */
	/* ly function that should be used for this purpose, all other functions    */
	/* should be regarded as internal and should not be used.                   */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  array subscript is out of range                                */
	/*    0  ..  everything ok, continue                                        */

	int index = 0;
	va_list args;

	va_start (args, qualifier);
	switch (phoebe_type_from_qualifier (qualifier))
		{
		case TYPE_INT:
			{
			int *value = va_arg (args, int *);
			*value = phoebe_get_value_int (qualifier);
			}
		break;
		case TYPE_BOOL:
			{
			bool *value = va_arg (args, bool *);
			*value = phoebe_get_value_bool (qualifier);
			}
		break;
		case TYPE_DOUBLE:
			{
			double *value = va_arg (args, double *);
			*value = phoebe_get_value_double (qualifier);
			}
		break;
		case TYPE_STRING:
			{
			const char **value = va_arg (args, const char **);
			*value = phoebe_get_value_string (qualifier);
			}
		break;
		case TYPE_INT_ARRAY:
			index = va_arg (args, int);
			{
			int *value = va_arg (args, int *);
			int i = phoebe_index_from_qualifier (qualifier);
			int range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
			if (index < 0 || index > range-1) return -2;

			*value = phoebe_get_value_list_int (qualifier, index);
			}
		break;
		case TYPE_BOOL_ARRAY:
			index = va_arg (args, int);
			{
			bool *value = va_arg (args, bool *);
			int i = phoebe_index_from_qualifier (qualifier);
			int range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
			if (index < 0 || index > range-1) return -2;

			*value = phoebe_get_value_list_bool (qualifier, index);
			}
		break;
		case TYPE_DOUBLE_ARRAY:
			index = va_arg (args, int);
			{
			double *value = va_arg (args, double *);
			int i = phoebe_index_from_qualifier (qualifier);
			int range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
			if (index < 0 || index > range-1) return -2;

			*value = phoebe_get_value_list_double (qualifier, index);
			}
		break;
		case TYPE_STRING_ARRAY:
			index = va_arg (args, int);
			{
			const char **value = va_arg (args, const char **);
			int i = phoebe_index_from_qualifier (qualifier);
			int range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
			if (index < 0 || index > range-1) return -2;

			*value = phoebe_get_value_list_string (qualifier, index);
			}
		break;
		}
	va_end (args);

	return 0;
	}

/* ************************************************************************** */

int intern_set_value_int (char *qualifier, int value)
	{
	int oldval = phoebe_get_value_int (qualifier);
	int i = phoebe_index_from_qualifier (qualifier);

	PHOEBE_parameters[i].value.i = value;
	if (strcmp (PHOEBE_parameters[i].bond, "bond") == 0)
		update_parameter_arrays (qualifier, oldval);

	return 0;
	}

int intern_set_value_double (char *qualifier, double value)
	{
	int i = phoebe_index_from_qualifier (qualifier);
	PHOEBE_parameters[i].value.d = value;

	return 0;
	}

int intern_set_value_bool (char *qualifier, bool value)
	{
	int i = phoebe_index_from_qualifier (qualifier);
	PHOEBE_parameters[i].value.b = value;

	return 0;
	}

int intern_set_value_string (char *qualifier, const char *value)
	{
	int i = phoebe_index_from_qualifier (qualifier);
	free (PHOEBE_parameters[i].value.str);
	PHOEBE_parameters[i].value.str = phoebe_malloc (strlen (value) + 1);
	strcpy (PHOEBE_parameters[i].value.str, value);

	return 0;
	}

int intern_set_value_list_string (char *qualifier, int row, const char *value)
	{
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the array index is out of bounds                               */
	/*   -1  ..  (reserved for non-existent qualifier signal)                   */
	/*    0  ..  set command successful                                         */

	int i = phoebe_index_from_qualifier (qualifier);
	int range;

	range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
	if (row < 0 || row > range-1) return -2;

	free (PHOEBE_parameters[i].value.strarray[row]);
	PHOEBE_parameters[i].value.strarray[row] = phoebe_malloc (strlen (value) + 1);
	strcpy (PHOEBE_parameters[i].value.strarray[row], value);
	return 0;
	}

int intern_set_value_list_int (char *qualifier, int row, int value)
	{
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the array index is out of bounds                               */
	/*   -1  ..  (reserved for non-existent qualifier signal)                   */
	/*    0  ..  set command successful                                         */

	int i = phoebe_index_from_qualifier (qualifier);
	int range;

	range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
	if (row < 0 || row > range-1) return -2;

	PHOEBE_parameters[i].value.iarray[row] = value;
	return 0;
	}

int intern_set_value_list_double (char *qualifier, int row, double value)
	{
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the array index is out of bounds                               */
	/*   -1  ..  (reserved for non-existent qualifier signal)                   */
	/*    0  ..  set command successful                                         */

	int i = phoebe_index_from_qualifier (qualifier);
	int range;

	range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
	if (row < 0 || row > range-1) return -2;

	PHOEBE_parameters[i].value.darray[row] = value;
	return 0;
	}

int intern_set_value_list_bool (char *qualifier, int row, bool value)
	{
	/* Return values:                                                           */
	/*                                                                          */
	/*   -2  ..  the array index is out of bounds                               */
	/*   -1  ..  (reserved for non-existent qualifier signal)                   */
	/*    0  ..  set command successful                                         */

	int i = phoebe_index_from_qualifier (qualifier);
	int range;

	range = phoebe_get_value_int (PHOEBE_parameters[i].bond);
	if (row < 0 || row > range-1) return -2;

	PHOEBE_parameters[i].value.barray[row] = value;
	return 0;
	}

int phoebe_set_parameter_value (char *qualifier, ...)
	{
	/* This is the public function for changing qualifier values. It is the on- */
	/* ly function that should be used for this purpose, all other functions    */
	/* should be regarded as internal and should not be used.                   */

	int index = 0;
	va_list args;
	int errno;

	PHOEBE_type type = phoebe_type_from_qualifier (qualifier);

	if (type == -1) return -1;

	va_start (args, qualifier);
	switch (phoebe_type_from_qualifier (qualifier))
		{
		case TYPE_INT:
			{
			int value = va_arg (args, int);
			errno = intern_set_value_int (qualifier, value);
			}
		break;
		case TYPE_BOOL:
			{
			bool value = va_arg (args, bool);
			errno = intern_set_value_bool (qualifier, value);
			}
		break;
		case TYPE_DOUBLE:
			{
			double value = va_arg (args, double);
			errno = intern_set_value_double (qualifier, value);
			}
		break;
		case TYPE_STRING:
			{
			char *value = va_arg (args, char *);
			errno = intern_set_value_string (qualifier, value);
			}
		break;
		case TYPE_INT_ARRAY:
			index = va_arg (args, int);
			{
			int value = va_arg (args, int);
			errno = intern_set_value_list_int (qualifier, index, value);
			}
		break;
		case TYPE_BOOL_ARRAY:
			index = va_arg (args, int);
			{
			bool value = va_arg (args, bool);
			errno = intern_set_value_list_bool (qualifier, index, value);
			}
		break;
		case TYPE_DOUBLE_ARRAY:
			index = va_arg (args, int);
			{
			double value = va_arg (args, double);
			errno = intern_set_value_list_double (qualifier, index, value);
			}
		break;
		case TYPE_STRING_ARRAY:
			index = va_arg (args, int);
			{
			char *value = va_arg (args, char *);
			errno = intern_set_value_list_string (qualifier, index, value);
			}
		break;
		}
	va_end (args);

	/* Since the global lookup table has changed, we have to signal the plugins */
	/* to update their own tables.                                              */
	if (errno == 0)
		emit_parameter_changed_signal_for_plugins (qualifier, index);

	return errno;
	}

PHOEBE_input_indep get_input_independent_variable (char *value)
	{
	/* This function returns the input independent variable enumeration.        */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */

	if (strcmp (value, "Phase")      == 0) return INPUT_PHASE;
	if (strcmp (value, "Time (HJD)") == 0) return INPUT_HJD;
	
	return -1;
	}

PHOEBE_input_dep get_input_dependent_variable (char *value)
	{
	/* This function returns the input dependent variable enumeration.          */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */

	if (strcmp (value, "Magnitude")  == 0) return INPUT_MAGNITUDE;
	if (strcmp (value, "Flux")       == 0) return INPUT_FLUX;
	if (strcmp (value, "RV in km/s") == 0) return INPUT_RV_IN_KMS;
	
	return -1;
	}

PHOEBE_input_weight get_input_weight (char *value)
	{
	/* This function returns the input weight variable enumeration.             */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */

	if (strcmp (value, "Standard weight (integer)")  == 0) return INPUT_STANDARD_WEIGHT;
	if (strcmp (value, "Standard weight (double)")   == 0) return INPUT_STANDARD_WEIGHT;
	if (strcmp (value, "Standard deviation (sigma)") == 0) return INPUT_STANDARD_DEVIATION;
	if (strcmp (value, "Unavailable")                == 0) return INPUT_UNAVAILABLE;
	
	return -1;
	}

PHOEBE_output_indep get_output_independent_variable (char *value)
	{
	/* This function returns the output independent variable enumeration.       */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */
	/*                                                                          */

	if (strcmp (value, "Phase")      == 0) return OUTPUT_PHASE;
	if (strcmp (value, "Time (HJD)") == 0) return OUTPUT_HJD;

	return -1;
	}

PHOEBE_output_dep get_output_dependent_variable (char *value)
	{
	/* This function returns the output dependent variable enumeration.         */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */

	if (strcmp (value, "Magnitude")               == 0) return OUTPUT_MAGNITUDE;
	if (strcmp (value, "Total flux")              == 0) return OUTPUT_TOTAL_FLUX;
	if (strcmp (value, "Primary star flux")       == 0) return OUTPUT_PRIMARY_FLUX;
	if (strcmp (value, "Secondary star flux")     == 0) return OUTPUT_SECONDARY_FLUX;
	if (strcmp (value, "Primary RV")              == 0) return OUTPUT_PRIMARY_RV;
	if (strcmp (value, "Secondary RV")            == 0) return OUTPUT_SECONDARY_RV;
	if (strcmp (value, "Both RVs")                == 0) return OUTPUT_BOTH_RVS;
	if (strcmp (value, "Primary normalized RV")   == 0) return OUTPUT_PRIMARY_NORMALIZED_RV;
	if (strcmp (value, "Secondary normalized RV") == 0) return OUTPUT_SECONDARY_NORMALIZED_RV;

	return -1;
	}

PHOEBE_output_weight get_output_weight (char *value)
	{
	/* This function returns the output weighting variable enumeration.         */
	/*                                                                          */
	/* Return values:                                                           */
	/*                                                                          */
	/*     -1  ..  recognition failed                                           */
	/*   enum  ..  the recognition was successful                               */

	if (strcmp (value, "Standard weight")            == 0) return OUTPUT_STANDARD_WEIGHT;
	if (strcmp (value, "Standard deviation (sigma)") == 0) return OUTPUT_STANDARD_DEVIATION;
	if (strcmp (value, "Unavailable")                == 0) return OUTPUT_UNAVAILABLE;

	return -1;
	}

void get_from_keyword_file (char *qualifier, char *value_str)
	{
	int i = phoebe_index_from_qualifier (qualifier);

	switch (PHOEBE_parameters[i].type)
		{
		case TYPE_INT:
			phoebe_set_parameter_value (qualifier, atoi (value_str));
		break;
		case TYPE_BOOL:
			phoebe_set_parameter_value (qualifier, atoi (value_str));
		break;
		case TYPE_DOUBLE:
			phoebe_set_parameter_value (qualifier, atof (value_str));
		break;
		case TYPE_STRING:
			/* Strip the string of quotes if necessary:                             */
			while (value_str[0] == '"') value_str++;
			while (value_str[strlen(value_str)-1] == '"') value_str[strlen(value_str)-1] = '\0';
			phoebe_set_parameter_value (qualifier, value_str);
		break;
		}
	}

void get_wavelength_dependent_parameter_from_keyword_file (char *qualifier, char *index, char *value_str)
	{
	/* Much like the function above, only that this one takes three arguments,  */
	/* the 2nd one being the index of the wavelength-dependent parameter.       */

	int i = phoebe_index_from_qualifier (qualifier);
	int idx = atof (index) - 1;

	switch (PHOEBE_parameters[i].type)
		{
		case TYPE_INT_ARRAY:
			phoebe_set_parameter_value (qualifier, idx, atoi (value_str));
		break;
		case TYPE_BOOL_ARRAY:
			phoebe_set_parameter_value (qualifier, idx, atoi (value_str));
		break;
		case TYPE_DOUBLE_ARRAY:
			phoebe_set_parameter_value (qualifier, idx, atof (value_str));
		break;
		case TYPE_STRING_ARRAY:
			while (value_str[0] == '"') value_str++;
			while (value_str[strlen(value_str)-1] == '"') value_str[strlen(value_str)-1] = '\0';
			phoebe_set_parameter_value (qualifier, idx, value_str);
		break;
		}
	}

int open_keyword_file (const char *filename)
	{
	/* This function opens PHOEBE 0.3x keyword files. The return value is:      */
	/*                                                                          */
	/*   -3 .. the specified file isn't a regular file (probably a directory).  */
	/*   -2 .. the specified file doesn't have read permissions.                */
	/*   -1 .. the specified file doesn't exist.                                */
	/*    0 .. everything OK, file readout successful.                          */
	/*    1 .. keywords within a file don't contain '=' signs; this is usually  */
	/*         the case when old keyword files or data files are being opened.  */

	char readout_string[256];
	char *readout_str = readout_string;

	char keyword_string[256];
	char *keyword_str = keyword_string;

	char value_string[256];
	char *value_str = value_string;

	char working_string[256];
	char *working_str = working_string;

	int i;

	FILE *keyword_file;

	/* First a checkup if everything is OK with the filename:                   */
	if (!filename_is_regular_file ((char *) filename))      return -3;
	if (!filename_has_read_permissions ((char *) filename)) return -2;
	if (!filename_exists ((char *) filename))               return -1;

	keyword_file = fopen (filename, "r");
	while (feof (keyword_file) == 0)
		{
		fgets (readout_str, 255, keyword_file);
		if (feof (keyword_file) != 0) break;

		/* fgets reads a newline character, which we don't want really:           */
		readout_str[strlen(readout_str)-1] = '\0';

		/* Let us check if the keyword file is an old PHOEBE keyword file:        */
		if (strchr (readout_str, '=') == NULL)
			{
			fclose (keyword_file);
			open_legacy_keyword_file (filename);
			return 1;
			}

		sscanf (readout_str, "%s = %*s", keyword_str);
		value_str = strchr (readout_str, '=');
		if (value_str == NULL)
			{
			/* If the keyword doesn't have '=', it will be skipped.                 */
			phoebe_warning ("keyword %s in file %s invalid.", keyword_str, filename);
			continue;
			}

		/* value_str now points to '=', we need the next character; beware that   */
		/* this increment offsets the pointer within the char array, thus we have */
		/* to repoint at the end of the loop.                                     */
		value_str++;

		/* Eat all empty spaces at the beginning and at the end:                  */
		while (value_str[0] == ' ') value_str++;
		while (value_str[strlen (value_str)-1] == ' ') value_str[strlen(value_str)-1] = '\0';

		for (i = 0; i < PHOEBE_parameters_no; i++)
			{
			if (strcmp (keyword_str, PHOEBE_parameters[i].keyword) == 0)
				{
				get_from_keyword_file (PHOEBE_parameters[i].qualifier, value_str);
				break;
				}
			if (strncmp (keyword_str, PHOEBE_parameters[i].keyword, strlen (PHOEBE_parameters[i].keyword)) == 0)
				{
				/* This is appopriate for wavelength-dependent parameters; a consecu- */
				/* tive number is attached to the end of the keyword for distinction. */

				keyword_str += strlen (PHOEBE_parameters[i].keyword);
				get_wavelength_dependent_parameter_from_keyword_file (PHOEBE_parameters[i].qualifier, keyword_str, value_str);
				break;
				}
			if (i == PHOEBE_parameters_no - 1)
				printf ("The keyword '%s' isn't recognized by PHOEBE. Sorry.\n", keyword_str);
			}

		/* As explained above, we have to repoint strings:                        */
		readout_str = readout_string;
		keyword_str = keyword_string;
		value_str = value_string;
		working_str = working_string;
		}

	fclose (keyword_file);

	return 0;
	}

void save_to_keyword_file (char *keyword, FILE *file)
	{
	int i = phoebe_index_from_keyword (keyword);
	int j;

	switch (PHOEBE_parameters[i].type)
		{
		case TYPE_INT:
			fprintf (file, "%s = %d\n", keyword, phoebe_get_value_int (phoebe_qualifier_from_keyword (keyword)));
		break;
		case TYPE_BOOL:
			fprintf (file, "%s = %d\n", keyword, phoebe_get_value_bool (phoebe_qualifier_from_keyword (keyword)));
		break;
		case TYPE_DOUBLE:
			fprintf (file, "%s = %lf\n", keyword, phoebe_get_value_double (phoebe_qualifier_from_keyword (keyword)));
		break;
		case TYPE_STRING:
			fprintf (file, "%s = \"%s\"\n", keyword, phoebe_get_value_string (phoebe_qualifier_from_keyword (keyword)));
		break;
		case TYPE_INT_ARRAY:
			for (j = 0; j < phoebe_get_value_int (PHOEBE_parameters[i].bond); j++)
				fprintf (file, "%s%d = %d\n", keyword, j+1, phoebe_get_value_list_int (phoebe_qualifier_from_keyword (keyword), j));
		break;
		case TYPE_BOOL_ARRAY:
			for (j = 0; j < phoebe_get_value_int (PHOEBE_parameters[i].bond); j++)
				fprintf (file, "%s%d = %d\n", keyword, j+1, phoebe_get_value_list_bool (phoebe_qualifier_from_keyword (keyword), j));
		break;
		case TYPE_DOUBLE_ARRAY:
			for (j = 0; j < phoebe_get_value_int (PHOEBE_parameters[i].bond); j++)
				fprintf (file, "%s%d = %lf\n", keyword, j+1, phoebe_get_value_list_double (phoebe_qualifier_from_keyword (keyword), j));
		break;
		case TYPE_STRING_ARRAY:
			for (j = 0; j < phoebe_get_value_int (PHOEBE_parameters[i].bond); j++)
				fprintf (file, "%s%d = \"%s\"\n", keyword, j+1, phoebe_get_value_list_string (phoebe_qualifier_from_keyword (keyword), j));
		break;
		}
	}

int save_keyword_file (const char *filename)
	{
	/* This function saves PHOEBE 0.3x keyword files. The return value is:      */
	/*                                                                          */
	/*   -3 .. the specified file isn't a regular file (probably a directory).  */
	/*   -2 .. the specified file doesn't have write permissions.               */
	/*    0 .. everything OK, file readout successful.                          */

	FILE *keyword_file;
	int i;

	/* First a checkup if everything is OK with the filename:                   */
	if (!filename_is_regular_file ((char *) filename))       return -3;
	if (!filename_has_write_permissions ((char *) filename)) return -2;

	keyword_file = fopen (filename, "w");
	for (i = 0; i < PHOEBE_parameters_no; i++)
		save_to_keyword_file (PHOEBE_parameters[i].keyword, keyword_file);

	fclose (keyword_file);
	return 0;
	}

int open_legacy_keyword_file (const char *filename)
	{
	phoebe_warning ("Not yet implemented!\n");
	return -1;
	}
