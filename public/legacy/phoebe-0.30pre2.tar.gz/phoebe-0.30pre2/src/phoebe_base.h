#ifndef PHOEBE_BASE_H
	#define PHOEBE_BASE_H 1

void   parse_startup_line    (int argc, char *argv[]);
int    variables_init        ();
int    phoebe_init           ();

#endif
