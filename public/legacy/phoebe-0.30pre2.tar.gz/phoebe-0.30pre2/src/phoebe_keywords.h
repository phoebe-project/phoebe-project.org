#ifndef PHOEBE_KEYWORDS_H
	#define PHOEBE_KEYWORDS_H 1

#include "phoebe_global.h"

/* Functions for manipulating internal PHOEBE keywords:                       */

void declare_parameter (char *qualifier, char *bond, char *keyword, char *description, ...);
void update_parameter_arrays (char *bond, int oldval);
void declare_all_parameters ();

char       *phoebe_qualifier_from_keyword       (char *keyword);
char       *phoebe_qualifier_from_description   (char *description);
char       *phoebe_keyword_from_qualifier       (char *qualifier);
char       *phoebe_keyword_from_description     (char *description);
char       *phoebe_description_from_qualifier   (char *qualifier);
char       *phoebe_description_from_keyword     (char *description);
int         phoebe_index_from_qualifier         (char *qualifier);
int         phoebe_index_from_keyword           (char *keyword);
int         phoebe_index_from_description       (char *description);
PHOEBE_type phoebe_type_from_qualifier          (char *qualifier);
PHOEBE_type phoebe_type_from_keyword            (char *keyword);
PHOEBE_type phoebe_type_from_description        (char *description);

int         phoebe_get_value_int             (char *qualifier);         
double      phoebe_get_value_double          (char *qualifier);         
bool        phoebe_get_value_bool            (char *qualifier);         
const char *phoebe_get_value_string          (char *qualifier);         
char       *phoebe_get_value_list_string     (char *qualifier, int row);
double      phoebe_get_value_list_double     (char *qualifier, int row);
bool        phoebe_get_value_list_bool       (char *qualifier, int row);
int         phoebe_get_value_list_int        (char *qualifier, int row);

int         phoebe_get_parameter_value       (char *qualifier, ...);
int         phoebe_set_parameter_value       (char *qualifier, ...);

/* ************************************************************************** */
/* The following functions are internal and are called by the phoebe_set_     */
/* _parameter_value function. Their usage is deprecated and their prototypes  */
/* are thus commented out.                                                    */
/*                                                                            */
/* void intern_set_value_int         (char *qualifier, int value);            */
/* void intern_set_value_double      (char *qualifier, double value);         */
/* void intern_set_value_bool        (char *qualifier, bool value);           */
/* void intern_set_value_string      (char *qualifier, const char *value);    */
/* void intern_set_value_list_string (char *qualifier, int row,               */
/*                                                        const char *value); */
/* void intern_set_value_list_int    (char *qualifier, int row, int value);   */
/* void intern_set_value_list_double (char *qualifier, int row,               */
/*                                                             double value); */
/* void intern_set_value_list_bool   (char *qualifier, int row, bool value);  */
/*                                                                            */
/* ************************************************************************** */

PHOEBE_input_indep   get_input_independent_variable  (char *value);
PHOEBE_input_dep     get_input_dependent_variable    (char *value);
PHOEBE_input_weight  get_input_weight                (char *value);
PHOEBE_output_indep  get_output_independent_variable (char *value);
PHOEBE_output_dep    get_output_dependent_variable   (char *value);
PHOEBE_output_weight get_output_weight               (char *value);

/* Opening and saving keyword files:                                          */

void get_from_keyword_file (char *qualifier, char *value_str);
int  open_keyword_file (const char *filename);
int  open_legacy_keyword_file (const char *filename);

void save_to_keyword_file (char *param, FILE *file);
int  save_keyword_file (const char *filename);

#endif
